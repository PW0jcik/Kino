package GUIAddons;

import javafx.scene.control.Label;

public class MainBar extends Label {

    public MainBar(int width, int height){
        this.setLayoutX(0);
        this.setLayoutY(0);
        this.setMinWidth(width);
        this.setMinHeight(height);
        this.setStyle("-fx-background-color: #282828;");
    }
}

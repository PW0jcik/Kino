package GUIAddons;

import javafx.scene.control.Label;

public class SeparatorLineLabel extends Label {
    public SeparatorLineLabel(int xPosition, int yPosition){
        this.setText("|");
        this.setLayoutX(xPosition);
        this.setLayoutY(yPosition);
        this.setHeight(80);
        this.setStyle("-fx-font-family: Roboto; -fx-font-size: 24px; -fx-text-fill: #FFFFFF;");
    }
}

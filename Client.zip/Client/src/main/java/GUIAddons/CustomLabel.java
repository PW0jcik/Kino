package GUIAddons;

import javafx.scene.control.Label;

public class CustomLabel extends Label {

    public CustomLabel(String labelName, int xPosition, int yPosition, int fontSize){
        this.setText(labelName);
        this.setLayoutX(xPosition);
        this.setLayoutY(yPosition);
        this.setStyle("-fx-font-family: Roboto; -fx-font-size:" + fontSize+ "px; -fx-text-fill: #FFFFFF;");
    }
}

package GUIAddons;

import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class TemplateWindow extends Application {
    public static int sleepTime = 550;
    final int screenWidth = 1200;
    final int screenHeight = 800;
    Pane root;
    Scene scene;
    MainBar mainBar;

    public void start(Stage stage) throws Exception {
        setMainBar();
        root = new Pane();
        root.setStyle("-fx-background-image: url(" + String.valueOf(getClass().getResource("/images/cinema_image.jpg")) + "); " + "-fx-background-size: cover;");
        root.getChildren().add(mainBar);

        this.scene = new Scene(root, screenWidth, screenHeight);

        stage.setResizable(false);
        stage.setScene(this.scene);
        stage.getIcons().add(new Image(String.valueOf(getClass().getResource("/images/cinema_icon.png"))));
        stage.setTitle("Kino");
        stage.show();
    }
    public void setMainBar(){
        mainBar = new MainBar(screenWidth,80);
    }
    public void addToPane(Object object){
        this.root.getChildren().add((Node) object);
    }
    public Scene getScene(){
        return this.scene;
    }
}

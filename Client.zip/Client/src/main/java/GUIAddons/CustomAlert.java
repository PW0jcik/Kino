package GUIAddons;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class CustomAlert {
    public Alert alert;
    public CustomAlert(String alertText){
        this.alert = new Alert(Alert.AlertType.ERROR, alertText);
        Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
        stage.getIcons().add(new Image(String.valueOf(getClass().getResource("/images/cinema_icon.png"))));
        alert.getButtonTypes().set(0, new ButtonType("OK", ButtonBar.ButtonData.LEFT));
        alert.showAndWait();
    }
}

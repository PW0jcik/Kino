package GUIAddons;

import javafx.scene.control.Button;

public class SeatButton extends Button {
    public int seatNumber;
    private final int seatSize = 50;
    public String standardButtonStyle;
    public String hoveredButtonStyle;

    public SeatButton(int seatNumber, int xPosition, int yPosition){
        this.seatNumber = seatNumber;
        this.setText(String.valueOf(seatNumber));
        setDimensionsAndPosition(xPosition, yPosition);
        setStandardButtonStyle();
        setHoveredButtonStyle();
        this.setStyle(standardButtonStyle);
        this.setOnMouseEntered(e -> this.setStyle(hoveredButtonStyle));
        this.setOnMouseExited(e -> this.setStyle(standardButtonStyle));
    }
    private void setDimensionsAndPosition(int xPosition, int yPosition){
        this.setLayoutX(xPosition);
        this.setLayoutY(yPosition);
        this.setPrefWidth(this.seatSize);
        this.setPrefHeight(this.seatSize);
    }
    private void setStandardButtonStyle(){
        this.standardButtonStyle = "-fx-font-family: Roboto;"  +
                "-fx-border-width: 2px;"  +
                "-fx-border-radius: 2px;" +
                "-fx-background-color: #730202;" +
                "-fx-font-size: 20px;" +
                "-fx-text-fill: #FFFFFF;" +
                "-fx-background-insets: 0 0 -1 0, 0, 1, 2;";
    }
    private void setHoveredButtonStyle(){
        this.hoveredButtonStyle = "-fx-font-family: Roboto;"  +
                "-fx-border-width: 2px;"  +
                "-fx-border-radius: 2px;" +
                "-fx-background-color: #383838;" +
                "-fx-font-size: 20px;" +
                "-fx-text-fill: #FFFFFF;" +
                "-fx-background-insets: 0 0 -1 0, 0, 1, 2;";
    }
}

package GUIAddons;

import javafx.scene.control.ComboBox;

import java.util.LinkedList;

public class CustomComboBox extends ComboBox {
    public CustomComboBox(String promptText, LinkedList linkedList, int xPosition, int yPosition, int width, int height){
        this.getItems().addAll(linkedList);
        this.setPromptText(promptText);
        this.setLayoutX(xPosition);
        this.setLayoutY(yPosition);
        this.setPrefWidth(width);
        this.setPrefHeight(height);
        this.setEditable(false);
    }
}

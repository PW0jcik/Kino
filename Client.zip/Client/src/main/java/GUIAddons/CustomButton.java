package GUIAddons;

import javafx.scene.control.Button;

public class CustomButton extends Button {
    private int fontSize;
    private String fontColor;
    private String standardButtonStyle;
    private String hoveredButtonStyle;
    private String bgColor;
    private String bgHoverColor;

    public CustomButton(String buttonName, int xPosition, int yPosition, double width,
                        double height, int fontSize){
        this.fontColor = "#e8e8e8";
        this.setText(buttonName);
        this.fontSize = fontSize;
        this.bgColor = "#282828";
        this.bgHoverColor = "#383838";
        setStandardButtonStyle();
        setHoveredButtonStyle();
        setDimensionsAndPosition(xPosition, yPosition, width, height);


        this.setStyle(standardButtonStyle);
        this.setOnMouseEntered(e -> this.setStyle(hoveredButtonStyle));
        this.setOnMouseExited(e -> this.setStyle(standardButtonStyle));
    }
    public CustomButton(String buttonName, int xPosition, int yPosition, double width,
                        double height, int fontSize, String fontColor){
        this.setText(buttonName);
        this.fontColor = fontColor;
        this.fontSize = fontSize;
        this.bgColor = "#282828";
        this.bgHoverColor = "#383838";
        setStandardButtonStyle();
        setHoveredButtonStyle();
        setDimensionsAndPosition(xPosition, yPosition, width, height);


        this.setStyle(standardButtonStyle);
    }
    public CustomButton(String buttonName, int xPosition, int yPosition, double width,
                        double height, int fontSize, String bgColor, String bgHoverColor){
        this.fontColor = "#FFFFFF";
        this.setText(buttonName);
        this.fontSize = fontSize;
        this.bgColor = bgColor;
        this.bgHoverColor = bgHoverColor;
        setStandardButtonStyle();
        setHoveredButtonStyle();
        setDimensionsAndPosition(xPosition, yPosition, width, height);

        this.setStyle(standardButtonStyle);
        this.setOnMouseEntered(e -> this.setStyle(hoveredButtonStyle));
        this.setOnMouseExited(e -> this.setStyle(standardButtonStyle));
    }
    private void setDimensionsAndPosition(int xPosition, int yPosition, double width,
                                          double height){
        this.setLayoutX(xPosition);
        this.setLayoutY(yPosition);
        this.setMinWidth(width);
        this.setMinHeight(height);
        this.setMaxWidth(width);
        this.setMaxHeight(height);
    }
    private void setStandardButtonStyle(){
        this.standardButtonStyle = "-fx-font-family: Roboto;"  +
                "-fx-border-radius: 3px;" +
                "-fx-background-color: " + this.bgColor + ";" +
                "-fx-font-size: " + this.fontSize + "px;" +
                "-fx-text-fill: " + this.fontColor + ";" +
                "-fx-background-insets: 0 0 -1 0, 0, 1, 2;";
    }
    private void setHoveredButtonStyle(){
        this.hoveredButtonStyle = "-fx-font-family: Roboto;"  +
                "-fx-border-radius: 3px;" +
                "-fx-background-color: " + this.bgHoverColor + ";" +
                "-fx-font-size: " + this.fontSize + "px;" +
                "-fx-text-fill: " + this.fontColor + ";" +
                "-fx-background-insets: 0 0 -1 0, 0, 1, 2;";
    }
}

package GUIAddons;

import javafx.scene.control.Label;

public class HorizontalSeparatorLabel extends Label {

    public HorizontalSeparatorLabel(int xPosition, int yPosition, int width){
        this.setLayoutX(xPosition);
        this.setLayoutY(yPosition);
        this.setPrefWidth(width);
        this.setStyle(
                "-fx-font-size: 0.8px;" +
                "-fx-background-radius: 2px;" +
                "-fx-background-color: #e8e8e8;"
        );
    }

}

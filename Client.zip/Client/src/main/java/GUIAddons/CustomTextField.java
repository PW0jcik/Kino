package GUIAddons;

import javafx.scene.control.TextField;

public class CustomTextField extends TextField {

    public CustomTextField(String promptText, int xPosition, int yPosition, int width, int height){
        this.setPromptText(promptText);
        this.setLayoutX(xPosition);
        this.setLayoutY(yPosition);
        this.setPrefWidth(width);
        this.setPrefHeight(height);
        this.setStyle("-fx-font-family: Roboto; -fx-font-size: 14px;");
    }
}

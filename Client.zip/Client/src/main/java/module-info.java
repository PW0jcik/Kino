module Client {
    opens GUIAddons;
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.web;
    requires javafx.media;
    requires junit;
    requires jdk.hotspot.agent;

    exports Client to javafx.graphics,javafx.base,javafx.controls,javafx.web,javafx.media;
    exports ForQueries to javafx.graphics,javafx.base,javafx.controls,javafx.web,javafx.media;
    exports GUIAddons to javafx.graphics,javafx.base,javafx.controls,javafx.web,javafx.media;
    exports Main to javafx.graphics,javafx.base,javafx.controls,javafx.web,javafx.media;
    exports Windows to javafx.base, javafx.controls,javafx.graphics, javafx.media, javafx.web;
    exports Windows.Buyer to javafx.base, javafx.controls, javafx.graphics, javafx.media, javafx.web;
    exports Windows.Employee to javafx.base, javafx.controls, javafx.graphics, javafx.media, javafx.web;
    exports Windows.Owner to javafx.base, javafx.controls, javafx.graphics, javafx.media, javafx.web;
    opens Windows;
    exports ForTables to javafx.base, javafx.controls, javafx.graphics, javafx.media, javafx.web;
    opens ForTables;
}
package ForQueries;

import java.io.Serializable;

public class Client implements Serializable {
    public String login;
    public Client(String login){
        this.login = login;
    }
    public String toString(){
        return login;
    }
}

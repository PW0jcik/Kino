package ForQueries;

import java.io.Serializable;

public class Movie implements Serializable {
    public int movieId;
    public String title;
    public int genreId;
    public int yearOfProduction;
    public String movieDirector;

    final static String sep = ",";

    public Movie(String s){
        String tmp[] = s.split(sep);
        movieId = Integer.parseInt(tmp[0]);
        title = tmp[1];
        genreId = Integer.parseInt(tmp[2]);
        yearOfProduction = Integer.parseInt(tmp[3]);
        movieDirector = tmp[4];
    }
    public String toString(){
        return title + sep + " " + yearOfProduction + sep + " " + movieDirector;
    }
    public String toString2(){
        return movieId + ". " + title + ", " + yearOfProduction + ", " + movieDirector + ", Zarezerwowano: " + genreId;
    }
}
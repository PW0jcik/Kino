package ForQueries;

import java.io.Serializable;

public class ReservationSummary implements Serializable {
    public int seanceId;
    public String movieTitle;
    public String dateOfSeance;
    public String hourOfSeance;
    public int hallNumber;
    public int seatNumber;
    final static String sep = ",";

    public ReservationSummary(String s){
        String tmp[] = s.split(sep);
        seanceId = Integer.parseInt(tmp[0]);
        movieTitle = tmp[1];
        dateOfSeance = tmp[2];
        hourOfSeance = tmp[3];
        hallNumber = Integer.parseInt(tmp[4]);
        seatNumber = Integer.parseInt(tmp[5]);
    }
    public String toString(){
        return seanceId + sep + movieTitle + sep + dateOfSeance + sep + hourOfSeance + sep + hallNumber + sep + seatNumber;
    }
}
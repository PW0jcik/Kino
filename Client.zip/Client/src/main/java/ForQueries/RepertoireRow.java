package ForQueries;

import java.io.Serializable;

public class RepertoireRow implements Serializable {
    public int movieId;
    public String movieTitle;
    public int yearOfProduction;
    public String movieDirector;
    public String movieGenre;

    final static String sep = ",";

    public RepertoireRow(String s){
        String tmp[] = s.split(sep);
        movieId = Integer.parseInt(tmp[0]);
        movieTitle = tmp[1];
        yearOfProduction = Integer.parseInt(tmp[2]);
        movieDirector = tmp[3];
        movieGenre = tmp[4];
    }
    public String toString(){
        return movieId + sep + movieTitle + sep + yearOfProduction + sep + movieDirector + sep + movieGenre;
    }
}
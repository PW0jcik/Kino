package ForQueries;

import java.io.Serializable;

public class Account implements Serializable {
    public String login;
    public String password;
    public int privileges;
    final static String sep = ",";

    public Account(String s){
        String tmp[] = s.split(sep);
        login = tmp[0];
        password = tmp[1];
        privileges = Integer.parseInt(tmp[2]);
    }
    public String toString(){
        return login + sep + password + sep + privileges;
    }
}
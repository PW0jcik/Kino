package ForQueries;

import java.io.Serializable;

public class SeanceCharacteristics implements Serializable {
    public int seanceId;
    public String seanceDate;
    public double seancePrice;

    final static String sep = ",";

    public SeanceCharacteristics(String s){
        String tmp[] = s.split(sep);
        seanceId = Integer.parseInt(tmp[0]);
        seanceDate = tmp[1];
        seancePrice = Double.parseDouble(tmp[2]);
    }
    public String toString(){
        return seanceDate;
    }
    public int getSeanceId(){
        return this.seanceId;
    }
    public String getSeanceDate(){
        return this.seanceDate;
    }
    public double getSeancePrice(){
        return this.seancePrice;
    }
}
package ForQueries;

import java.io.Serializable;

public class ReservationToShow implements Serializable {
    public int reservationId;
    public String clientName;
    public String dateOfReservation;
    public int seanceId;
    public String movieTitle;
    public int hallNumber;
    public int seatNumber;

    final static String sep = ",";

    public ReservationToShow(String s){
        String tmp[] = s.split(sep);
        reservationId = Integer.parseInt(tmp[0]);
        clientName = tmp[1];
        dateOfReservation = tmp[2];
        seanceId = Integer.parseInt(tmp[3]);
        movieTitle = tmp[4];
        hallNumber = Integer.parseInt(tmp[5]);
        seatNumber = Integer.parseInt(tmp[6]);
    }
    public String toString(){
        return  reservationId + sep + clientName + sep + dateOfReservation + sep +
                seanceId + sep + movieTitle + sep + hallNumber + sep + seatNumber;
    }
}

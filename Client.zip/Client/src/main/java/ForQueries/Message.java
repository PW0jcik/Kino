package ForQueries;

import java.io.Serializable;

public class Message<T> implements Serializable{
    public int type;
    public T object;

    public Message(int type, T object){
        this.type = type;
        this.object = object;
    }
    public String toString(){
        return type + "," + object.toString();
    }
}
package ForQueries;

import java.io.Serializable;

public class SeanceToSet implements Serializable {
    public int seanceId;
    public String seanceDate;
    public String movieTitle;
    public double seancePrice;

    final static String sep = ",";

    public SeanceToSet(String s){
        String tmp[] = s.split(sep);
        seanceId = Integer.parseInt(tmp[0]);
        seanceDate = tmp[1];
        movieTitle = tmp[2];
        seancePrice = Double.parseDouble(tmp[3]);
    }
    public String toString(){
        return movieTitle + ", " + seanceDate + ", " + seancePrice;
    }
}

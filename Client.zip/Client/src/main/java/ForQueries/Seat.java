package ForQueries;

import java.io.Serializable;

public class Seat implements Serializable {
    public int seatId;

    public Seat(String seatId){
        this.seatId = Integer.valueOf(seatId);
    }
    public String toString(){
        return String.valueOf(seatId);
    }
}

package ForQueries;

import java.io.Serializable;

public class Incomes implements Serializable {
    public double sum;

    public Incomes(String sum){
        this.sum = Double.valueOf(sum);
    }
    public String toString(){
        return String.valueOf(sum);
    }
}

package ForQueries;

import java.io.Serializable;

public class Entry implements Serializable {
    public int entryId;
    public String dayOfWeek;
    public String workHours;
    public int employeeId;
    public String employeeName;

    final static String sep = ",";

    public Entry(String s) {
        String tmp[] = s.split(sep);
        entryId = Integer.parseInt(tmp[0]);
        dayOfWeek = tmp[1];
        workHours = tmp[2];
        employeeId = Integer.parseInt(tmp[3]);
        employeeName = tmp[4];
    }

    public String toString() {
        return entryId + sep + dayOfWeek + sep + workHours + sep + employeeName;
    }
}
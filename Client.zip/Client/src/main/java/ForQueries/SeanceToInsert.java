package ForQueries;

import java.io.Serializable;

public class SeanceToInsert implements Serializable {
    public String seanceDate;
    public int movieId;
    public int hallId;

    final static String sep = ",";

    public SeanceToInsert(String s){
        String tmp[] = s.split(sep);
        seanceDate = tmp[0];
        movieId = Integer.parseInt(tmp[1]);
        hallId = Integer.parseInt(tmp[2]);
    }
    public String toString(){
        return seanceDate + sep + movieId + sep + hallId;
    }
}

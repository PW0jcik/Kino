package Windows.Owner;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.*;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;

public class StatisticsWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton employeesButton, workScheduleButton, ticketManagementButton, statisticsButton, logoutButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    Label statisticLabel, incomeLabel, moviesRankLabel, typeOfTicketLabel, genreOfMoviesRankLabel;
    ActiveSocketClient activeSocketClient;

    Incomes incomes;
    LinkedList<Movie> listOfTop3Movies;
    LinkedList<TicketType> listOfTop3TicketTypes;
    LinkedList<Genre> listOfTop3Genres;


    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();

        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setEmployeesButton(stage);
        setWorkScheduleButton(stage);
        setTicketManagementButton(stage);
        setStatisticsButton(stage);
        setLogoutButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(402,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels() throws IOException, InterruptedException {
        statisticLabel = new CustomLabel("Statystyki", 550, 140, 24);

        getIncomes();
        incomeLabel = new Label("Przychody: " + incomes.sum + " PLN");
        setLabel(incomeLabel,425, 200, 350,70);

        getListOfTop3Movies();
        moviesRankLabel = new Label("\t\t\t      Najpopularniesze filmy\n\n" +
                listOfTop3Movies.get(0).toString2() + "\n" +
                listOfTop3Movies.get(1).toString2() + "\n" +
                listOfTop3Movies.get(2).toString2());
        setLabel(moviesRankLabel,340, 290, 520,180);

        getListOfTop3TicketTypes();
        typeOfTicketLabel = new Label("  Najpopularniejsze bilety\n\n" +
                "  " + listOfTop3TicketTypes.get(0) + "\n" +
                "  " + listOfTop3TicketTypes.get(1) + "\n" +
                "  " + listOfTop3TicketTypes.get(2));
        setLabel(typeOfTicketLabel,340, 490, 250,170);

        getListOfTop3Genres();
        genreOfMoviesRankLabel = new Label(" Najpolulajniesze gatunki\n\n" +
                "    " + listOfTop3Genres.get(0) + "\n" +
                "    " + listOfTop3Genres.get(1) + "\n" +
                "    " + listOfTop3Genres.get(2));
        setLabel(genreOfMoviesRankLabel,610, 490, 250,170);
    }

    private void setEmployeesButton(Stage stage){
        employeesButton = new CustomButton("Pracownicy",0,0,150,79,20);
        employeesButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeeListWindow(this.activeSocketClient, stage);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Harmonogram pracy", 160, 0, 240, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeesWorkScheduleWindow(this.activeSocketClient, stage);
        });
    }
    private void setTicketManagementButton(Stage stage){
        ticketManagementButton = new CustomButton("Zarządzanie biletami", 410, 0, 250, 79, 20);
        ticketManagementButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnTicketManagementWindow(this.activeSocketClient, stage);
        });
    }
    private void setStatisticsButton(Stage stage){
        statisticsButton = new CustomButton("Statystyki", 910, 0, 150, 79, 20, "#E2202C");
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setLabel(Label label, int xPosition, int yPosition, int width, int height){
        label.setLayoutX(xPosition);
        label.setLayoutY(yPosition);
        label.setPrefWidth(width);
        label.setPrefHeight(height);

        label.setStyle("-fx-font-family: Roboto;" +
                "-fx-background-color: #282828;" +
                "-fx-font-size: 18px;" +
                "-fx-text-fill: #FFFFFF;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 4px;");
    }
    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(employeesButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(ticketManagementButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(statisticsButton);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(statisticLabel);
        templateWindow.addToPane(incomeLabel);
        templateWindow.addToPane(moviesRankLabel);
        templateWindow.addToPane(typeOfTicketLabel);
        templateWindow.addToPane(genreOfMoviesRankLabel);
    }
    private void getIncomes() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(27, new Incomes("0")));
        Thread.sleep(TemplateWindow.sleepTime);
        incomes = (Incomes) activeSocketClient.lastMessage.object;
    }
    private void getListOfTop3Movies() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(25, new Movie("0,0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfTop3Movies = (LinkedList<Movie>) activeSocketClient.lastMessage.object;
    }
    private void getListOfTop3TicketTypes() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(24, new TicketType("0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfTop3TicketTypes = (LinkedList<TicketType>) activeSocketClient.lastMessage.object;
    }
    private void getListOfTop3Genres() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(26, new Genre("0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfTop3Genres = (LinkedList<Genre>) activeSocketClient.lastMessage.object;
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
}

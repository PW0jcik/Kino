package Windows.Owner;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.*;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;


public class TicketManagementWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton employeesButton, workScheduleButton, ticketManagementButton, statisticsButton, logoutButton, confirmButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    CustomLabel setTicketPriceLabel, seanceLabel, priceLabel;
    CustomComboBox seanceComboBox, priceComboBox;
    ActiveSocketClient activeSocketClient;

    LinkedList<SeanceToSet> listOfSeancesToSet;
    LinkedList<String> listOfSeancesPrice;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setAllComboBoxes();

        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setEmployeesButton(stage);
        setWorkScheduleButton(stage);
        setTicketManagementButton(stage);
        setStatisticsButton(stage);
        setLogoutButton(stage);
        setConfirmButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(402,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels(){
        setTicketPriceLabel = new CustomLabel("Ustalanie ceny biletu", 490, 140, 24);
        seanceLabel = new CustomLabel("Seans", 360, 237, 20);
        priceLabel = new CustomLabel("Cena", 360, 292, 20);
    }
    private void setAllComboBoxes() throws IOException, InterruptedException {
        getListOfSeancesToSet();
        seanceComboBox = new CustomComboBox("", listOfSeancesToSet,450, 230, 300, 45);
        getListOfSeancesPrice();
        priceComboBox = new CustomComboBox("", listOfSeancesPrice,450, 285, 300, 45);
    }

    private void setEmployeesButton(Stage stage){
        employeesButton = new CustomButton("Pracownicy",0,0,150,79,20);
        employeesButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeeListWindow(this.activeSocketClient, stage);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Harmonogram pracy", 160, 0, 240, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeesWorkScheduleWindow(this.activeSocketClient, stage);
        });
    }
    private void setTicketManagementButton(Stage stage){
        ticketManagementButton = new CustomButton("Zarządzanie biletami", 410, 0, 250, 79, 20, "#E2202C");
    }
    private void setStatisticsButton(Stage stage){
        statisticsButton = new CustomButton("Statystyki", 910, 0, 150, 79, 20);
        statisticsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnStatisticsWindow(this.activeSocketClient, stage);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setConfirmButton(Stage stage){
        confirmButton = new CustomButton("Zatwierdź", 500, 380, 200, 60, 20);
        confirmButton.setOnAction((event) -> {
            if((seanceComboBox.getValue() == null) || (priceComboBox.getValue() == null)){
                new CustomAlert("Wprowadź wszystkie dane!");
            }else {
                sendSeanceToSet();
                WindowsHandler.changeWindowOnTicketManagementWindow(this.activeSocketClient, stage);
            }
        });
    }
    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(employeesButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(ticketManagementButton);
        templateWindow.addToPane(statisticsButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(setTicketPriceLabel);

        templateWindow.addToPane(seanceLabel);
        templateWindow.addToPane(seanceComboBox);

        templateWindow.addToPane(priceLabel);
        templateWindow.addToPane(priceComboBox);

        templateWindow.addToPane(confirmButton);
    }

    private void getListOfSeancesToSet() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(15, new SeanceToSet("0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfSeancesToSet = (LinkedList<SeanceToSet>) activeSocketClient.lastMessage.object;
    }
    private void getListOfSeancesPrice(){
        listOfSeancesPrice = new LinkedList<String>();
        for(int i=15; i<=30; i++){
            listOfSeancesPrice.add(i + ".00");
            if(i<30)
                listOfSeancesPrice.add(i + ".50");
        }
    }
    private void sendSeanceToSet(){
        int index1 = seanceComboBox.getSelectionModel().getSelectedIndex();
        int seanceId = listOfSeancesToSet.get(index1).seanceId;
        Message message = new Message(16, new SeanceToSet(seanceId + ",0,0," + priceComboBox.getValue()));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
}

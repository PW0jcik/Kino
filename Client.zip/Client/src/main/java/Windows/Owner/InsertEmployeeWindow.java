package Windows.Owner;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.Employee;
import ForQueries.Message;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;

public class InsertEmployeeWindow extends Application {
    TemplateWindow templateWindow;
    CustomLabel insertEmployeeLabel, employeeNameLabel, employeePeselLabel, employeeSalaryLabel, employeePhoneNumberLabel, employeeLoginLabel;
    CustomButton employeesButton, workScheduleButton, ticketManagementButton, statisticsButton, logoutButton, insertEmployeeButton;
    CustomTextField employeeFirstNameField, employeeLastNameField, employeePeselField, employeePhoneNumberField, employeeLoginField;
    CustomComboBox employeeSalaryComboBox;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;

    LinkedList listOfSalary;
    ActiveSocketClient activeSocketClient;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setAllFields();
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setEmployeesButton(stage);
        setWorkScheduleButton(stage);
        setTicketManagementButton(stage);
        setStatisticsButton(stage);
        setLogoutButton(stage);
        setInsertEmployeeButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(402,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels(){
        insertEmployeeLabel = new CustomLabel("Dodaj pracownika", 505, 140, 24);
        employeeNameLabel = new CustomLabel("Pracownik", 340, 197, 20);
        employeePeselLabel = new CustomLabel("PESEL", 340, 252, 20);
        employeeSalaryLabel = new CustomLabel("Pensja", 340, 307, 20);
        employeePhoneNumberLabel = new CustomLabel("Telefon", 340, 362, 20);
        employeeLoginLabel = new CustomLabel("Login", 340, 417, 20);
    }
    private void setAllFields(){
        setListOfSalaryForComboBox();
        employeeFirstNameField = new CustomTextField("Imię", 450, 190, 145, 45);
        employeeLastNameField = new CustomTextField("Nazwisko", 605, 190, 145, 45);
        employeePeselField = new CustomTextField("PESEL", 450, 245, 300, 45);
        employeeSalaryComboBox = new CustomComboBox("", listOfSalary,450, 300, 300,45);
        employeePhoneNumberField = new CustomTextField("Numer telefonu", 450, 355, 300, 45);
        employeeLoginField = new CustomTextField("Login", 450, 410, 300, 45);
    }
    private void setEmployeesButton(Stage stage){
        employeesButton = new CustomButton("Pracownicy",0,0,150,79,20);
        employeesButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeeListWindow(this.activeSocketClient, stage);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Harmonogram pracy", 160, 0, 240, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeesWorkScheduleWindow(this.activeSocketClient, stage);
        });
    }
    private void setTicketManagementButton(Stage stage){
        ticketManagementButton = new CustomButton("Zarządzanie biletami", 410, 0, 250, 79, 20);
        ticketManagementButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnTicketManagementWindow(this.activeSocketClient, stage);
        });
    }
    private void setStatisticsButton(Stage stage){
        statisticsButton = new CustomButton("Statystyki", 910, 0, 150, 79, 20);
        statisticsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnStatisticsWindow(this.activeSocketClient, stage);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setInsertEmployeeButton(Stage stage){
        insertEmployeeButton = new CustomButton("Dodaj pracownika", 500, 480, 200, 60, 20);
        insertEmployeeButton.setOnAction((event) -> {
            System.out.println("Dodaj pracownika");

            sendEmployeeData();
            WindowsHandler.changeWindowOnEmployeeListWindow(this.activeSocketClient, stage);
        });
    }

    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(employeesButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(ticketManagementButton);
        templateWindow.addToPane(statisticsButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(insertEmployeeLabel);

        templateWindow.addToPane(employeeNameLabel);
        templateWindow.addToPane(employeeFirstNameField);
        templateWindow.addToPane(employeeLastNameField);

        templateWindow.addToPane(employeePeselLabel);
        templateWindow.addToPane(employeePeselField);

        templateWindow.addToPane(employeeSalaryLabel);
        templateWindow.addToPane(employeeSalaryComboBox);

        templateWindow.addToPane(employeePhoneNumberLabel);
        templateWindow.addToPane(employeePhoneNumberField);

        templateWindow.addToPane(employeeLoginLabel);
        templateWindow.addToPane(employeeLoginField);

        templateWindow.addToPane(insertEmployeeButton);
    }

    private void setListOfSalaryForComboBox(){
        listOfSalary = new LinkedList();
        for(int i=0; i<=20; i++){
            listOfSalary.add(String.valueOf(2000+i*100));
        }
    }
    private void sendEmployeeData(){
        Message message = new Message(3, new Employee("0," + employeeFirstNameField.getText() + "," + employeeLastNameField.getText() + "," + employeePeselField.getText() + ","
                        + "0," + employeeSalaryComboBox.getValue() + "," + employeePhoneNumberField.getText() + "," + employeeLoginField.getText()));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene() {
        return this.templateWindow.getScene();
    }
}

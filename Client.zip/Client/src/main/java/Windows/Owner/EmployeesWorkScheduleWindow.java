package Windows.Owner;

import Client.ActiveSocketClient;
import ForTables.EntryInfoRow;
import GUIAddons.*;
import ForQueries.Employee;
import ForQueries.Entry;
import ForQueries.Message;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;

public class EmployeesWorkScheduleWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton employeesButton, workScheduleButton, ticketManagementButton, statisticsButton, logoutButton, confirmScheduleButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    CustomLabel setEmployeeScheduleLabel;
    TableView tableOfEntries;
    ActiveSocketClient activeSocketClient;
    LinkedList<Entry> listOfEntries;
    LinkedList<Employee> listOfEmployees;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        EntryInfoRow.setSocket(activeSocketClient);
        EntryInfoRow.setStage(stage);
        getListOfEmployees();
        EntryInfoRow.setListOfEmployees(this.listOfEmployees);
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setTableOfEntries();
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setEmployeesButton(stage);
        setWorkScheduleButton(stage);
        setTicketManagementButton(stage);
        setStatisticsButton(stage);
        setLogoutButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(402,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels(){
        setEmployeeScheduleLabel = new CustomLabel("Harmonogram pracy", 490, 140, 24);
    }

    private void setEmployeesButton(Stage stage){
        employeesButton = new CustomButton("Pracownicy",0,0,150,79,20);
        employeesButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeeListWindow(this.activeSocketClient, stage);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Harmonogram pracy", 160, 0, 240, 79, 20, "#E2202C");
    }
    private void setTicketManagementButton(Stage stage){
        ticketManagementButton = new CustomButton("Zarządzanie biletami", 410, 0, 250, 79, 20);
        ticketManagementButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnTicketManagementWindow(this.activeSocketClient, stage);
        });
    }
    private void setStatisticsButton(Stage stage){
        statisticsButton = new CustomButton("Statystyki", 910, 0, 150, 79, 20);
        statisticsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnStatisticsWindow(this.activeSocketClient, stage);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }

    private void setTableOfEntries() throws IOException, InterruptedException {
        tableOfEntries = new TableView();
        tableOfEntries.setLayoutX(190);
        tableOfEntries.setLayoutY(200);
        tableOfEntries.setPrefWidth(820);
        tableOfEntries.setPrefHeight(520);
        setTableColumns();
    }
    private void setTableColumns() throws IOException, InterruptedException {

        TableColumn<EntryInfoRow, String> dayOfWeekColumn = new TableColumn<>("Dzień tyg.");
        addStyleToColumn(dayOfWeekColumn, 233);
        dayOfWeekColumn.setCellValueFactory(new PropertyValueFactory<>("dayOfWeek"));

        TableColumn<EntryInfoRow, String> workHoursColumn = new TableColumn<>("Godziny");
        addStyleToColumn(workHoursColumn, 233);
        workHoursColumn.setCellValueFactory(new PropertyValueFactory<>("workHours"));

        TableColumn<EntryInfoRow, String> employeeColumn = new TableColumn<>("Pracownik");
        addStyleToColumn(employeeColumn, 234);
        employeeColumn.setCellValueFactory(new PropertyValueFactory<>("employeeName"));

        TableColumn<EntryInfoRow, CustomButton> actionColumn = new TableColumn<>("");
        addStyleToColumn(actionColumn, 100);
        actionColumn.setCellValueFactory(new PropertyValueFactory<>("entryModifyButton"));

        tableOfEntries.getColumns().addAll(dayOfWeekColumn, workHoursColumn, employeeColumn, actionColumn);
        fillTable();
    }
    private void addStyleToColumn(TableColumn tableColumn, int width){
        tableColumn.setPrefWidth(width);
        tableColumn.setStyle("-fx-alignment: center; -fx-font-size: 16px;");
    }
    private void fillTable() throws IOException, InterruptedException {
        getListOfEntries();
        for(int i=0; i<listOfEntries.size(); i++) {
            tableOfEntries.getItems().add(new EntryInfoRow(listOfEntries.get(i).entryId, listOfEntries.get(i).dayOfWeek,
                    listOfEntries.get(i).workHours, listOfEntries.get(i).employeeName));
        }
    }

    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(employeesButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(ticketManagementButton);
        templateWindow.addToPane(statisticsButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(setEmployeeScheduleLabel);
        templateWindow.addToPane(tableOfEntries);
    }

    private void getListOfEntries() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(20, new Entry("0,0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfEntries = (LinkedList<Entry>) activeSocketClient.lastMessage.object;
    }
    private void getListOfEmployees() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(4, new Employee("0,0,0,0,0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfEmployees = (LinkedList<Employee>) activeSocketClient.lastMessage.object;
    }

    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
}

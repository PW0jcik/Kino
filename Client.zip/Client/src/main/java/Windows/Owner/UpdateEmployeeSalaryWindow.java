package Windows.Owner;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.Employee;
import ForQueries.Message;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;

public class UpdateEmployeeSalaryWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton employeesButton, workScheduleButton, ticketManagementButton, statisticsButton, logoutButton, confirmButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    CustomLabel updateEmployeeSalaryLabel, employeeNameLabel, dateOfEmploymentLabel, employeeSalaryLabel;
    CustomTextField employeeFirstNameField, employeeLastNameField, dateOfEmploymentField;
    CustomComboBox employeeSalaryComboBox;

    LinkedList listOfSalary;
    ActiveSocketClient activeSocketClient;
    int employeeId;
    String firstName, lastName;
    String dateOfEmployment;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setAllFields();
        templateWindow.start(stage);
        addAllElements(templateWindow);

    }
    private void setAllButtons(Stage stage){
        setEmployeesButton(stage);
        setWorkScheduleButton(stage);
        setTicketManagementButton(stage);
        setStatisticsButton(stage);
        setLogoutButton(stage);
        setConfirmButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(402,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels(){
        updateEmployeeSalaryLabel = new CustomLabel("Edycja pensji", 530, 140, 24);
        employeeNameLabel = new CustomLabel("Pracownik", 332, 197, 20);
        dateOfEmploymentLabel = new CustomLabel("Zatrudniono", 325, 252, 20);
        employeeSalaryLabel = new CustomLabel("Pensja", 350, 307, 20);
    }
    private void setAllFields(){

        employeeFirstNameField = new CustomTextField("", 450, 190, 145, 45);
        setField(employeeFirstNameField, firstName);

        employeeLastNameField = new CustomTextField("", 605, 190, 145, 45);
        setField(employeeLastNameField, lastName);

        dateOfEmploymentField = new CustomTextField("", 450, 245, 300, 45);
        setField(dateOfEmploymentField, dateOfEmployment);

        setListOfSalaryForComboBox();
        employeeSalaryComboBox = new CustomComboBox("", listOfSalary,450, 300, 300,45);
    }
    private void setField(TextField textField, String text){
        textField.setText(text);
        textField.setDisable(true);
        textField.setStyle("-fx-opacity: 0.8;");
    }
    private void setEmployeesButton(Stage stage){
        employeesButton = new CustomButton("Pracownicy",0,0,150,79,20);
        employeesButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeeListWindow(this.activeSocketClient, stage);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Harmonogram pracy", 160, 0, 240, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeesWorkScheduleWindow(this.activeSocketClient, stage);
        });
    }
    private void setTicketManagementButton(Stage stage){
        ticketManagementButton = new CustomButton("Zarządzanie biletami", 410, 0, 250, 79, 20);
        ticketManagementButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnTicketManagementWindow(this.activeSocketClient, stage);
        });
    }
    private void setStatisticsButton(Stage stage){
        statisticsButton = new CustomButton("Statystyki", 910, 0, 150, 79, 20);
        statisticsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnStatisticsWindow(this.activeSocketClient, stage);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setConfirmButton(Stage stage){
        confirmButton = new CustomButton("Zatwierdź", 500, 370, 200, 60, 20);
        confirmButton.setOnAction((event) -> {
            System.out.println("Zatwierdz");
            sendEmployeeToUpdate();
            WindowsHandler.changeWindowOnEmployeeListWindow(this.activeSocketClient, stage);
        });
    }

    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(employeesButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(ticketManagementButton);
        templateWindow.addToPane(statisticsButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(updateEmployeeSalaryLabel);

        templateWindow.addToPane(employeeNameLabel);
        templateWindow.addToPane(employeeFirstNameField);
        templateWindow.addToPane(employeeLastNameField);

        templateWindow.addToPane(dateOfEmploymentLabel);
        templateWindow.addToPane(dateOfEmploymentField);

        templateWindow.addToPane(employeeSalaryLabel);
        templateWindow.addToPane(employeeSalaryComboBox);

        templateWindow.addToPane(confirmButton);
    }

    private void setListOfSalaryForComboBox(){
        listOfSalary = new LinkedList();
        for(int i=0; i<=20; i++){
            listOfSalary.add(String.valueOf(2000+i*100));
        }
    }
    private void sendEmployeeToUpdate(){
        Message message = new Message(18, new Employee(this.employeeId + ",0,0,0,0," + employeeSalaryComboBox.getValue() + ",0,0"));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene() {
        return this.templateWindow.getScene();
    }
    public void setEmployeeInfoToUpdate(int employeeId, String firstName, String lastName, String dateOfEmployment){
        setEmployeeId(employeeId);
        setFirstName(firstName);
        setLastName(lastName);
        setDateOfEmployment(dateOfEmployment);
    }
    public void setEmployeeId(int employeeId){
        this.employeeId = employeeId;
    }
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    public void setDateOfEmployment(String dateOfEmployment){
        this.dateOfEmployment = dateOfEmployment;
    }
}
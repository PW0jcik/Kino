package Windows.Owner;

import Client.ActiveSocketClient;
import ForTables.EmployeeInfoRow;
import GUIAddons.*;
import ForQueries.Employee;
import ForQueries.Message;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;

public class EmployeeListWindow extends Application {
    TemplateWindow templateWindow;
    CustomLabel employeeListLabel;
    CustomButton employeesButton, workScheduleButton, ticketManagementButton, statisticsButton, logoutButton, insertEmployeeButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    TableView tableOfEmployees;
    ActiveSocketClient activeSocketClient;
    LinkedList<Employee> listOfEmployees;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        EmployeeInfoRow.setSocket(this.activeSocketClient);
        EmployeeInfoRow.setStage(stage);
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setTableOfEmployees();
        templateWindow.start(stage);

        addAllElements(templateWindow);

    }

    private void setAllButtons(Stage stage){
        setEmployeesButton(stage);
        setWorkScheduleButton(stage);
        setTicketManagementButton(stage);
        setStatisticsButton(stage);
        setLogoutButton(stage);
        setInsertEmployeeButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(402,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels() {
        employeeListLabel = new CustomLabel("Lista pracowników", 505, 140, 24);
    }

    private void setEmployeesButton(Stage stage){
        employeesButton = new CustomButton("Pracownicy",0,0,150,79,20,"#E2202C");
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Harmonogram pracy", 160, 0, 240, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnEmployeesWorkScheduleWindow(this. activeSocketClient, stage);
        });
    }
    private void setTicketManagementButton(Stage stage){
        ticketManagementButton = new CustomButton("Zarządzanie biletami", 410, 0, 250, 79, 20);
        ticketManagementButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnTicketManagementWindow(this.activeSocketClient, stage);
        });
    }
    private void setStatisticsButton(Stage stage){
        statisticsButton = new CustomButton("Statystyki", 910, 0, 150, 79, 20);
        statisticsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnStatisticsWindow(this.activeSocketClient, stage);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setInsertEmployeeButton(Stage stage){
        insertEmployeeButton = new CustomButton("+", 1050, 410, 100, 100, 40);
        insertEmployeeButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertEmployeeWindow(this.activeSocketClient, stage);
        });
    }
    private void setTableOfEmployees() throws IOException, InterruptedException {
        tableOfEmployees = new TableView();
        tableOfEmployees.setLayoutX(200);
        tableOfEmployees.setLayoutY(200);
        tableOfEmployees.setPrefWidth(800);
        tableOfEmployees.setPrefHeight(520);
        tableOfEmployees.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        setTableColumns();
    }
    private void setTableColumns() throws IOException, InterruptedException {

        TableColumn<EmployeeInfoRow, Integer> idColumn = new TableColumn<>("ID");
        addStyleToColumn(idColumn);
        idColumn.setCellValueFactory(new PropertyValueFactory<>("employeeId"));

        TableColumn<EmployeeInfoRow, String> firstNameColumn = new TableColumn<>("Imię");
        addStyleToColumn(firstNameColumn);
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));

        TableColumn<EmployeeInfoRow, String> lastNameColumn = new TableColumn<>("Nazwisko");
        addStyleToColumn(lastNameColumn);
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        TableColumn<EmployeeInfoRow, String> dateOfEmploymentColumn = new TableColumn<>("Zatrudniono");
        addStyleToColumn(dateOfEmploymentColumn);
        dateOfEmploymentColumn.setCellValueFactory(new PropertyValueFactory<>("dateOfEmployment"));

        TableColumn<EmployeeInfoRow, Integer> salaryColumn = new TableColumn<>("Pensja");
        addStyleToColumn(salaryColumn);
        salaryColumn.setCellValueFactory(new PropertyValueFactory<>("salary"));

        TableColumn<EmployeeInfoRow, CustomButton> actionBoxColumn = new TableColumn<>("Akcja");
        addStyleToColumn(actionBoxColumn);
        actionBoxColumn.setCellValueFactory(new PropertyValueFactory<>("actionBox"));

        tableOfEmployees.getColumns().addAll(idColumn, firstNameColumn, lastNameColumn, dateOfEmploymentColumn, salaryColumn, actionBoxColumn);
        fillTable();
    }
    private void fillTable() throws IOException, InterruptedException {
        getListOfEmployees();
        for(int i=0; i<listOfEmployees.size(); i++){
            tableOfEmployees.getItems().add(new EmployeeInfoRow(listOfEmployees.get(i).employeeId, listOfEmployees.get(i).firstName,
                    listOfEmployees.get(i).lastName, listOfEmployees.get(i).dateOfEmployment.substring(0, 10), listOfEmployees.get(i).salary, listOfEmployees.get(i).employeeLogin));
        }
    }
    private void addStyleToColumn(TableColumn tableColumn){
        tableColumn.setStyle("-fx-alignment: center; -fx-font-size: 16px;");
    }
    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(employeesButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(ticketManagementButton);
        templateWindow.addToPane(statisticsButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(employeeListLabel);

        templateWindow.addToPane(tableOfEmployees);

        templateWindow.addToPane(insertEmployeeButton);
    }

    private void getListOfEmployees() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(4, new Employee("0,0,0,0,0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfEmployees = (LinkedList<Employee>) activeSocketClient.lastMessage.object;
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene() {
        return this.templateWindow.getScene();
    }
}

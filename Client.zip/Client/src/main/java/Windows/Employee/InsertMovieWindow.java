package Windows.Employee;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.Message;
import ForQueries.Movie;
import Windows.WindowsHandler;
import javafx.application.Application;

import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;


public class InsertMovieWindow extends Application{
    TemplateWindow templateWindow;
    CustomButton reservationsButton, insertSeanceButton, insertMovieButton, workScheduleButton, logoutButton, confirmMovieButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    CustomLabel insertMovieLabel, movieTitleLabel, movieGenreLabel,
            yearProductionLabel, directorLabel, confirmMovieFailureLabel;
    CustomTextField movieTitleField, directorFirstNameField,
            directorLastNameField;
    CustomComboBox genreComboBox, yearProductionField;

    LinkedList listOfGenres, listOfYears;

    ActiveSocketClient activeSocketClient;
    String login;
    int typeOfUser;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setAllFields();
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setReservationsButton(stage);
        setInsertSeanceButton(stage);
        setInsertMovieButton(stage);
        setWorkScheduleButton(stage);
        setLogoutButton(stage);
        setConfirmMovieButton();
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(312,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels(){
        insertMovieLabel = new CustomLabel("Dodawanie filmu", 510, 140, 24);
        movieTitleLabel = new CustomLabel("Tytuł filmu", 320, 197, 20);
        movieGenreLabel = new CustomLabel("Gatunek", 320, 252, 20);
        yearProductionLabel = new CustomLabel("Rok produkcji", 320, 307, 20);
        directorLabel = new CustomLabel("Reżyser", 320, 362, 20);
    }
    private void setAllFields(){
        setListsForComboBoxes();
        movieTitleField = new CustomTextField("", 450, 190, 300, 45);
        genreComboBox = new CustomComboBox("Gatunek", listOfGenres, 450, 245, 300,45);
        directorLastNameField = new CustomTextField("", 450, 245, 300, 45);
        yearProductionField = new CustomComboBox("", listOfYears, 450, 300, 300, 45);
        directorFirstNameField = new CustomTextField("Imię", 450, 355, 145, 45);
        directorLastNameField = new CustomTextField("Nazwisko", 605, 355, 145, 45);
    }

    private void setReservationsButton(Stage stage){
        reservationsButton = new CustomButton("Rezerwacje",0,0,150,79,20);
        reservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnReservationsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setInsertSeanceButton(Stage stage){
        insertSeanceButton = new CustomButton("Dodaj seans", 160, 0, 150, 79, 20);
        insertSeanceButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertSeanceWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setInsertMovieButton(Stage stage){
        insertMovieButton = new CustomButton("Dodaj film", 320, 0, 140, 79, 20, "#E2202C");
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Grafik", 960, 0, 100, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnScheduleForEmployeeWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setConfirmMovieButton(){
        confirmMovieButton = new CustomButton("Dodaj film", 500, 415, 200, 60, 20);
        confirmMovieButton.setOnAction((event) -> {
            System.out.println("zatwierdz film");
            if(movieTitleField.getText() == "" || genreComboBox.getValue() == "" || yearProductionField.getValue() == "" || directorFirstNameField.getText() == "" || directorLastNameField.getText() ==""){
                setInsertFailureLabel();
            }
            else {
                sentMovieToInsert();
            }
        });
    }
    private void setInsertFailureLabel(){
        confirmMovieFailureLabel = new CustomLabel("Dodawanie nieudane!", 485, 555, 24);
        templateWindow.addToPane(confirmMovieFailureLabel);
    }

    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(reservationsButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(insertSeanceButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(insertMovieButton);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(insertMovieLabel);

        templateWindow.addToPane(movieTitleLabel);
        templateWindow.addToPane(movieTitleField);

        templateWindow.addToPane(movieGenreLabel);
        templateWindow.addToPane(genreComboBox);

        templateWindow.addToPane(yearProductionLabel);
        templateWindow.addToPane(yearProductionField);

        templateWindow.addToPane(directorLabel);
        templateWindow.addToPane(directorFirstNameField);
        templateWindow.addToPane(directorLastNameField);

        templateWindow.addToPane(confirmMovieButton);
    }
    private void sentMovieToInsert(){
        Message message = new Message(1,
                new Movie("0," + movieTitleField.getText() + "," + convertGenreStringToId(genreComboBox.getValue()) + "," + yearProductionField.getValue() + ","
                        + directorFirstNameField.getText() + " " + directorLastNameField.getText()));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
        movieTitleField.setText("");
        genreComboBox.setValue("");
        yearProductionField.setValue("");
        directorFirstNameField.setText("");
        directorLastNameField.setText("");
    }

    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    private int convertGenreStringToId(Object type){
        switch(type.toString()) {
            case "Akcja": return 1;
            case "Dramat": return 2;
            case "Horror": return 3;
            case "Komedia": return 4;
            case "Sci-Fi": return 5;
            case "Thriller": return 6;
            case "Western": return 7;
        }
        return 0;
    }
    private void setListsForComboBoxes(){
        listOfGenres = new LinkedList();
        listOfGenres.add("Akcja");
        listOfGenres.add("Dramat");
        listOfGenres.add("Horror");
        listOfGenres.add("Komedia");
        listOfGenres.add("Sci-Fi");
        listOfGenres.add("Thriller");
        listOfGenres.add("Western");

        listOfYears = new LinkedList();
        for(int i=0; i<73; i++){
            listOfYears.add(String.valueOf(i+1950));
        }
    }
    public void setLogin(String login){
        this.login = login;
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }
}



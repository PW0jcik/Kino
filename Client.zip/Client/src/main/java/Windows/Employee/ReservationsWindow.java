package Windows.Employee;

import Client.ActiveSocketClient;
import ForTables.ReservationInfoRow;
import GUIAddons.*;
import ForQueries.Message;
import ForQueries.ReservationToShow;
import Windows.WindowsHandler;
import javafx.application.Application;

import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;


public class ReservationsWindow extends Application{
    TemplateWindow templateWindow;
    CustomButton reservationsButton, insertSeanceButton, insertMovieButton, workScheduleButton, logoutButton, insertReservationButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    CustomLabel listOfReservationsLabel;
    TableView tableOfReservations;
    LinkedList<ReservationToShow> listOfReservations;
    ActiveSocketClient activeSocketClient;
    String login;
    int typeOfUser;


    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        ReservationInfoRow.setSocket(this.activeSocketClient);
        ReservationInfoRow.setStage(stage);
        ReservationInfoRow.setLogin(this.login);
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setTableView();
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }

    private void setAllButtons(Stage stage){
        setReservationsButton(stage);
        setInsertSeanceButton(stage);
        setInsertMovieButton(stage);
        setWorkScheduleButton(stage);
        setLogoutButton(stage);
        setInsertReservationButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(312,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels(){
        listOfReservationsLabel = new CustomLabel("Lista rezerwacji", 515, 140, 24);
    }

    private void setReservationsButton(Stage stage){
        reservationsButton = new CustomButton("Rezerwacje",0,0,150,79,20,"#E2202C");
    }
    private void setInsertSeanceButton(Stage stage){
        insertSeanceButton = new CustomButton("Dodaj seans", 160, 0, 150, 79, 20);
        insertSeanceButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertSeanceWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setInsertMovieButton(Stage stage){
        insertMovieButton = new CustomButton("Dodaj film", 320, 0, 140, 79, 20);
        insertMovieButton.setOnAction((event)->{
            WindowsHandler.changeWindowOnInsertMovieWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Grafik", 960, 0, 100, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnScheduleForEmployeeWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setInsertReservationButton(Stage stage){
        insertReservationButton = new CustomButton("+", 1085, 420, 80, 80, 34);
        insertReservationButton.setOnAction((event) -> {
            System.out.println("+");
            WindowsHandler.changeWindowOnRepertoireWindow(this.activeSocketClient, stage, this.login, 2);
        });
    }

    private void setTableView() throws IOException, InterruptedException {
        tableOfReservations = new TableView();
        tableOfReservations.setLayoutX(150);
        tableOfReservations.setLayoutY(200);
        tableOfReservations.setPrefWidth(900);
        tableOfReservations.setPrefHeight(520);
        setTableColumns();
    }
    private void setTableColumns() throws IOException, InterruptedException {

        TableColumn<ReservationInfoRow, Integer> idColumn = new TableColumn<>("Id");
        addStyleToColumn(idColumn, 50);
        idColumn.setCellValueFactory(new PropertyValueFactory<>("reservationId"));

        TableColumn<ReservationInfoRow, String> lastNameColumn = new TableColumn<>("Kupujący");
        addStyleToColumn(lastNameColumn, 130);
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("clientName"));

        TableColumn<ReservationInfoRow, String> dateOfReservationColumn = new TableColumn<>("Data rezerwacji");
        addStyleToColumn(dateOfReservationColumn, 160);
        dateOfReservationColumn.setCellValueFactory(new PropertyValueFactory<>("dateOfReservation"));

        TableColumn<ReservationInfoRow, Integer> seanceIdColumn = new TableColumn<>("Id seansu");
        addStyleToColumn(seanceIdColumn, 81);
        seanceIdColumn.setCellValueFactory(new PropertyValueFactory<>("seanceId"));

        TableColumn<ReservationInfoRow, String> movieTitleColumn = new TableColumn<>("Tytuł filmu");
        addStyleToColumn(movieTitleColumn, 163);
        movieTitleColumn.setCellValueFactory(new PropertyValueFactory<>("movieTitle"));

        TableColumn<ReservationInfoRow, Integer> hallNumberColumn = new TableColumn<>("Sala");
        addStyleToColumn(hallNumberColumn, 70);
        hallNumberColumn.setCellValueFactory(new PropertyValueFactory<>("hallNumber"));

        TableColumn<ReservationInfoRow, Integer> seatNumberColumn = new TableColumn<>("Siedzenie");
        addStyleToColumn(seatNumberColumn, 90);
        seatNumberColumn.setCellValueFactory(new PropertyValueFactory<>("seatNumber"));

        TableColumn<ReservationInfoRow, HBox> actionBoxColumn = new TableColumn<>("Akcja");
        addStyleToColumn(actionBoxColumn, 137);
        actionBoxColumn.setCellValueFactory(new PropertyValueFactory<>("actionBox"));

        tableOfReservations.getColumns().addAll(idColumn, lastNameColumn, dateOfReservationColumn, seanceIdColumn,
                movieTitleColumn, hallNumberColumn, seatNumberColumn, actionBoxColumn);
        fillTable();
    }
    private void fillTable() throws IOException, InterruptedException {
        getListOfReservations();
        for(int i=0; i<listOfReservations.size(); i++){
            tableOfReservations.getItems().add(new ReservationInfoRow(listOfReservations.get(i).reservationId, listOfReservations.get(i).clientName,
                listOfReservations.get(i).dateOfReservation, listOfReservations.get(i).seanceId,
                listOfReservations.get(i).movieTitle, listOfReservations.get(i).hallNumber, listOfReservations.get(i).seatNumber));
        }
    }
    private void addStyleToColumn(TableColumn tableColumn, int width){
        tableColumn.setPrefWidth(width);
        tableColumn.setStyle("-fx-alignment: center; -fx-font-size: 16px;");
    }

    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(reservationsButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(insertSeanceButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(insertMovieButton);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(listOfReservationsLabel);

        templateWindow.addToPane(tableOfReservations);

        templateWindow.addToPane(insertReservationButton);
    }
    private void getListOfReservations() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(10, new ReservationToShow("0,0,0,0,0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfReservations = (LinkedList<ReservationToShow>) activeSocketClient.lastMessage.object;
        System.out.println(listOfReservations);
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public void setLogin(String login){
        this.login = login;
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }
}



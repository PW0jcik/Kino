package Windows.Employee;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.Message;
import ForQueries.Movie;
import ForQueries.SeanceToInsert;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;

public class InsertSeanceWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton reservationsButton, insertSeanceButton, insertMovieButton, workScheduleButton, logoutButton, confirmSeanceButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    CustomLabel insertSeanceLabel, movieTitleLabel, dateLabel, hourLabel, hallNumberLabel;
    CustomComboBox movieTitleComboBox, hourComboBox, hallNumberComboBox;
    DatePicker datePicker;

    LinkedList<Movie> listOfMovies;
    LinkedList listOfHours;
    LinkedList listOfHalls;

    ActiveSocketClient activeSocketClient;
    String login;
    int typeOfUser;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);

        setAllSeparators();
        setAllLabels();
        setAllComboBoxes();
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setReservationsButton(stage);
        setInsertSeanceButton(stage);
        setInsertMovieButton(stage);
        setWorkScheduleButton(stage);
        setLogoutButton(stage);
        setConfirmSeanceButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(312,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels(){
        insertSeanceLabel = new CustomLabel("Dodawanie seansu", 500, 140, 24);
        movieTitleLabel = new CustomLabel("Film", 320, 197, 20);
        dateLabel = new CustomLabel("Data", 320, 252, 20);
        hourLabel = new CustomLabel("Godzina", 320, 307, 20);
        hallNumberLabel = new CustomLabel("Sala", 320, 362, 20);
    }
    private void setAllComboBoxes() throws IOException, InterruptedException {
        getListOfMovies();
        movieTitleComboBox = new CustomComboBox("Tytuł", listOfMovies,450, 190, 300, 45);
        setDatePicker();
        getListOfHours();
        hourComboBox = new CustomComboBox("Godzina", listOfHours,450, 300, 300, 45);
        getListOfHalls();
        hallNumberComboBox = new CustomComboBox("Numer", listOfHalls, 450, 355, 300, 45);
    }

    private void setReservationsButton(Stage stage){
        reservationsButton = new CustomButton("Rezerwacje",0,0,150,79,20);
        reservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnReservationsWindow(this.activeSocketClient, stage, this.login, 2);
        });
    }
    private void setInsertSeanceButton(Stage stage){
        insertSeanceButton = new CustomButton("Dodaj seans", 160, 0, 150, 79, 20, "#E2202C");
    }
    private void setInsertMovieButton(Stage stage){
        insertMovieButton = new CustomButton("Dodaj film", 320, 0, 140, 79, 20);
        insertMovieButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertMovieWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setWorkScheduleButton(Stage stage) {
        workScheduleButton = new CustomButton("Grafik", 960, 0, 100, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnScheduleForEmployeeWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setConfirmSeanceButton(Stage stage){
        confirmSeanceButton = new CustomButton("Dodaj seans", 500, 415, 200, 60, 20);
        confirmSeanceButton.setOnAction((event) -> {
            if((movieTitleComboBox.getValue() == null) || (datePicker.getValue() == null) || (hourComboBox.getValue() == null) || (hallNumberComboBox.getValue() == null)){
                new CustomAlert("Wprowadz wszystkie dane!");
            }else {
                int index = movieTitleComboBox.getSelectionModel().getSelectedIndex();
                try {
                    insertSeanceMessage(index);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                WindowsHandler.changeWindowOnReservationsWindow(this.activeSocketClient, stage, this.login, 2);
            }
        });
    }
    private void setDatePicker(){
        datePicker = new DatePicker();
        datePicker.setLayoutX(450);
        datePicker.setLayoutY(245);
        datePicker.setPrefWidth(300);
        datePicker.setPrefHeight(45);
        datePicker.setOnAction((event) -> {
            System.out.println(datePicker.getValue());
        });
    }
    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(reservationsButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(insertSeanceButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(insertMovieButton);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(insertSeanceLabel);

        templateWindow.addToPane(movieTitleLabel);
        templateWindow.addToPane(movieTitleComboBox);

        templateWindow.addToPane(dateLabel);
        templateWindow.addToPane(datePicker);

        templateWindow.addToPane(hourLabel);
        templateWindow.addToPane(hourComboBox);

        templateWindow.addToPane(hallNumberLabel);
        templateWindow.addToPane(hallNumberComboBox);

        templateWindow.addToPane(confirmSeanceButton);
    }
    private void getListOfMovies() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(2, new Movie("0,0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfMovies = (LinkedList<Movie>) activeSocketClient.lastMessage.object;
    }
    private void insertSeanceMessage(int index) throws IOException, InterruptedException {
        activeSocketClient.send(new Message(12, new SeanceToInsert(datePicker.getValue() + " " + hourComboBox.getValue() + ":00," + listOfMovies.get(index).movieId + "," + hallNumberComboBox.getValue())));
        Thread.sleep(TemplateWindow.sleepTime);
    }
    private void getListOfHours() {
        listOfHours = new LinkedList();
        for(int i=9; i<21; i++){
            listOfHours.add(i + ":00");
            listOfHours.add(i + ":30");
        }
    }
    private void getListOfHalls() {
        listOfHalls = new LinkedList();
        listOfHalls.add("1");
        listOfHalls.add("2");
        listOfHalls.add("3");
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public void setLogin(String login){
        this.login = login;
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }
}

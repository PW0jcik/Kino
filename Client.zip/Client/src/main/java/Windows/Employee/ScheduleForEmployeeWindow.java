package Windows.Employee;

import Client.ActiveSocketClient;
import ForTables.EntryInfoRow;
import GUIAddons.*;
import ForQueries.Entry;
import ForQueries.Message;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;

public class ScheduleForEmployeeWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton reservationsButton, insertSeanceButton, insertMovieButton, workScheduleButton, logoutButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    CustomLabel employeeWorkScheduleLabel;
    TableView tableOfEntries;
    ActiveSocketClient activeSocketClient;
    LinkedList<Entry> listOfEntries;
    String login;
    int typeOfUser;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setTableOfEntries();
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setReservationsButton(stage);
        setInsertSeanceButton(stage);
        setInsertMovieButton(stage);
        setWorkScheduleButton(stage);
        setLogoutButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(312,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels(){
        employeeWorkScheduleLabel = new CustomLabel("Harmonogram pracy", 490, 140, 24);
    }

    private void setReservationsButton(Stage stage){
        reservationsButton = new CustomButton("Rezerwacje",0,0,150,79,20);
        reservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnReservationsWindow(this.activeSocketClient, stage, this.login, 2);
        });
    }
    private void setInsertSeanceButton(Stage stage){
        insertSeanceButton = new CustomButton("Dodaj seans", 160, 0, 150, 79, 20);
        insertSeanceButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertSeanceWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setInsertMovieButton(Stage stage){
        insertMovieButton = new CustomButton("Dodaj film", 320, 0, 140, 79, 20);
        insertMovieButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertMovieWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setWorkScheduleButton(Stage stage) {
        workScheduleButton = new CustomButton("Grafik", 960, 0, 100, 79, 20,"#E2202C");
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }

    private void setTableOfEntries() throws IOException, InterruptedException {
        tableOfEntries = new TableView();
        tableOfEntries.setLayoutX(240);
        tableOfEntries.setLayoutY(200);
        tableOfEntries.setPrefWidth(720);
        tableOfEntries.setPrefHeight(520);
        setTableColumns();
    }
    private void setTableColumns() throws IOException, InterruptedException {

        TableColumn<EntryInfoRow, String> dayOfWeekColumn = new TableColumn<>("Dzień tyg.");
        addStyleToColumn(dayOfWeekColumn, 233);
        dayOfWeekColumn.setCellValueFactory(new PropertyValueFactory<>("dayOfWeek"));

        TableColumn<EntryInfoRow, String> workHoursColumn = new TableColumn<>("Godziny");
        addStyleToColumn(workHoursColumn, 233);
        workHoursColumn.setCellValueFactory(new PropertyValueFactory<>("workHours"));

        TableColumn<EntryInfoRow, String> employeeColumn = new TableColumn<>("Pracownik");
        addStyleToColumn(employeeColumn, 234);
        employeeColumn.setCellValueFactory(new PropertyValueFactory<>("employeeName"));

        tableOfEntries.getColumns().addAll(dayOfWeekColumn, workHoursColumn, employeeColumn);
        fillTable();
    }
    private void addStyleToColumn(TableColumn tableColumn, int width){
        tableColumn.setPrefWidth(width);
        tableColumn.setStyle("-fx-alignment: center; -fx-font-size: 16px;");
    }
    private void fillTable() throws IOException, InterruptedException {
        getListOfEntries();
        for(int i=0; i<listOfEntries.size(); i++) {
            tableOfEntries.getItems().add(new EntryInfoRow(listOfEntries.get(i).entryId, listOfEntries.get(i).dayOfWeek,
                    listOfEntries.get(i).workHours, listOfEntries.get(i).employeeName));
        }
    }

    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(reservationsButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(insertSeanceButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(insertMovieButton);
        templateWindow.addToPane(workScheduleButton);
        templateWindow.addToPane(separatorLine3);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(employeeWorkScheduleLabel);
        templateWindow.addToPane(tableOfEntries);

    }
    private void getListOfEntries() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(20, new Entry("0,0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfEntries = (LinkedList<Entry>) activeSocketClient.lastMessage.object;
    }

    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public void setLogin(String login){
        this.login = login;
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }

}

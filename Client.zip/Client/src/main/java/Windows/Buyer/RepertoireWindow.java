package Windows.Buyer;

import Client.ActiveSocketClient;
import ForTables.EmployeeInfoRow;
import ForTables.RepertoireInfoRow;
import GUIAddons.*;
import ForQueries.Message;
import ForQueries.Movie;
import ForQueries.RepertoireRow;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;

public class RepertoireWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton repertoireButton, clientReservationsButton, changePasswordButton, aboutUsButton, signInButton, logoutButton;
    CustomButton reservationsButton, insertSeanceButton, insertMovieButton, workScheduleButton;
    SeparatorLineLabel separatorLine1, separatorLine3, separatorLine2;
    CustomLabel listOfSeancesLabel;
    ActiveSocketClient activeSocketClient;
    String login;
    int typeOfUser;
    TableView tableOfRepertoire;
    LinkedList<RepertoireRow> listOfRepertoireRows;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        RepertoireInfoRow.setSocket(this.activeSocketClient);
        RepertoireInfoRow.setStage(stage);
        RepertoireInfoRow.setTypeOfUser(this.typeOfUser);
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setTableOfRepertoire();
        templateWindow.start(stage);

        addAllElements(templateWindow);
    }

    private void setAllButtons(Stage stage) {
        if(typeOfUser == 0){
            setRepertoireButton(stage);
            setChangePasswordButton(stage);
            setAboutUsButton(stage);
            setSignInButton(stage);
        }
        if(typeOfUser == 1) {
            setRepertoireButton(stage);
            setClientReservationsButton(stage);
            setAboutUsButton(stage);
            setLogoutButton(stage);
        }else if(typeOfUser == 2){
            setReservationsButton(stage);
            setInsertSeanceButton(stage);
            setInsertMovieButton(stage);
            setWorkScheduleButton(stage);
            setLogoutButton(stage);
        }
    }

    private void setAllSeparators() {
        separatorLine1 = new SeparatorLineLabel(152, 20);
        separatorLine2 = new SeparatorLineLabel(312,20);
        if(typeOfUser != 2){
            separatorLine3 = new SeparatorLineLabel(1042+typeOfUser*20,20);
        }
        else{
            separatorLine3 = new SeparatorLineLabel(1062,20);
        }
    }

    private void setAllLabels() {
        listOfSeancesLabel = new CustomLabel("Lista seansów", 525, 140, 24);
    }

    private void setRepertoireButton(Stage stage) {
        repertoireButton = new CustomButton("Repertuar", 0, 0, 150, 79, 20, "#E2202C");
    }
    private void setClientReservationsButton(Stage stage) {
        clientReservationsButton = new CustomButton("Rezerwacje", 160, 0, 150, 79, 20);
        clientReservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnClientReservationsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setChangePasswordButton(Stage stage){
        changePasswordButton = new CustomButton("Zmień hasło", 160,0, 150, 79,20);
        changePasswordButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnChangePasswordWindow(this.activeSocketClient, stage);
        });
    }
    private void setAboutUsButton(Stage stage) {
        aboutUsButton = new CustomButton("O nas", 920 + typeOfUser*20, 0, 120, 79, 20);
        aboutUsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnAboutUsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }

    private void setReservationsButton(Stage stage){
        reservationsButton = new CustomButton("Rezerwacje",0,0,150,79,20);
        reservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnReservationsWindow(activeSocketClient, stage, this.login, 2);
        });
    }
    private void setInsertSeanceButton(Stage stage){
        insertSeanceButton = new CustomButton("Dodaj seans", 160, 0, 150, 79, 20);
        insertSeanceButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertSeanceWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setInsertMovieButton(Stage stage){
        insertMovieButton = new CustomButton("Dodaj film", 320, 0, 140, 79, 20);
        insertMovieButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertMovieWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Grafik", 960, 0, 100, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnScheduleForEmployeeWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setSignInButton(Stage stage){
        signInButton = new CustomButton("Zaloguj się", 1050,0, 150, 79, 20);
        signInButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setLogoutButton(Stage stage) {
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setTableOfRepertoire() throws IOException, InterruptedException {
        tableOfRepertoire = new TableView();
        tableOfRepertoire.setLayoutX(200);
        tableOfRepertoire.setLayoutY(200);
        tableOfRepertoire.setPrefWidth(800);
        tableOfRepertoire.setPrefHeight(520);
        tableOfRepertoire.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        setTableColumns();
    }
    private void setTableColumns() throws IOException, InterruptedException {

        TableColumn<EmployeeInfoRow, String> titleColumn = new TableColumn<>("Tytuł filmu");
        addStyleToColumn(titleColumn);
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("movieTitle"));

        TableColumn<EmployeeInfoRow, String> directorColumn = new TableColumn<>("Reżyser");
        addStyleToColumn(directorColumn);
        directorColumn.setCellValueFactory(new PropertyValueFactory<>("movieDirector"));

        TableColumn<EmployeeInfoRow, Integer> yearColumn = new TableColumn<>("Rok produkcji");
        addStyleToColumn(yearColumn);
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("yearOfProduction"));

        TableColumn<EmployeeInfoRow, String> genreColumn = new TableColumn<>("Gatunek");
        addStyleToColumn(genreColumn);
        genreColumn.setCellValueFactory(new PropertyValueFactory<>("movieGenre"));

        TableColumn<EmployeeInfoRow, CustomButton> reservationButtonColumn = new TableColumn<>("");
        addStyleToColumn(reservationButtonColumn);
        reservationButtonColumn.setCellValueFactory(new PropertyValueFactory<>("reservationButton"));

        tableOfRepertoire.getColumns().addAll(titleColumn, yearColumn, directorColumn,genreColumn, reservationButtonColumn);
        fillTable();
    }

    private void fillTable() throws IOException, InterruptedException {
        getListOfRepertoireRows();
        for(int i=0; i<listOfRepertoireRows.size(); i++){
            tableOfRepertoire.getItems().add(new RepertoireInfoRow(this.login, listOfRepertoireRows.get(i).movieId, listOfRepertoireRows.get(i).movieTitle, listOfRepertoireRows.get(i).yearOfProduction,
                    listOfRepertoireRows.get(i).movieDirector, listOfRepertoireRows.get(i).movieGenre));

        }
    }
    private void addStyleToColumn(TableColumn tableColumn){
        tableColumn.setStyle("-fx-alignment: center; -fx-font-size: 16px;");
    }
    private void addAllElements(TemplateWindow templateWindow) {
        if(typeOfUser == 0){
            templateWindow.addToPane(repertoireButton);
            templateWindow.addToPane(changePasswordButton);
            templateWindow.addToPane(aboutUsButton);
            templateWindow.addToPane(signInButton);
        }
        if(typeOfUser == 1){
            templateWindow.addToPane(repertoireButton);
            templateWindow.addToPane(clientReservationsButton);
            templateWindow.addToPane(aboutUsButton);
            templateWindow.addToPane(logoutButton);
        }else if(typeOfUser == 2){
            templateWindow.addToPane(reservationsButton);
            templateWindow.addToPane(insertSeanceButton);
            templateWindow.addToPane(separatorLine2);
            templateWindow.addToPane(insertMovieButton);
            templateWindow.addToPane(workScheduleButton);
            templateWindow.addToPane(logoutButton);
        }
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(separatorLine3);

        templateWindow.addToPane(listOfSeancesLabel);
        templateWindow.addToPane(tableOfRepertoire);
    }

    private void getListOfRepertoireRows() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(5, new Movie("0,0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime+200);
        listOfRepertoireRows = (LinkedList<RepertoireRow>) activeSocketClient.lastMessage.object;
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene() {
        return templateWindow.getScene();
    }
    public void setLogin(String login){
        this.login = login;
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }
}
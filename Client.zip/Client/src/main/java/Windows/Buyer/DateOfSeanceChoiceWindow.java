package Windows.Buyer;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.SeanceCharacteristics;
import ForQueries.Message;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.LinkedList;


public class DateOfSeanceChoiceWindow extends Application {
    double finalPrice = 0.0;

    TemplateWindow templateWindow;
    CustomButton repertoireButton, clientReservationsButton, reservationButton, aboutUsButton, logoutButton, continueButton;
    CustomButton reservationsButton, insertSeanceButton, insertMovieButton, workScheduleButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    Label backgroundLabel;
    CustomLabel reservationLabel, ticketTypeLabel, dateOfSeanceLabel, finalPriceLabel;
    CustomComboBox ticketTypesComboBox, dateOfSeancesComboBox;
    ActiveSocketClient activeSocketClient;
    String login;
    int typeOfUser;
    int movieId;
    LinkedList listOfTicketTypes;
    LinkedList<SeanceCharacteristics> listOfDateOfSeances;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setAllComboBoxes();
        templateWindow.start(stage);

        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        if(typeOfUser == 1) {
            setRepertoireButton(stage);
            setClientReservationsButton(stage);
            setReservationButton(stage);
            setAboutUsButton(stage);
        }else if(typeOfUser == 2){
            setReservationsButton(stage);
            setInsertSeanceButton(stage);
            setInsertMovieButton(stage);
            setWorkScheduleButton(stage);
        }
        setLogoutButton(stage);
        setContinueButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(312,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels() {
        reservationLabel = new CustomLabel("Dodawanie rezerwacji", 485, 140, 24);
        backgroundLabel = new Label();
        setLabel(backgroundLabel, 180, 247);
        ticketTypeLabel = new CustomLabel("Bilet", 385, 232, 20);
        dateOfSeanceLabel = new CustomLabel("Data", 385, 302, 20);
        finalPriceLabel = new CustomLabel("Cena:  ", 548, 370, 20);
    }
    private void setAllComboBoxes() throws IOException, InterruptedException {
        getListOfTicketTypes();
        ticketTypesComboBox = new CustomComboBox("Wybierz rodzaj biletu", listOfTicketTypes,450, 225, 300, 45);
        getListOfDateOfSeances();
        dateOfSeancesComboBox = new CustomComboBox("Wybierz datę seansu", listOfDateOfSeances,450, 295, 300, 45);
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        setComboBoxAction(ticketTypesComboBox, dateOfSeancesComboBox, decimalFormat);
        setComboBoxAction(dateOfSeancesComboBox, ticketTypesComboBox, decimalFormat);
    }
    private void setComboBoxAction(CustomComboBox comboBoxToSet, CustomComboBox comboBoxToCheck, DecimalFormat decimalFormat){
        comboBoxToSet.setOnAction((event) -> {
            if(comboBoxToCheck.getValue() != null) {
                int index = dateOfSeancesComboBox.getSelectionModel().getSelectedIndex();
                finalPrice = countFinalPrice((String) ticketTypesComboBox.getValue(), listOfDateOfSeances.get(index).seancePrice);
                finalPriceLabel.setText("Cena: " + decimalFormat.format(finalPrice));
            }
        });
    }

    private void setRepertoireButton(Stage stage){
        repertoireButton = new CustomButton("Repertuar", 0,0, 150, 79,20);
        repertoireButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnRepertoireWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setClientReservationsButton(Stage stage) {
        clientReservationsButton = new CustomButton("Rezerwacje", 160, 0, 150, 79, 20);
        clientReservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnClientReservationsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setReservationButton(Stage stage){
        reservationButton = new CustomButton("Rezerwuj", 320,0, 150, 79,20, "#E2202C");
    }
    private void setAboutUsButton(Stage stage) {
        aboutUsButton = new CustomButton("O nas", 920 + typeOfUser*20, 0, 120, 79, 20);
        aboutUsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnAboutUsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setReservationsButton(Stage stage){
        reservationsButton = new CustomButton("Rezerwacje",0,0,150,79,20);
        reservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnReservationsWindow(activeSocketClient, stage, this.login, 2);
        });
    }
    private void setInsertSeanceButton(Stage stage){
        insertSeanceButton = new CustomButton("Dodaj seans", 160, 0, 150, 79, 20);
        insertSeanceButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertSeanceWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setInsertMovieButton(Stage stage){
        insertMovieButton = new CustomButton("Dodaj film", 320, 0, 140, 79, 20);
        insertMovieButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertMovieWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Grafik", 960, 0, 100, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnScheduleForEmployeeWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setContinueButton(Stage stage){
        continueButton = new CustomButton("Dalej", 500, 450, 200, 60, 20);
        continueButton.setOnAction((event) -> {
            if(dateOfSeancesComboBox.getValue() == null || ticketTypesComboBox.getValue() == null){
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Wprowadź wszystkie dane!");
                Stage stage2 = (Stage) alert.getDialogPane().getScene().getWindow();
                stage2.getIcons().add(new Image(String.valueOf(getClass().getResource("/images/cinema_icon.png"))));
                alert.showAndWait();
            }
            else {
                int index1 = ticketTypesComboBox.getSelectionModel().getSelectedIndex();
                int index2 = dateOfSeancesComboBox.getSelectionModel().getSelectedIndex();
                String ticketType = (String)listOfTicketTypes.get(index1);
                int seanceId = listOfDateOfSeances.get(index2).seanceId;
                WindowsHandler.changeWindowOnHallWindow(this.activeSocketClient, stage, this.login, this.typeOfUser, 0, seanceId, ticketType, finalPrice, false);
            }
        });
    }

    private void setLabel(Label label, int yPosition, int height){
        label.setLayoutX(360);
        label.setLayoutY(yPosition);
        label.setPrefWidth(480);
        label.setPrefHeight(height);

        label.setStyle("-fx-font-family: Roboto;" +
                "-fx-background-color: #282828;" +
                "-fx-font-size: 18px;" +
                "-fx-text-fill: #FFFFFF;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 6px;");
    }

    private void addAllElements(TemplateWindow templateWindow) {
        if(typeOfUser == 1){
            templateWindow.addToPane(repertoireButton);
            templateWindow.addToPane(clientReservationsButton);
            templateWindow.addToPane(reservationButton);
            templateWindow.addToPane(aboutUsButton);
        }else if(typeOfUser == 2){
            templateWindow.addToPane(reservationsButton);
            templateWindow.addToPane(insertSeanceButton);

            templateWindow.addToPane(insertMovieButton);
            templateWindow.addToPane(workScheduleButton);
        }
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(separatorLine3);


        templateWindow.addToPane(reservationLabel);
        templateWindow.addToPane(backgroundLabel);

        templateWindow.addToPane(ticketTypeLabel);
        templateWindow.addToPane(ticketTypesComboBox);

        templateWindow.addToPane(dateOfSeanceLabel);
        templateWindow.addToPane(dateOfSeancesComboBox);

        templateWindow.addToPane(finalPriceLabel);

        templateWindow.addToPane(continueButton);
    }
    private void getListOfTicketTypes(){
        listOfTicketTypes = new LinkedList<>();
        listOfTicketTypes.add("Normalny");
        listOfTicketTypes.add("Ulgowy");
        listOfTicketTypes.add("Studencki");
        listOfTicketTypes.add("Seniorski");
    }
    private void getListOfDateOfSeances() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(6, new SeanceCharacteristics(movieId + ",0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfDateOfSeances = (LinkedList<SeanceCharacteristics>) activeSocketClient.lastMessage.object;
    }
    private double countFinalPrice(String ticketType, double seancePrice){
        switch (ticketType){
            case "Normalny": return seancePrice;
            case "Ulgowy": return seancePrice * 0.75;
            case "Studencki": return seancePrice * 0.7;
            case "Seniorski": return seancePrice * 0.6;
        }
        return 0;
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setLogin(String login){
        this.login = login;
    }
    public void setMovieId(int movieId){
        this.movieId = movieId;
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }
}
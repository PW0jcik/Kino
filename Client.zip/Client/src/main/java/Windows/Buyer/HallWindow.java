package Windows.Buyer;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.Message;
import ForQueries.ReservationToShow;
import ForQueries.Seat;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;

public class HallWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton repertoireButton, clientReservationsButton, reservationButton, aboutUsButton, logoutButton, continueButton;
    CustomButton reservationsButton, insertSeanceButton, insertMovieButton, workScheduleButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    CustomLabel insertReservationLabel;
    Label screenLabel, seatsBackgroundLabel;
    SeatButton [] seatsButtonsArray;
    ActiveSocketClient activeSocketClient;
    String login;
    int typeOfUser;
    int reservationId;
    int seanceId;
    String ticketType;
    double finalPrice;
    int previousButtonNumber, checkedSeatNumber=17;
    boolean isSomethingPressed, isFirstClick=true, isUpdate;
    LinkedList<Seat> listOfOccupiedSeats;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage) throws IOException, InterruptedException {
        if(typeOfUser == 1) {
            setRepertoireButton(stage);
            setClientReservationsButton(stage);
            setReservationButton(stage);
            setAboutUsButton(stage);
        }else if(typeOfUser == 2){
            setReservationsButton(stage);
            setInsertSeanceButton(stage);
            setInsertMovieButton(stage);
            setWorkScheduleButton(stage);
        }
        setLogoutButton(stage);
        setAllSeatButtons();
        setContinueButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(312,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
    }
    private void setAllLabels() {
        insertReservationLabel = new CustomLabel("Dodawanie rezerwacji", 485, 140, 24);
        screenLabel = new Label("EKRAN");
        seatsBackgroundLabel = new Label();
        setScreenLabel();
        setSeatsBackgroundLabel();
    }
    private void setAllSeatButtons() throws IOException, InterruptedException {
        getListOfOccupiedSeats();
        final int space = 5;
        final int seatSize = 50;
        int xPosition = 439;
        int yPosition = 290;
        seatsButtonsArray = new SeatButton[16];
        int i=0;
        for(int y=0; y<4; y++){
            for(int x=0; x<4; x++){
                xPosition += seatSize + space;
                seatsButtonsArray[i] = new SeatButton(i+1, xPosition , yPosition);
                int finalI = i;
                seatsButtonsArray[i].setOnAction((event) -> {
                    isSomethingPressed = true;
                    previousButtonNumber = checkedSeatNumber;
                    if(!isFirstClick){
                        seatsButtonsArray[previousButtonNumber-1].setDisable(false);
                        seatsButtonsArray[previousButtonNumber-1].setStyle(seatsButtonsArray[previousButtonNumber-1].standardButtonStyle);
                    }
                    isFirstClick = false;
                    checkedSeatNumber = seatsButtonsArray[finalI].seatNumber;
                    seatsButtonsArray[finalI].setDisable(true);
                    seatsButtonsArray[finalI].setStyle("-fx-font-family: Roboto;"  +
                            "-fx-border-width: 2px;"  +
                            "-fx-border-radius: 2px;" +
                            "-fx-background-color: #400b0b;" +
                            "-fx-font-size: 20px;" +
                            "-fx-text-fill: #FFFFFF;" +
                            "-fx-opacity: 0.9;" +
                            "-fx-background-insets: 0 0 -1 0, 0, 1, 2;");
                    System.out.println(checkedSeatNumber);
                });
                i++;
            }
            xPosition = 439;
            yPosition += (seatSize + space);
        }
        setAllOccupiedSeats();
    }
    private void setOccupiedSeatButton(SeatButton seatButton){
        seatButton.setDisable(true);
        seatButton.setStyle("-fx-opacity: 0.75; -fx-font-size: 20px;");
    }
    private void setAllOccupiedSeats(){
        for(int i=0; i<listOfOccupiedSeats.size(); i++){
            setOccupiedSeatButton(seatsButtonsArray[listOfOccupiedSeats.get(i).seatId-1]);
        }
    }
    private void setRepertoireButton(Stage stage){
        repertoireButton = new CustomButton("Repertuar", 0,0, 150, 79,20);
        repertoireButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnRepertoireWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setClientReservationsButton(Stage stage) {
        clientReservationsButton = new CustomButton("Rezerwacje", 160, 0, 150, 79, 20);
        clientReservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnClientReservationsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setReservationButton(Stage stage){
        reservationButton = new CustomButton("Rezerwuj", 320,0, 150, 79,20, "#E2202C");
    }
    private void setAboutUsButton(Stage stage) {
        aboutUsButton = new CustomButton("O nas", 920 + typeOfUser*20, 0, 120, 79, 20);
        aboutUsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnAboutUsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setReservationsButton(Stage stage){
        reservationsButton = new CustomButton("Rezerwacje",0,0,150,79,20);
        reservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnReservationsWindow(activeSocketClient, stage, this.login, 2);
        });
    }
    private void setInsertSeanceButton(Stage stage){
        insertSeanceButton = new CustomButton("Dodaj seans", 160, 0, 150, 79, 20);
        insertSeanceButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertSeanceWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setInsertMovieButton(Stage stage){
        insertMovieButton = new CustomButton("Dodaj film", 320, 0, 140, 79, 20);
        insertMovieButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertMovieWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Grafik", 960, 0, 100, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnScheduleForEmployeeWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setContinueButton(Stage stage){
        if(isUpdate) {
            continueButton = new CustomButton("Zatwierdź", 500, 540, 200, 60, 20);
            continueButton.setOnAction((event) -> {
                if(isSomethingPressed) {
                    sendReservationToUpdate();
                    WindowsHandler.changeWindowOnReservationsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
                }
                else{
                    new CustomAlert("Nie wybrano żadnego siedzenia!");
                }
            });
        }
       else {
            continueButton = new CustomButton("Dalej", 500, 540, 200, 60, 20);
            continueButton.setOnAction((event) -> {
                if(isSomethingPressed)
                    WindowsHandler.changeWindowOnReservationSummaryWindow(this.activeSocketClient, stage, this.login, this.typeOfUser, this.seanceId, this.ticketType, this.finalPrice, this.checkedSeatNumber);
                else{
                    new CustomAlert("Nie wybrano żadnego siedzenia!");
                }
            });
        }
    }
    private void setScreenLabel(){
        screenLabel.setLayoutX(300);
        screenLabel.setLayoutY(215);
        screenLabel.setPrefWidth(600);
        screenLabel.setPrefHeight(20);
        screenLabel.setStyle("-fx-font-family: Roboto;" +
                "-fx-background-color: #bab8b8;" +
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #000000;" +
                "-fx-alignment: center;" );
    }
    private void setSeatsBackgroundLabel(){
        seatsBackgroundLabel.setLayoutX(489);
        seatsBackgroundLabel.setLayoutY(285);
        seatsBackgroundLabel.setPrefWidth(225);
        seatsBackgroundLabel.setPrefHeight(225);
        seatsBackgroundLabel.setStyle("-fx-font-family: Roboto;" +
                "-fx-background-color: #282828;" +
                "-fx-font-size: 14px;" +
                "-fx-text-fill: #000000;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 4px;");
    }
    private void addAllElements(TemplateWindow templateWindow) {
        if(typeOfUser == 1){
            templateWindow.addToPane(repertoireButton);
            templateWindow.addToPane(clientReservationsButton);
            templateWindow.addToPane(reservationButton);
            templateWindow.addToPane(aboutUsButton);
        }else if(typeOfUser == 2){
            templateWindow.addToPane(reservationsButton);
            templateWindow.addToPane(insertSeanceButton);

            templateWindow.addToPane(insertMovieButton);
            templateWindow.addToPane(workScheduleButton);
        }
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(separatorLine3);

        templateWindow.addToPane(insertReservationLabel);
        templateWindow.addToPane(screenLabel);
        templateWindow.addToPane(seatsBackgroundLabel);
        templateWindow.addToPane(continueButton);

        for(int i=0; i<16; i++){
            templateWindow.addToPane(seatsButtonsArray[i]);
        }
    }
    private void getListOfOccupiedSeats() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(28, new Seat(String.valueOf(seanceId))));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfOccupiedSeats = (LinkedList<Seat>) activeSocketClient.lastMessage.object;
        System.out.println(listOfOccupiedSeats.size());
    }
    public void sendReservationToUpdate(){
        Message message = new Message(19, new ReservationToShow(this.reservationId + ",0,0,0,0,0," + this.checkedSeatNumber));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setLogin(String login){
        this.login = login;
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }
    public void setReservationId(int reservationId){
        this.reservationId = reservationId;
    }
    public void setSeanceId(int seanceId){
        this.seanceId = seanceId;
    }
    public void setTicketType(String ticketType){
        this.ticketType = ticketType;
    }
    public void setFinalPrice(double finalPrice){
        this.finalPrice = finalPrice;
    }
    public void setIsUpdate(boolean isUpdate){
        this.isUpdate = isUpdate;
    }
}

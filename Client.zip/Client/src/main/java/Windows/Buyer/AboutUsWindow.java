package Windows.Buyer;

import Client.ActiveSocketClient;
import GUIAddons.*;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class AboutUsWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton repertoireButton, clientReservationsButton, changePasswordButton, aboutUsButton, signInButton, logoutButton;
    SeparatorLineLabel separatorLine1, separatorLine2;
    CustomLabel aboutUsLabel;
    Label informationLabel;
    ActiveSocketClient activeSocketClient;
    String login;
    int typeOfUser;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        templateWindow.start(stage);

        addAllElements(templateWindow);
    }

    private void setAllButtons(Stage stage) {
        setRepertoireButton(stage);
        setAboutUsButton(stage);
        if(typeOfUser != 0){
            setClientReservationsButton(stage);
            setLogoutButton(stage);
        }
        else{
            setChangePasswordButton(stage);
            setSignInButton(stage);
        }
    }

    private void setAllSeparators() {
        separatorLine1 = new SeparatorLineLabel(152, 20);
        separatorLine2 = new SeparatorLineLabel(1042+typeOfUser*20,20);
    }

    private void setAllLabels() {
        aboutUsLabel = new CustomLabel("O nas", 570, 140, 24);
        informationLabel = new Label("\t\t\t   Godziny otwarcia: \n\t\t\tPon.-Sob.: 9.00-23.00 \n\t\t\t   Niedz.: nieczynne\n\n" +
                "\t\t      Zachęcamy do kontaktu! \n   \t\t\t  telefon: 123456789 \n  \t\t\tmail: kino@gmail.com\n\n" +
                "Adres: aleja Tysiąclecia Państwa Polskiego 7, Kielce");
        setLabel(informationLabel);
    }

    private void setRepertoireButton(Stage stage) {
        repertoireButton = new CustomButton("Repertuar", 0, 0, 150, 79, 20);
        repertoireButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnRepertoireWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setClientReservationsButton(Stage stage) {
        clientReservationsButton = new CustomButton("Rezerwacje", 160, 0, 150, 79, 20);
        clientReservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnClientReservationsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setChangePasswordButton(Stage stage){
        changePasswordButton = new CustomButton("Zmień hasło", 160,0, 150, 79,20);
        changePasswordButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnChangePasswordWindow(this.activeSocketClient, stage);
        });
    }
    private void setAboutUsButton(Stage stage) {
        aboutUsButton = new CustomButton("O nas", 920 + typeOfUser*20, 0, 120, 79, 20, "#E2202C");
    }
    private void setSignInButton(Stage stage){
        signInButton = new CustomButton("Zaloguj się", 1050,0, 150, 79, 20);
        signInButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setLogoutButton(Stage stage) {
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });

    }

    private void setLabel(Label label){
        label.setLayoutX(350);
        label.setLayoutY(200);
        label.setPrefWidth(500);
        label.setPrefHeight(300);

        label.setStyle("-fx-font-family: Roboto;" +
                "-fx-background-color: #282828;" +
                "-fx-font-size: 18px;" +
                "-fx-text-fill: #FFFFFF;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 4px;");
    }

    private void addAllElements(TemplateWindow templateWindow) {
        templateWindow.addToPane(repertoireButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(aboutUsButton);
        templateWindow.addToPane(separatorLine2);

        if(typeOfUser != 0){
            templateWindow.addToPane(clientReservationsButton);
            templateWindow.addToPane(logoutButton);
        }
        else{
            templateWindow.addToPane(changePasswordButton);
            templateWindow.addToPane(signInButton);
        }
        templateWindow.addToPane(aboutUsLabel);
        templateWindow.addToPane(informationLabel);
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene() {
        return templateWindow.getScene();
    }
    public void setLogin(String login){
        this.login = login;
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }
}
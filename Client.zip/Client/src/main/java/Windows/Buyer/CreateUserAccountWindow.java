package Windows.Buyer;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.ClientAndAccount;
import ForQueries.Message;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import java.io.IOException;

public class CreateUserAccountWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton backToLoginButton, aboutUsButton, createAccountButton, confirmCreateButton;
    SeparatorLineLabel separatorLine1;
    CustomLabel createAccountLabel, firstNameLabel, phoneNumberLabel, eMailLabel, loginLabel, passwordLabel;
    CustomTextField firstNameField, lastNameField, phoneNumberField, eMailField, loginField;
    PasswordField passwordField;
    ActiveSocketClient activeSocketClient;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setAllFields();
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setBackToLoginButton(stage);
        setAboutUsButton(stage);
        setCreateAccountButton(stage);
        setConfirmCreateButton(stage);
    }
    private void setAllSeparators() {
        separatorLine1 = new SeparatorLineLabel(1042,20);
    }
    private void setAllLabels(){
        createAccountLabel = new CustomLabel("Tworzenie konta", 510, 140, 24);
        firstNameLabel = new CustomLabel("Klient", 340, 197, 20);
        phoneNumberLabel = new CustomLabel("Telefon", 340, 252, 20);
        eMailLabel = new CustomLabel("E-mail", 340, 307, 20);
        loginLabel = new CustomLabel("Login", 340, 362, 20);
        passwordLabel = new CustomLabel("Hasło", 340, 417, 20);
    }
    private void setAllFields(){
        firstNameField = new CustomTextField("Imię", 450, 190, 145, 45);
        lastNameField = new CustomTextField("Nazwisko", 605, 190, 145, 45);
        phoneNumberField = new CustomTextField("Numer telefonu", 450, 245, 300, 45);
        eMailField = new CustomTextField("E-mail",450, 300, 300,45);
        loginField  = new CustomTextField("login", 450, 355, 300, 45);
        setPasswordField();
    }

    private void setBackToLoginButton(Stage stage){
        backToLoginButton = new CustomButton("Powrót", 0,0, 140, 79, 20);
        backToLoginButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setAboutUsButton(Stage stage) {
        aboutUsButton = new CustomButton("O nas", 920, 0, 120, 79, 20);
        aboutUsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnAboutUsWindow(this.activeSocketClient, stage, "", 0);
        });
    }
    private void setCreateAccountButton(Stage stage){
        createAccountButton = new CustomButton("Stwórz konto", 1050,0, 150, 79, 20, "#E2202C");
    }
    private void setConfirmCreateButton(Stage stage){
        confirmCreateButton = new CustomButton("Zatwierdź", 500, 480, 200, 60, 20);
        confirmCreateButton.setOnAction((event) -> {
            if((firstNameField.getText() == "") || (lastNameField.getText() == "") || (phoneNumberField.getText() == "") ||
                    (eMailField.getText() == "") || (loginField.getText() == "") || (passwordField.getText() == "")){
                new CustomAlert("Wprowadź wszystykie dane!");
            }
            else {
                try {
                    sendAccountAndClientToCreate(stage);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void setPasswordField(){
        passwordField = new PasswordField();
        passwordField.setPromptText("hasło");
        passwordField.setLayoutX(450);
        passwordField.setLayoutY(410);
        passwordField.setPrefWidth(300);
        passwordField.setPrefHeight(45);
        passwordField.setStyle("-fx-font-size: 14px;");
    }
    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(backToLoginButton);
        templateWindow.addToPane(aboutUsButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(createAccountButton);
        templateWindow.addToPane(createAccountLabel);

        templateWindow.addToPane(firstNameLabel);
        templateWindow.addToPane(firstNameField);
        templateWindow.addToPane(lastNameField);

        templateWindow.addToPane(phoneNumberLabel);
        templateWindow.addToPane(phoneNumberField);

        templateWindow.addToPane(eMailLabel);
        templateWindow.addToPane(eMailField);

        templateWindow.addToPane(loginLabel);
        templateWindow.addToPane(loginField);

        templateWindow.addToPane(passwordLabel);
        templateWindow.addToPane(passwordField);

        templateWindow.addToPane(confirmCreateButton);
    }

    private void sendAccountAndClientToCreate(Stage stage) throws InterruptedException {
        Message message = new Message(22,
                new ClientAndAccount(firstNameField.getText() + "," + lastNameField.getText() +
                        "," + phoneNumberField.getText() + "," + eMailField.getText() + "," + loginField.getText() +
                        "," + passwordField.getText()));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Thread.sleep(TemplateWindow.sleepTime);
        ClientAndAccount clientAndAccount = (ClientAndAccount) activeSocketClient.lastMessage.object;
        if(Integer.valueOf(clientAndAccount.login) != 0){
            new CustomAlert("Podany login jest zajęty!");
        }
        else{
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        }
    }

    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
}
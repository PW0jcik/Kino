package Windows.Buyer;

import Client.ActiveSocketClient;
import ForTables.RepertoireInfoRow;
import ForTables.ReservationInfoRow;
import GUIAddons.*;
import ForQueries.Client;
import ForQueries.Message;
import ForQueries.ReservationToShow;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.LinkedList;

public class ClientReservationsWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton repertoireButton, clientReservationsButton, aboutUsButton, logoutButton;
    SeparatorLineLabel separatorLine1, separatorLine2;
    CustomLabel listOfSeancesLabel;
    TableView tableOfReservations;
    LinkedList<ReservationToShow> listOfReservations;
    ActiveSocketClient activeSocketClient;
    String clientId;
    String login;
    int typeOfUser;


    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        getClientId();
        RepertoireInfoRow.setSocket(this.activeSocketClient);
        RepertoireInfoRow.setStage(stage);
        RepertoireInfoRow.setTypeOfUser(this.typeOfUser);
        setAllButtons(stage);
        setAllSeparators();
        setAllLabels();
        setTableView();
        templateWindow.start(stage);

        addAllElements(templateWindow);
    }

    private void setAllButtons(Stage stage) {
        setRepertoireButton(stage);
        setClientReservationsButton(stage);
        setAboutUsButton(stage);
        setLogoutButton(stage);
    }

    private void setAllSeparators() {
        separatorLine1 = new SeparatorLineLabel(152, 20);
        separatorLine2 = new SeparatorLineLabel(1062,20);
    }

    private void setAllLabels() {
        listOfSeancesLabel = new CustomLabel("Twoje rezerwacje", 512, 140, 24);
    }

    private void setRepertoireButton(Stage stage) {
        repertoireButton = new CustomButton("Repertuar", 0, 0, 150, 79, 20);
        repertoireButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnRepertoireWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setClientReservationsButton(Stage stage) {
        clientReservationsButton = new CustomButton("Rezerwacje", 160, 0, 150, 79, 20, "#E2202C");
    }
    private void setAboutUsButton(Stage stage) {
        aboutUsButton = new CustomButton("O nas", 920 + typeOfUser*20, 0, 120, 79, 20);
        aboutUsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnAboutUsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setLogoutButton(Stage stage) {
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });

    }

    private void setTableView() throws IOException, InterruptedException {
        tableOfReservations = new TableView();
        tableOfReservations.setLayoutX(218);
        tableOfReservations.setLayoutY(200);
        tableOfReservations.setPrefWidth(766);
        tableOfReservations.setPrefHeight(520);
        setTableColumns();
    }
    private void setTableColumns() throws IOException, InterruptedException {

        TableColumn<ReservationInfoRow, Integer> idColumn = new TableColumn<>("Id");
        addStyleToColumn(idColumn, 50);
        idColumn.setCellValueFactory(new PropertyValueFactory<>("reservationId"));

        TableColumn<ReservationInfoRow, String> lastNameColumn = new TableColumn<>("Nazwisko");
        addStyleToColumn(lastNameColumn, 130);
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("clientName"));

        TableColumn<ReservationInfoRow, String> dateOfReservationColumn = new TableColumn<>("Data rezerwacji");
        addStyleToColumn(dateOfReservationColumn, 160);
        dateOfReservationColumn.setCellValueFactory(new PropertyValueFactory<>("dateOfReservation"));

        TableColumn<ReservationInfoRow, Integer> seanceIdColumn = new TableColumn<>("Id seansu");
        addStyleToColumn(seanceIdColumn, 81);
        seanceIdColumn.setCellValueFactory(new PropertyValueFactory<>("seanceId"));

        TableColumn<ReservationInfoRow, String> movieTitleColumn = new TableColumn<>("Tytuł filmu");
        addStyleToColumn(movieTitleColumn, 163);
        movieTitleColumn.setCellValueFactory(new PropertyValueFactory<>("movieTitle"));

        TableColumn<ReservationInfoRow, Integer> hallNumberColumn = new TableColumn<>("Sala");
        addStyleToColumn(hallNumberColumn, 90);
        hallNumberColumn.setCellValueFactory(new PropertyValueFactory<>("hallNumber"));

        TableColumn<ReservationInfoRow, Integer> seatNumberColumn = new TableColumn<>("Siedzenie");
        addStyleToColumn(seatNumberColumn, 90);
        seatNumberColumn.setCellValueFactory(new PropertyValueFactory<>("seatNumber"));


        tableOfReservations.getColumns().addAll(idColumn, lastNameColumn, dateOfReservationColumn, seanceIdColumn,
                movieTitleColumn, hallNumberColumn, seatNumberColumn);
        fillTable();
    }
    private void fillTable() throws IOException, InterruptedException {
        getListOfReservations();
        for(int i=0; i<listOfReservations.size(); i++){
            tableOfReservations.getItems().add(new ReservationInfoRow(listOfReservations.get(i).reservationId, listOfReservations.get(i).clientName,
                    listOfReservations.get(i).dateOfReservation, listOfReservations.get(i).seanceId,
                    listOfReservations.get(i).movieTitle, listOfReservations.get(i).hallNumber, listOfReservations.get(i).seatNumber));
        }
    }
    private void addStyleToColumn(TableColumn tableColumn, int width){
        tableColumn.setPrefWidth(width);
        tableColumn.setStyle("-fx-alignment: center; -fx-font-size: 16px;");
    }
    private void addAllElements(TemplateWindow templateWindow) {

        templateWindow.addToPane(repertoireButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(clientReservationsButton);
        templateWindow.addToPane(aboutUsButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(listOfSeancesLabel);
        templateWindow.addToPane(tableOfReservations);

    }
    private void getClientId() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(9, new Client(this.login)));
        Thread.sleep(TemplateWindow.sleepTime);
        this.clientId = String.valueOf(activeSocketClient.lastMessage.object);
    }
    private void getListOfReservations() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(23, new ReservationToShow("0," + this.clientId + ",0,0,0,0,0")));
        Thread.sleep(TemplateWindow.sleepTime);
        listOfReservations = (LinkedList<ReservationToShow>) activeSocketClient.lastMessage.object;
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene() {
        return templateWindow.getScene();
    }
    public void setLogin(String login){
        this.login = login;
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }
}

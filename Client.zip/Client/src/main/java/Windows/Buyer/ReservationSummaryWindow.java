package Windows.Buyer;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.*;
import Windows.WindowsHandler;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.text.DecimalFormat;

public class ReservationSummaryWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton repertoireButton, clientReservationsButton, reservationButton, aboutUsButton, logoutButton, continueButton;
    CustomButton reservationsButton, insertSeanceButton, insertMovieButton, workScheduleButton;
    SeparatorLineLabel separatorLine1, separatorLine2, separatorLine3;
    CustomLabel reservationLabel;
    Label summaryBackgroundLabel, movieTitleLabel, priceLabel;
    HorizontalSeparatorLabel horizontalSeparatorLabel1, horizontalSeparatorLabel2;
    ActiveSocketClient activeSocketClient;
    String clientId, employeeId;
    String login;
    int typeOfUser;
    int seanceId;
    String ticketType;
    double finalPrice;
    int seatNumber;
    ReservationSummary reservationSummary;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        if(typeOfUser == 1) {
            getClientId();
        }else if(typeOfUser == 2) {
            getEmployeeId();
        }
        setAllButtons(stage);
        setAllSeparators();
        getReservationSummaryInfo();
        setAllLabels();

        templateWindow.start(stage);

        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage) throws IOException, InterruptedException {
        if(typeOfUser == 1) {
            setRepertoireButton(stage);
            setClientReservationsButton(stage);
            setReservationButton(stage);
            setAboutUsButton(stage);
        }else if(typeOfUser == 2){
            setReservationsButton(stage);
            setInsertSeanceButton(stage);
            setInsertMovieButton(stage);
            setWorkScheduleButton(stage);
        }
        setLogoutButton(stage);
        setContinueButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(312,20);
        separatorLine3 = new SeparatorLineLabel(1062,20);
        horizontalSeparatorLabel1 = new HorizontalSeparatorLabel(430, 266, 340);
        horizontalSeparatorLabel2 = new HorizontalSeparatorLabel(430, 378, 340);
    }
    private void setAllLabels() {
        reservationLabel = new CustomLabel("Podsumowanie", 518, 140, 24);
        movieTitleLabel = new Label(reservationSummary.movieTitle);
        setLabel(movieTitleLabel,210,60);
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        summaryBackgroundLabel = new Label("\nData: " + reservationSummary.dateOfSeance + " " + reservationSummary.hourOfSeance +
                "\nRodzaj biletu: " + this.ticketType + "\nSala: " + reservationSummary.hallNumber + "  |  Miejsce: " + this.seatNumber + "\n\n-");
        setLabel(summaryBackgroundLabel,210,250);
        priceLabel = new Label("Cena: " + decimalFormat.format(this.finalPrice) + " zl");
        setLabel(priceLabel, 400, 40);
    }

    private void setRepertoireButton(Stage stage){
        repertoireButton = new CustomButton("Repertuar", 0,0, 150, 79,20);
        repertoireButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnRepertoireWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setClientReservationsButton(Stage stage) {
        clientReservationsButton = new CustomButton("Rezerwacje", 160, 0, 150, 79, 20);
        clientReservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnClientReservationsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setReservationButton(Stage stage){
        reservationButton = new CustomButton("Rezerwuj", 320,0, 150, 79,20, "#E2202C");
    }
    private void setAboutUsButton(Stage stage) {
        aboutUsButton = new CustomButton("O nas", 920 + typeOfUser*20, 0, 120, 79, 20);
        aboutUsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnAboutUsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setReservationsButton(Stage stage){
        reservationsButton = new CustomButton("Rezerwacje",0,0,150,79,20);
        reservationsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnReservationsWindow(activeSocketClient, stage, this.login, 2);
        });
    }
    private void setInsertSeanceButton(Stage stage){
        insertSeanceButton = new CustomButton("Dodaj seans", 160, 0, 150, 79, 20);
        insertSeanceButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertSeanceWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setInsertMovieButton(Stage stage){
        insertMovieButton = new CustomButton("Dodaj film", 320, 0, 140, 79, 20);
        insertMovieButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnInsertMovieWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setWorkScheduleButton(Stage stage){
        workScheduleButton = new CustomButton("Grafik", 960, 0, 100, 79, 20);
        workScheduleButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnScheduleForEmployeeWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
        });
    }
    private void setLogoutButton(Stage stage){
        logoutButton = new CustomButton("Wyloguj", 1070, 0, 130, 79, 20);
        logoutButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setContinueButton(Stage stage){
        continueButton = new CustomButton("Zatwierdź", 500, 500, 200, 60, 20);
        continueButton.setOnAction((event) -> {
            sendReservationToInsert();
            if(typeOfUser == 1){
                WindowsHandler.changeWindowOnRepertoireWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
            }
            else{
                WindowsHandler.changeWindowOnReservationsWindow(this.activeSocketClient, stage, this.login, this.typeOfUser);
            }
        });
    }
    private void setLabel(Label label,int yPosition, int height){
        label.setLayoutX(400);
        label.setLayoutY(yPosition);
        label.setPrefWidth(400);
        label.setPrefHeight(height);

        label.setStyle("-fx-font-family: Roboto;" +
                "-fx-background-color: #282828;" +
                "-fx-font-size: 18px;" +
                "-fx-text-fill: #FFFFFF;" +
                "-fx-alignment: center;" +
                "-fx-background-radius: 4px;");
    }
    private void addAllElements(TemplateWindow templateWindow) {
        if(typeOfUser == 1){
            templateWindow.addToPane(repertoireButton);
            templateWindow.addToPane(clientReservationsButton);
            templateWindow.addToPane(reservationButton);
            templateWindow.addToPane(aboutUsButton);
        }else if(typeOfUser == 2){
            templateWindow.addToPane(reservationsButton);
            templateWindow.addToPane(insertSeanceButton);

            templateWindow.addToPane(insertMovieButton);
            templateWindow.addToPane(workScheduleButton);
        }
        templateWindow.addToPane(logoutButton);

        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(separatorLine3);

        templateWindow.addToPane(reservationLabel);
        templateWindow.addToPane(summaryBackgroundLabel);
        templateWindow.addToPane(movieTitleLabel);
        templateWindow.addToPane(horizontalSeparatorLabel1);
        templateWindow.addToPane(horizontalSeparatorLabel2);
        templateWindow.addToPane(priceLabel);

        templateWindow.addToPane(continueButton);
    }

    private void getClientId() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(9, new Client(this.login)));
        Thread.sleep(TemplateWindow.sleepTime);
        this.clientId = String.valueOf(activeSocketClient.lastMessage.object);
    }
    private void getEmployeeId() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(14, new Employee("0,0,0,0,0,0,0," + this.login)));
        Thread.sleep(TemplateWindow.sleepTime);
        Employee employee = (Employee) activeSocketClient.lastMessage.object;
        this.employeeId = String.valueOf(employee.employeeId);
    }

    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setSeanceId(int seanceId){
        this.seanceId = seanceId;
    }
    public void setLogin(String login){
        this.login = login;
    }
    private void getReservationSummaryInfo() throws IOException, InterruptedException {
        activeSocketClient.send(new Message(7, new ReservationSummary(seanceId + ",0,0,0,0," + seatNumber)));
        Thread.sleep(TemplateWindow.sleepTime);
        reservationSummary = (ReservationSummary) activeSocketClient.lastMessage.object;
    }
    public void setTicketType(String ticketType){
        this.ticketType = ticketType;
    }
    public void setFinalPrice(double finalPrice){
        this.finalPrice = finalPrice;
    }
    public void setSeatNumber(int seatNumber){
        this.seatNumber = seatNumber;
    }
    private void sendReservationToInsert(){
        Message message = null;

        switch(ticketType){
            case "Normalny": ticketType = "1";
                break;
            case "Ulgowy": ticketType = "2";
                break;
            case "Studencki": ticketType = "3";
                break;
            case "Seniorski": ticketType = "4";
                break;
        }

        if(typeOfUser == 1){
             message = new Message(8,
                    new ReservationToInsert(this.finalPrice + ",0," + this.clientId + "," + this.seanceId + "," + this.ticketType + "," + this.seatNumber));
        }else if(typeOfUser == 2){
            message = new Message(8,
                    new ReservationToInsert(this.finalPrice + ",0," + 1 + "," + this.seanceId + "," + this.ticketType + "," + this.seatNumber));
        }

        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void setTypeOfUser(int typeOfUser){
        this.typeOfUser = typeOfUser;
    }
}
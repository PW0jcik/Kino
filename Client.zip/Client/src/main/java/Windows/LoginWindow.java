package Windows;

import Client.ActiveSocketClient;
import GUIAddons.*;
import ForQueries.Account;
import ForQueries.Message;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginWindow extends Application {
    TemplateWindow templateWindow;
    CustomLabel signInLabel;
    CustomTextField loginField;
    PasswordField passwordField;
    public CustomButton repertoireButton, changePasswordButton, aboutUsButton, createAccountButton, signInButton;
    SeparatorLineLabel separatorLine1, separatorLine2;

    ActiveSocketClient activeSocketClient;
    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllSeparators();
        signInLabel = new CustomLabel("Logowanie", 540, 175, 24);
        setLoginField(stage);
        setPasswordField(stage);
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setRepertoireButton(stage);
        setChangePasswordButton(stage);
        setAboutUsButton(stage);
        setCreateAccountButton(stage);
        setSignInButton(stage);
    }
    private void setAllSeparators(){
        separatorLine1 = new SeparatorLineLabel(152,20);
        separatorLine2 = new SeparatorLineLabel(1042,20);
    }

    private void setRepertoireButton(Stage stage){
        repertoireButton = new CustomButton("Repertuar", 0,0, 150, 79,20);
        repertoireButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnRepertoireWindow(this.activeSocketClient, stage, "", 0);
        });
    }
    private void setChangePasswordButton(Stage stage){
        changePasswordButton = new CustomButton("Zmień hasło", 160,0, 150, 79,20);
        changePasswordButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnChangePasswordWindow(this.activeSocketClient, stage);
        });
    }
    private void setAboutUsButton(Stage stage) {
        aboutUsButton = new CustomButton("O nas", 920, 0, 120, 79, 20);
        aboutUsButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnAboutUsWindow(this.activeSocketClient, stage, "", 0);
        });
    }
    private void setCreateAccountButton(Stage stage){
        createAccountButton = new CustomButton("Stwórz konto", 1050,0, 150, 79, 20);
        createAccountButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnCreateUserAccountWindow(this.activeSocketClient, stage);
        });
    }

    private void setSignInButton(Stage stage){
        signInButton = new CustomButton("Zaloguj", 525,360, 150, 40, 16);
        signInButton.setOnAction((event) -> {
            getSignInButtonAction(stage);
        });
    }
    private void getSignInButtonAction(Stage stage){
        System.out.println("Zaloguj!");
        sendSignInData();
        threadSleep();
        setTypeOfUser(stage);
    }

    private void setLoginField(Stage stage){
        loginField = new CustomTextField("Login", 450,235, 300, 45);
        loginField.setOnKeyPressed((event) -> {
            if (event.getCode().equals(KeyCode.ENTER)) {
                getSignInButtonAction(stage);
            }
        });
    }
    private void setPasswordField(Stage stage){
        passwordField = new PasswordField();
        passwordField.setPromptText("Hasło");
        passwordField.setLayoutX(450);
        passwordField.setLayoutY(290);
        passwordField.setPrefWidth(300);
        passwordField.setPrefHeight(45);
        passwordField.setStyle("-fx-font-size: 14px;");
        passwordField.setOnKeyPressed((event) -> {
            if (event.getCode().equals(KeyCode.ENTER)) {
                getSignInButtonAction(stage);
            }
        });
    }

    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(repertoireButton);
        templateWindow.addToPane(separatorLine1);
        templateWindow.addToPane(changePasswordButton);
        templateWindow.addToPane(aboutUsButton);
        templateWindow.addToPane(separatorLine2);
        templateWindow.addToPane(createAccountButton);

        templateWindow.addToPane(signInLabel);
        templateWindow.addToPane(loginField);
        templateWindow.addToPane(passwordField);
        templateWindow.addToPane(signInButton);
    }


    private void sendSignInData(){
        Message message = new Message(0,
                new Account(loginField.getText() + "," + passwordField.getText() + ",0"));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void setTypeOfUser(Stage stage){
        Account account = (Account) activeSocketClient.lastMessage.object;
        switch(account.privileges){
            case 1: WindowsHandler.changeWindowOnRepertoireWindow(this.activeSocketClient, stage, loginField.getText(), 1);
                break;
            case 2: WindowsHandler.changeWindowOnReservationsWindow(this.activeSocketClient, stage, loginField.getText(), 2);
                break;
            case 3: WindowsHandler.changeWindowOnEmployeeListWindow(this.activeSocketClient, stage);
                break;
            default: {
                new CustomAlert("Nieprawidłowe dane!");
            }
        }
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
    public void threadSleep(){
        try {
            Thread.sleep(TemplateWindow.sleepTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }



}

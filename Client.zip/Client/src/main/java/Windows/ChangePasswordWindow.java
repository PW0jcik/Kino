package Windows;

import Client.ActiveSocketClient;
import ForQueries.ChangePassword;
import ForQueries.Message;
import GUIAddons.*;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import java.io.IOException;

public class ChangePasswordWindow extends Application {
    TemplateWindow templateWindow;
    CustomButton backToLoginButton, confirmChangeButton;
    CustomLabel changePasswordLabel, loginLabel, oldPasswordLabel, newPasswordLabel;
    CustomTextField loginField;
    PasswordField oldPasswordField, newPasswordField;
    ActiveSocketClient activeSocketClient;

    @Override
    public void start(Stage stage) throws Exception {
        templateWindow = new TemplateWindow();
        setAllButtons(stage);
        setAllLabels();
        setAllFields();
        templateWindow.start(stage);
        addAllElements(templateWindow);
    }
    private void setAllButtons(Stage stage){
        setBackToLoginButton(stage);
        setConfirmChangeButton(stage);
    }
    private void setAllLabels(){
        changePasswordLabel = new CustomLabel("Zmiana hasła", 530, 140, 24);
    }
    private void setAllFields(){
        loginField = new CustomTextField("Login", 450, 210, 300, 45);
        oldPasswordField = new PasswordField();
        setPasswordField(oldPasswordField, "Stare hasło", 450, 270);
        newPasswordField = new PasswordField();
        setPasswordField(newPasswordField, "Nowe hasło", 450, 330);
    }

    private void setBackToLoginButton(Stage stage){
        backToLoginButton = new CustomButton("Powrót", 0,0, 140, 79, 20);
        backToLoginButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        });
    }
    private void setConfirmChangeButton(Stage stage){
        confirmChangeButton = new CustomButton("Zatwierdź", 500, 430, 200, 60, 20);
        confirmChangeButton.setOnAction((event) -> {
            if((loginField.getText() == "") || (oldPasswordField.getText() == "") || (newPasswordField.getText() == "")){
                new CustomAlert("Wprowadź wszystykie dane!");
            }
            else{
                try {
                    sendChangePasswordData(stage);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void setPasswordField(PasswordField passwordField, String promptText, int xPosition, int yPosition){
        passwordField.setPromptText(promptText);
        passwordField.setLayoutX(xPosition);
        passwordField.setLayoutY(yPosition);
        passwordField.setPrefWidth(300);
        passwordField.setPrefHeight(45);
        passwordField.setStyle("-fx-font-size: 14px;");
    }
    private void addAllElements(TemplateWindow templateWindow){
        templateWindow.addToPane(backToLoginButton);

        templateWindow.addToPane(changePasswordLabel);

        templateWindow.addToPane(loginField);

        templateWindow.addToPane(oldPasswordField);

        templateWindow.addToPane(newPasswordField);

        templateWindow.addToPane(confirmChangeButton);
    }
    private void sendChangePasswordData(Stage stage) throws InterruptedException {
        Message message = new Message(29,
                new ChangePassword(loginField.getText() + "," + oldPasswordField.getText() + "," + newPasswordField.getText()));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Thread.sleep(TemplateWindow.sleepTime);
        ChangePassword changePassword = (ChangePassword) activeSocketClient.lastMessage.object;

        if(Integer.valueOf(changePassword.newPassword) == 0){
            System.out.println(changePassword.newPassword);
            new CustomAlert("Niepoprawne dane!");
        }
        else{
            WindowsHandler.changeWindowOnLoginWindow(this.activeSocketClient, stage);
        }
    }
    public Scene getScene(){
        return templateWindow.getScene();
    }
    public void setSocket(ActiveSocketClient activeSocketClient){
        this.activeSocketClient = activeSocketClient;
    }
}
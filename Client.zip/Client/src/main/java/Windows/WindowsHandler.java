package Windows;

import Client.ActiveSocketClient;
import ForTables.RepertoireInfoRow;
import Windows.Buyer.*;
import Windows.Employee.InsertMovieWindow;
import Windows.Employee.InsertSeanceWindow;
import Windows.Employee.ReservationsWindow;
import Windows.Employee.ScheduleForEmployeeWindow;
import Windows.Owner.*;
import javafx.stage.Stage;

import java.io.IOException;

public class WindowsHandler {
    // For all
    public static void changeWindowOnLoginWindow(ActiveSocketClient activeSocketClient, Stage stage){
        LoginWindow loginWindow = new LoginWindow();
        loginWindow.setSocket(activeSocketClient);
        try {
            loginWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(loginWindow.getScene());
    }
    public static void changeWindowOnChangePasswordWindow(ActiveSocketClient activeSocketClient, Stage stage){
        ChangePasswordWindow changePasswordWindow = new ChangePasswordWindow();
        changePasswordWindow.setSocket(activeSocketClient);
        try {
            changePasswordWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(changePasswordWindow.getScene());
    }
    /*  -----------------------  */

    // Buyer
    public static void changeWindowOnClientReservationsWindow(ActiveSocketClient activeSocketClient, Stage stage, String login, int typeOfUser){
        ClientReservationsWindow clientReservationsWindow = new ClientReservationsWindow();
        clientReservationsWindow.setSocket(activeSocketClient);
        clientReservationsWindow.setLogin(login);
        clientReservationsWindow.setTypeOfUser(typeOfUser);
        try {
            clientReservationsWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(clientReservationsWindow.getScene());
    }
    public static void changeWindowOnAboutUsWindow(ActiveSocketClient activeSocketClient, Stage stage, String login, int typeOfUser){
        AboutUsWindow aboutUsWindow = new AboutUsWindow();
        aboutUsWindow.setSocket(activeSocketClient);
        aboutUsWindow.setLogin(login);
        aboutUsWindow.setTypeOfUser(typeOfUser);
        try {
            aboutUsWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(aboutUsWindow.getScene());
    }
    public static void changeWindowOnCreateUserAccountWindow(ActiveSocketClient activeSocketClient, Stage stage){
        CreateUserAccountWindow createUserAccountWindow = new CreateUserAccountWindow();
        createUserAccountWindow.setSocket(activeSocketClient);
        try {
            createUserAccountWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(createUserAccountWindow.getScene());
    }
    public static void changeWindowOnDateOfSeanceChoiceWindow(Stage stage, String login, int typeOfUser, int movieId) throws IOException {
        DateOfSeanceChoiceWindow dateOfSeanceChoiceWindow = new DateOfSeanceChoiceWindow();
        dateOfSeanceChoiceWindow.setSocket(RepertoireInfoRow.activeSocketClient);
        dateOfSeanceChoiceWindow.setLogin(login);
        dateOfSeanceChoiceWindow.setTypeOfUser(typeOfUser);
        dateOfSeanceChoiceWindow.setMovieId(movieId);
        try {
            dateOfSeanceChoiceWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(dateOfSeanceChoiceWindow.getScene());
    }
    public static void changeWindowOnHallWindow(ActiveSocketClient activeSocketClient, Stage stage, String login, int typeOfUser, int reservationId, int seanceId, String ticketType, double finalPrice, boolean isUpdate){
        HallWindow hallWindow = new HallWindow();
        hallWindow.setSocket(activeSocketClient);
        hallWindow.setLogin(login);
        hallWindow.setTypeOfUser(typeOfUser);
        hallWindow.setReservationId(reservationId);
        hallWindow.setSeanceId(seanceId);
        hallWindow.setTicketType(ticketType);
        hallWindow.setFinalPrice(finalPrice);
        hallWindow.setIsUpdate(isUpdate);
        try {
            hallWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(hallWindow.getScene());
    }
    public static void changeWindowOnRepertoireWindow(ActiveSocketClient activeSocketClient, Stage stage, String login, int typeOfUser){
        RepertoireWindow repertoireWindow = new RepertoireWindow();
        repertoireWindow.setSocket(activeSocketClient);
        repertoireWindow.setLogin(login);
        repertoireWindow.setTypeOfUser(typeOfUser);
        try {
            repertoireWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(repertoireWindow.getScene());
    }
    public static void changeWindowOnReservationSummaryWindow(ActiveSocketClient activeSocketClient, Stage stage, String login, int typeOfUser, int seanceId, String ticketType, double finalPrice, int seatNumber){
        ReservationSummaryWindow reservationSummaryWindow = new ReservationSummaryWindow();
        reservationSummaryWindow.setSocket(activeSocketClient);
        reservationSummaryWindow.setLogin(login);
        reservationSummaryWindow.setTypeOfUser(typeOfUser);
        reservationSummaryWindow.setSeanceId(seanceId);
        reservationSummaryWindow.setTicketType(ticketType);
        reservationSummaryWindow.setFinalPrice(finalPrice);
        reservationSummaryWindow.setSeatNumber(seatNumber);
        try {
            reservationSummaryWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(reservationSummaryWindow.getScene());
    }
    /*  -----------------------  */

    // Employee
    public static void changeWindowOnInsertMovieWindow(ActiveSocketClient activeSocketClient, Stage stage, String login, int typeOfUser){
        InsertMovieWindow insertMovieWindow = new InsertMovieWindow();
        insertMovieWindow.setSocket(activeSocketClient);
        insertMovieWindow.setLogin(login);
        insertMovieWindow.setTypeOfUser(typeOfUser);
        try {
            insertMovieWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(insertMovieWindow.getScene());
    }
    public static void changeWindowOnInsertSeanceWindow(ActiveSocketClient activeSocketClient, Stage stage, String login, int typeOfUser){
        InsertSeanceWindow insertSeanceWindow = new InsertSeanceWindow();
        insertSeanceWindow.setSocket(activeSocketClient);
        insertSeanceWindow.setLogin(login);
        insertSeanceWindow.setTypeOfUser(typeOfUser);
        try {
            insertSeanceWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(insertSeanceWindow.getScene());
    }
    public static void changeWindowOnReservationsWindow(ActiveSocketClient activeSocketClient, Stage stage, String login, int typeOfUser){
        ReservationsWindow reservationsWindow = new ReservationsWindow();
        reservationsWindow.setSocket(activeSocketClient);
        reservationsWindow.setLogin(login);
        reservationsWindow.setTypeOfUser(typeOfUser);
        try {
            reservationsWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(reservationsWindow.getScene());
    }
    public static void changeWindowOnScheduleForEmployeeWindow(ActiveSocketClient activeSocketClient, Stage stage, String login, int typeOfUser){
        ScheduleForEmployeeWindow scheduleForEmployeeWindow = new ScheduleForEmployeeWindow();
        scheduleForEmployeeWindow.setSocket(activeSocketClient);
        scheduleForEmployeeWindow.setLogin(login);
        scheduleForEmployeeWindow.setTypeOfUser(typeOfUser);
        try {
            scheduleForEmployeeWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(scheduleForEmployeeWindow.getScene());
    }
    /*  -----------------------  */

    // Owner
    public static void changeWindowOnEmployeeListWindow(ActiveSocketClient activeSocketClient, Stage stage){
        EmployeeListWindow employeeListWindow = new EmployeeListWindow();
        employeeListWindow.setSocket(activeSocketClient);
        try {
            employeeListWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(employeeListWindow.getScene());
    }
    public static void changeWindowOnEmployeesWorkScheduleWindow(ActiveSocketClient activeSocketClient, Stage stage){
        EmployeesWorkScheduleWindow setEmployeeScheduleWindow = new EmployeesWorkScheduleWindow();
        setEmployeeScheduleWindow.setSocket(activeSocketClient);
        try {
            setEmployeeScheduleWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(setEmployeeScheduleWindow.getScene());
    }
    public static void changeWindowOnInsertEmployeeWindow(ActiveSocketClient activeSocketClient, Stage stage){
        InsertEmployeeWindow insertEmployeeWindow = new InsertEmployeeWindow();
        insertEmployeeWindow.setSocket(activeSocketClient);
        try {
            insertEmployeeWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(insertEmployeeWindow.getScene());
    }
    public static void changeWindowOnStatisticsWindow(ActiveSocketClient activeSocketClient, Stage stage){
        StatisticsWindow statisticsWindow = new StatisticsWindow();
        statisticsWindow.setSocket(activeSocketClient);
        try {
            statisticsWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(statisticsWindow.getScene());
    }
    public static void changeWindowOnTicketManagementWindow(ActiveSocketClient activeSocketClient, Stage stage){
        TicketManagementWindow ticketManagementWindow = new TicketManagementWindow();
        ticketManagementWindow.setSocket(activeSocketClient);
        try {
            ticketManagementWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(ticketManagementWindow.getScene());
    }
    public static void changeWindowOnUpdateEmployeeSalaryWindow(ActiveSocketClient activeSocketClient, Stage stage, int employeeId, String firstName, String lastName, String dateOfEmployment){
        UpdateEmployeeSalaryWindow updateEmployeeSalaryWindow = new UpdateEmployeeSalaryWindow();
        updateEmployeeSalaryWindow.setSocket(activeSocketClient);
        updateEmployeeSalaryWindow.setEmployeeInfoToUpdate(employeeId, firstName, lastName, dateOfEmployment);
        try {
            updateEmployeeSalaryWindow.start(stage);
        } catch (Exception e) {
            e.printStackTrace();
        }
        stage.setScene(updateEmployeeSalaryWindow.getScene());
    }
    /*  -----------------------  */
}

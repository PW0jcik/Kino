package Client;


import ForQueries.Message;
import javafx.beans.Observable;

import java.io.*;


public class ActiveSocketClient {
    ActiveSocket socket;
    public Message lastMessage = null;
    public ActiveSocketClient() throws IOException {
        try (ActiveSocket socket = new ActiveSocket("localhost", 12245)) {
            this.socket = socket;
                socket.addObserver(new Observer() {
                    @Override
                    public void update(Observable observable, Object arg) {
                        if (arg instanceof Exception) {
                            System.out.println("#Zakonczono polaczenie#");
                        } else {
                            lastMessage = (Message) arg;
                            System.out.println(arg);
                        }
                    }
                });
                socket.start();
            }
    }
    public void send(Object object) throws IOException{
        socket.send(object);
    }
}

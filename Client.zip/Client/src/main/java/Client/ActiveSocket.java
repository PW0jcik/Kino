package Client;

import java.io.*;
import java.net.Socket;

public class ActiveSocket extends Observable implements Runnable, Closeable {
    private Thread thread;
    private Socket socket;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;

    public ActiveSocket(String host, int port) throws IOException{
        this.socket = new Socket(host, port);
        this.outputStream = new ObjectOutputStream(socket.getOutputStream());
        this.inputStream = new ObjectInputStream(socket.getInputStream());
    }

    @Override
    public void run(){
        try{
            while(true){
                notifyObservers(inputStream.readObject());
            }
        } catch(Exception e){
            notifyObservers(e);
        }
    }
    public void send(Object object) throws IOException{
        outputStream.writeObject(object);
    }
    public void start(){
        if(thread == null){
            thread = new Thread(this);
            thread.start();
        }
    }
    @Override
    public void close(){
        if(thread != null){
            thread.interrupt();
        }
    }
}

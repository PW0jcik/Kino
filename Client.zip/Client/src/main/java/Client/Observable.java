package Client;

import javafx.beans.InvalidationListener;

import java.util.ArrayList;
import java.util.Collection;

public class Observable implements javafx.beans.Observable {
    private Collection<Observer> observers = new ArrayList<>();

    public void addObserver(Observer observer){
        observers.add(observer);
    }
    public void removeObserver(Observer observer){
        observers.remove(observer);
    }
    public void notifyObservers(Object arg){
        for(Observer observer : observers){
            observer.update(this, arg);
        }
    }

    @Override
    public void addListener(InvalidationListener invalidationListener) {

    }

    @Override
    public void removeListener(InvalidationListener invalidationListener) {

    }
}

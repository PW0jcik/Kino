package Client;

import javafx.beans.Observable;

public interface Observer {
    void update(Observable observable, Object arg);
}

package ForTables;

import Client.ActiveSocketClient;
import GUIAddons.CustomButton;
import Windows.WindowsHandler;
import javafx.scene.control.Alert;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;

public class RepertoireInfoRow {
    String login;
    int movieId;
    String movieTitle;
    int yearOfProduction;
    String movieDirector;
    String movieGenre;
    CustomButton reservationButton;
    static Stage stage = null;
    public static ActiveSocketClient activeSocketClient = null;
    static int typeOfUser = 0;

    public RepertoireInfoRow(String login, int movieId, String movieTitle, int yearOfProduction, String movieDirector, String movieGenre){
        this.login = login;
        this.movieId = movieId;
        this.movieTitle = movieTitle;
        this.yearOfProduction = yearOfProduction;
        this.movieDirector = movieDirector;
        this.movieGenre = movieGenre;
        reservationButton = new CustomButton("Rezerwuj", 0,0, 100, 30, 14, "#730202", "#ab0707");
        reservationButton.setOnAction((event) -> {
            if(typeOfUser == 0){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
                stage.getIcons().add(new Image(String.valueOf(getClass().getResource("/images/cinema_icon.png"))));
                alert.setHeaderText("Aby złożyć rezerwację musisz być zalogowany.");
                alert.setContentText("");
                alert.showAndWait();
            }
            else{
                try {
                    WindowsHandler.changeWindowOnDateOfSeanceChoiceWindow(RepertoireInfoRow.stage, this.login, this.typeOfUser, this.movieId);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public String getMovieTitle() {
        return movieTitle;
    }
    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public int getYearOfProduction() {
        return yearOfProduction;
    }
    public void setYearOfProduction(int yearOfProduction) {
        this.yearOfProduction = yearOfProduction;
    }

    public String getMovieDirector() {
        return movieDirector;
    }
    public void setMovieDirector(String movieDirector) {
        this.movieDirector = movieDirector;
    }

    public String getMovieGenre() {
        return movieGenre;
    }
    public void setMovieGenre(String movieGenre) {
        this.movieGenre = movieGenre;
    }

    public CustomButton getReservationButton(){
        return reservationButton;
    }
    public void setReservationButton(CustomButton reservationButton){
        this.reservationButton = reservationButton;
    }

    public static void setSocket(ActiveSocketClient activeSocketClient){
        RepertoireInfoRow.activeSocketClient = activeSocketClient;
    }
    public static void setStage(Stage stage){
        RepertoireInfoRow.stage = stage;
    }
    public static void setTypeOfUser(int typeOfUser){
        RepertoireInfoRow.typeOfUser = typeOfUser;
    }

}
package ForTables;

import Client.ActiveSocketClient;
import ForQueries.Message;
import ForQueries.ReservationToShow;
import GUIAddons.CustomButton;
import Windows.WindowsHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;

public class ReservationInfoRow {
    public int reservationId;
    public String clientName;
    public String dateOfReservation;
    public int seanceId;
    public String movieTitle;
    public int hallNumber;
    public int seatNumber;
    CustomButton updateReservationButton, cancelReservationButton;
    HBox actionBox;

    static Stage stage = null;
    static ActiveSocketClient activeSocketClient = null;
    public static String login = "";

    public ReservationInfoRow(int reservationId, String clientName, String dateOfReservation, int seanceId, String movieTitle, int hallNumber, int seatNumber){
        this.reservationId = reservationId;
        this.clientName = clientName;
        this.dateOfReservation = dateOfReservation;
        this.seanceId = seanceId;
        this.movieTitle = movieTitle;
        this.hallNumber = hallNumber;
        this.seatNumber = seatNumber;
        setUpdateReservationButton();
        setCancelReservationButton();
        actionBox = new HBox(5);
        actionBox.getChildren().addAll(updateReservationButton, cancelReservationButton);
    }

    public int getReservationId() {
        return reservationId;
    }
    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public String getClientName() {
        return clientName;
    }
    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getDateOfReservation() {
        return dateOfReservation;
    }
    public void setDateOfReservation(String dateOfReservation) {
        this.dateOfReservation = dateOfReservation;
    }

    public int getSeanceId() {
        return seanceId;
    }
    public void setSeanceId(int seanceId) {
        this.seanceId = seanceId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }
    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public int getHallNumber() {
        return hallNumber;
    }
    public void setHallNumber(int hallNumber) {
        this.hallNumber = hallNumber;
    }

    public int getSeatNumber() {
        return seatNumber;
    }
    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public HBox getActionBox(){
        return actionBox;
    }
    public void setActionBox(CustomButton updateButton){
        this.actionBox = actionBox;
    }

    public static void setSocket(ActiveSocketClient activeSocketClient){
        ReservationInfoRow.activeSocketClient = activeSocketClient;
    }
    public static void setStage(Stage stage){
        ReservationInfoRow.stage = stage;
    }
    public static void setLogin(String login){
        ReservationInfoRow.login = login;
    }
    public void setUpdateReservationButton(){
        updateReservationButton = new CustomButton("Edytuj", 0,0, 60, 30, 14, "#282828", "#383838");
        updateReservationButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnHallWindow(ReservationInfoRow.activeSocketClient, ReservationInfoRow.stage, this.login, 2, this.reservationId, this.seanceId, "", 0, true);
        });
    }
    public void setCancelReservationButton(){
        cancelReservationButton = new CustomButton("Anuluj", 0,0, 60, 30, 14, "#730202", "#ab0707");
        cancelReservationButton.setOnAction((event) -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Na pewno usunac rezerwacje " + this.clientName + "?");
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            stage.getIcons().add(new Image(String.valueOf(getClass().getResource("/images/cinema_icon.png"))));
            Optional<ButtonType> result = alert.showAndWait();
            if(result.get() == ButtonType.OK) {
                sendReservationToRemove();
                WindowsHandler.changeWindowOnReservationsWindow(ReservationInfoRow.activeSocketClient, ReservationInfoRow.stage, login, 2);
            }
            else if(result.get() == ButtonType.CANCEL)
                System.out.println("anulowano");
        });
    }
    public void sendReservationToRemove(){
        Message message = new Message(11,
                new ReservationToShow(this.reservationId + ",0,0,0,0,0,0"));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

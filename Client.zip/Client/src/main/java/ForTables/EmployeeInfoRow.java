package ForTables;


import Client.ActiveSocketClient;
import ForQueries.Employee;
import ForQueries.Message;
import GUIAddons.CustomButton;
import Windows.WindowsHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;

public class EmployeeInfoRow {

    int employeeId;
    String firstName;
    String lastName;
    String dateOfEmployment;
    int salary;
    String employeeLogin;

    CustomButton deleteButton;
    CustomButton updateButton;
    HBox actionBox;

    static Stage stage = null;
    static ActiveSocketClient activeSocketClient = null;

    public EmployeeInfoRow(int employeeId, String firstName, String lastName, String dateOfEmployment, int salary, String employeeLogin){
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfEmployment = dateOfEmployment;
        this.salary = salary;
        this.employeeLogin = employeeLogin;
        setUpdateButton();
        setDeleteButton();
        actionBox = new HBox(5);
        actionBox.getChildren().addAll(updateButton, deleteButton);
    }
    public int getEmployeeId(){
        return employeeId;
    }
    public void setEmployeeId(int employeeId){
        this.employeeId = employeeId;
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDateOfEmployment() {
        return dateOfEmployment;
    }
    public void setDateOfEmployment(String dateOfEmployment) {
        this.dateOfEmployment = dateOfEmployment;
    }

    public int getSalary(){
        return salary;
    }
    public void setSalary(int salary){
        this.salary = salary;
    }

    public HBox getActionBox(){
        return actionBox;
    }
    public void setActionBox(CustomButton updateButton){
        this.actionBox = actionBox;
    }

    public void setUpdateButton(){
        updateButton = new CustomButton("Edytuj", 0,0, 60, 30, 14, "#282828", "#383838");
        updateButton.setOnAction((event) -> {
            WindowsHandler.changeWindowOnUpdateEmployeeSalaryWindow(EmployeeInfoRow.activeSocketClient, EmployeeInfoRow.stage, this.employeeId, this.firstName, this.lastName, this.dateOfEmployment);
        });
    }
    public void setDeleteButton(){
        deleteButton = new CustomButton("Usuń", 0,0, 60, 30, 14, "#730202", "#ab0707");
        deleteButton.setOnAction((event) -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Na pewno usunąć pracownika " + this.firstName.charAt(0) + ". " + this.lastName  + "?");
            Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
            stage.getIcons().add(new Image(String.valueOf(getClass().getResource("/images/cinema_icon.png"))));
            Optional<ButtonType> result = alert.showAndWait();
            if(result.get() == ButtonType.OK) {
                sendEmployeeToRemove();
                WindowsHandler.changeWindowOnEmployeeListWindow(EmployeeInfoRow.activeSocketClient, EmployeeInfoRow.stage);
            }
            else if(result.get() == ButtonType.CANCEL)
                System.out.println("anulowano");
        });
    }
    public void sendEmployeeToRemove(){
        Message message = new Message(17,
                new Employee(this.employeeId + ",0,0,0,0,0,0," + this.employeeLogin));
        try {
            activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void setSocket(ActiveSocketClient activeSocketClient){
        EmployeeInfoRow.activeSocketClient = activeSocketClient;
    }
    public static void setStage(Stage stage){
        EmployeeInfoRow.stage = stage;
    }
}


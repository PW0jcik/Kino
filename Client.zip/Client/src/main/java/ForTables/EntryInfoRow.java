package ForTables;

import Client.ActiveSocketClient;
import ForQueries.Employee;
import ForQueries.Entry;
import ForQueries.Message;
import GUIAddons.CustomButton;
import Windows.WindowsHandler;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;
import java.util.Optional;

public class EntryInfoRow {

    int entryId;
    String dayOfWeek;
    String workHours;
    String employeeName;

    CustomButton entryModifyButton;
    static LinkedList<Employee> listOfEmployees = null;

    static ActiveSocketClient activeSocketClient = null;
    static Stage stage = null;

    public EntryInfoRow(int entryId, String dayOfWeek, String workHours, String employeeName){
        this.entryId = entryId;
        this.dayOfWeek = dayOfWeek;
        this.workHours = workHours;
        this.employeeName = employeeName;

        setEntryModifyButton();
    }


    public int getEntryId(){
        return entryId;
    }
    public void setEntryId(int entryId){
        this.entryId = entryId;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }
    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public String getWorkHours() {
        return workHours;
    }
    public void setWorkHours(String workHours) {
        this.workHours = workHours;
    }

    public String getEmployeeName() {
        return employeeName;
    }
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public CustomButton getEntryModifyButton(){
        return entryModifyButton;
    }
    public void setEntryModifyButton(CustomButton modifyButton){
        this.entryModifyButton = modifyButton;
    }

    public void setEntryModifyButton(){
        entryModifyButton = new CustomButton("Edytuj", 0,0, 90, 30, 14, "#282828", "#383838");
        entryModifyButton.setOnAction((event) -> {
            setChoiceDialog();
        });
    }
    public static void setListOfEmployees(LinkedList<Employee> listOfEmployees){
        EntryInfoRow.listOfEmployees = listOfEmployees;
    }
    public void setChoiceDialog(){
        ChoiceDialog dialog = new ChoiceDialog(listOfEmployees.get(0), listOfEmployees);
        dialog.setTitle("Edycja wpisu");
        dialog.setHeaderText("Wybierz pracownika na zmiane.");
        dialog.setContentText("Pracownik:");
        Stage stage = (Stage) dialog.getDialogPane().getScene().getWindow();
        stage.getIcons().add(new Image(String.valueOf(getClass().getResource("/images/cinema_icon.png"))));

        Optional<ButtonType> result = dialog.showAndWait();

        if(result.isPresent()) {
            String tmp = String.valueOf(result.get());
            String tmp2[] = tmp.split(",");
            sendEntryToUpdate(tmp2[0]);
            WindowsHandler.changeWindowOnEmployeesWorkScheduleWindow(EntryInfoRow.activeSocketClient, EntryInfoRow.stage);
        }
        else {
            System.out.println("anulowano");
        }
    }
    public void sendEntryToUpdate(String employeeId){
        Message message = new Message(21,
                new Entry(this.entryId + ",0,0," + employeeId + ",0"));
        try {
            EmployeeInfoRow.activeSocketClient.send(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void setSocket(ActiveSocketClient activeSocketClient){
        EntryInfoRow.activeSocketClient = activeSocketClient;
    }
    public static void setStage(Stage stage){
        EntryInfoRow.stage = stage;
    }
}

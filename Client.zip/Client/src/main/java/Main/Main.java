package Main;

import Client.ActiveSocketClient;
import Windows.LoginWindow;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
    ActiveSocketClient socket;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        socket = new ActiveSocketClient();
        LoginWindow loginWindow = new LoginWindow();
        loginWindow.setSocket(socket);
        loginWindow.start(stage);
    }
}
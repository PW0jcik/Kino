INSERT INTO dni_tygodnia(nazwa)
VALUES('Poniedzialek');

INSERT INTO dni_tygodnia(nazwa)
VALUES('Wtorek');

INSERT INTO dni_tygodnia(nazwa)
VALUES('Sroda');

INSERT INTO dni_tygodnia(nazwa)
VALUES('Czwartek');

INSERT INTO dni_tygodnia(nazwa)
VALUES('Piatek');

INSERT INTO dni_tygodnia(nazwa)
VALUES('Sobota');

-----------------------------------

INSERT INTO godziny_pracy(poczatek, koniec)
VALUES(9, 16);

INSERT INTO godziny_pracy(poczatek, koniec)
VALUES(16, 23);

-----------------------------------

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('boss', 'boss', 3);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES( 'pracownik1', 'qwerty', 2);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('pracownik2', 'qwerty', 2);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('pracownik3', 'qwerty', 2);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('pracownik4', 'qwerty', 2);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('pracownik5', 'qwerty', 2);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient1', 'qwerty', 1);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient2', 'qwerty', 1);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient3', 'qwerty', 1);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient4', 'qwerty', 1);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient5', 'qwerty', 1);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient6', 'qwerty', 1);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient7', 'qwerty', 1);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient8', 'qwerty', 1);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient9', 'qwerty', 1);

INSERT INTO konta(login, haslo, uprawnienia)
VALUES('klient10', 'qwerty', 1);

-----------------------------------


INSERT INTO pracownicy(nazwisko)
VALUES('BRAK');

INSERT INTO pracownicy(imie, nazwisko, PESEL, data_zatrudnienia, pensja, nr_telefonu, login)
VALUES('Jan', 'Kowalski', 12345678901, TO_DATE('18-10-2020', 'DD-MM-YYYY'), 3000, 111222333, 'pracownik1');

INSERT INTO pracownicy(imie, nazwisko, PESEL, data_zatrudnienia, pensja, nr_telefonu, login)
VALUES('Marcin', 'Nowak', 12345678901, TO_DATE('11-09-2014', 'DD-MM-YYYY'), 3500, 111222333, 'pracownik2');

INSERT INTO pracownicy(imie, nazwisko, PESEL, data_zatrudnienia, pensja, nr_telefonu, login)
VALUES('Malgorzata', 'Wieczorek', 12345678901, TO_DATE('01-01-2021', 'DD-MM-YYYY'), 2700, 111222333, 'pracownik3');

INSERT INTO pracownicy(imie, nazwisko, PESEL, data_zatrudnienia, pensja, nr_telefonu, login)
VALUES('Michal', 'Kwiatkowski', 12345678901, TO_DATE('03-03-2022', 'DD-MM-YYYY'), 2500, 111222333, 'pracownik4');

INSERT INTO pracownicy(imie, nazwisko, PESEL, data_zatrudnienia, pensja, nr_telefonu, login)
VALUES('Andrzej', 'Mucha', 12345678901, TO_DATE('05-03-2019', 'DD-MM-YYYY'), 3100, 111222333, 'pracownik5');
-----------------------------------

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(1, 1, 3);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(1, 1, 4);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(1, 2, 5);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(1, 2, 6);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(2, 1, 2);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(2, 1, 3);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(2, 2, 4);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(2, 2, 5);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(3, 1, 2);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(3, 1, 3);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(3, 2, 4);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(3, 2, 6);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(4, 1, 2);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(4, 1, 4);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(4, 2, 5);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(4, 2, 6);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(5, 1, 2);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(5, 1, 3);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(5, 2, 5);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(5, 2, 6);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(6, 1, 2);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(6, 1, 3);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(6, 2, 4);

INSERT INTO wpisy_pracy(id_dnia, id_godzin_pracy, id_pracownika)
VALUES(6, 2, 5);


-----------------------------------

INSERT INTO klienci(imie, nazwisko)
VALUES('', 'Nasze Kino .');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Sebastian', 'Wysocki', 123456789, 'seb.wysocki@gmail.com', 'klient1');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Kamila', 'Nowak', 987654321, 'dam.nowak@gmail.com', 'klient2');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Adrian', 'Wesoly', 111222333, 'seb.wysocki@gmail.com', 'klient3');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Filip', 'Sienkiewicz', 583023125, 'f.sienk@gmail.com', 'klient4');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Karolina', 'Kowalska', 591023912, 'k.kowalska@gmail.com', 'klient5');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Barbara', 'Malinowska', 503302102, 'bar.malin123@gmail.com', 'klient6');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Marcin', 'Kwiatkowski', 519592192, 'm.kwiatkowski@gmail.com', 'klient7');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Marian', 'Dobrowolski', 510301301, 'mariandobro@gmail.com', 'klient8');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Justyna', 'Malinowska', 403145129, 'j.malinowska@gmail.com', 'klient9');

INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login)
VALUES('Aleksander', 'Siwy', 932123412, 'a.siwy@gmail.com', 'klient10');

-----------------------------------


INSERT INTO typy(nazwa, mnoznik_ceny)
VALUES('Normalny', 1);
INSERT INTO typy(nazwa, mnoznik_ceny)
VALUES('Ulgowy', 0.75);
INSERT INTO typy(nazwa, mnoznik_ceny)
VALUES('Studencki', 0.7);
INSERT INTO typy(nazwa, mnoznik_ceny)
VALUES('Seniorski', 0.6);

-----------------------------------

INSERT INTO gatunki_filmow(nazwa)
VALUES('Akcja');

INSERT INTO gatunki_filmow(nazwa)
VALUES('Dramat');

INSERT INTO gatunki_filmow(nazwa)
VALUES('Horror');

INSERT INTO gatunki_filmow(nazwa)
VALUES('Komedia');

INSERT INTO gatunki_filmow(nazwa)
VALUES('Sci-Fi');

INSERT INTO gatunki_filmow(nazwa)
VALUES('Thriller');

INSERT INTO gatunki_filmow(nazwa)
VALUES('Western');
-----------------------------------

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Batman', 1, 2004, 'Matt Reeves');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('No Time To Die', 1, 2020, 'Cary Fukunaga');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Django', 7, 2012, 'Quentin Tarantino');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Skazani na Shawshank', 2, 1994, 'Frank Darabont');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser) --5
VALUES('Obecnosc', 3, 2013, 'James Wan');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Interstellar', 5, 2014 , 'Christopher Nolan');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Zjawa', 7, 2015, 'Alejandro Gonzalez');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Nienawistna osemka', 7, 2015, 'Quentin Tarantino');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('To', 3, 2017, 'Andy Muschietti');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser) --10
VALUES('John Wick', 6, 2014, 'David Leitch');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Kac Vegas', 4, 2009, 'Todd Phillips');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Kiler', 4, 1997, 'Juliusz Machulski');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Gniew tytanow', 5, 2012, 'Jonathan Liebesman');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Siedmiu wspanialych', 7, 2016, 'Antoine Fuqua');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser) --15
VALUES('Ziarno prawdy', 6, 2015, 'Borys Lankosz');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Igrzyska smierci', 1, 2012, 'Gary Ross');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Transformers', 5, 2007, 'Michael Bay');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Spider-Man', 5, 2002, 'Sam Raimi');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser)
VALUES('Troja', 1, 2004, 'Wolfgang Petersen');

INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser) --20
VALUES('Bohemian Rhapsody', 2, 2018, 'Bryan Singer');


-----------------------------------
INSERT INTO sale(id_sali)
VALUES(1);

INSERT INTO sale(id_sali)
VALUES(2);

INSERT INTO sale(id_sali)
VALUES(3);

-----------------------------------

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('02-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 30, 1, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('03-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 22, 1, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('01-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 24, 1, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('02-08-2022 20:00', 'DD-MM-YYYY HH24:MI'), 23, 1, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('04-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 26, 2, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('05-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 17, 2, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('03-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 26, 2, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('04-08-2022 20:00', 'DD-MM-YYYY HH24:MI'), 20, 2, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('06-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 16, 3, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('07-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 29, 3, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('05-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 21, 3, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('06-08-2022 20:00', 'DD-MM-YYYY HH24:MI'), 19, 3, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('09-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 25, 4, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('10-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 19, 4, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('08-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 18, 4, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('09-08-2022 20:00', 'DD-MM-YYYY HH24:MI'), 18, 4, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('11-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 24, 5, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('12-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 25, 5, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('10-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 26, 5, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('11-08-2022 20:00', 'DD-MM-YYYY HH24:MI'), 26, 5, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('13-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 29, 6, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('14-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 29, 6, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('12-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 20, 6, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('12-08-2022 20:00', 'DD-MM-YYYY HH24:MI'), 23, 6, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('16-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 27, 7, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('17-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 23, 7, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('13-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 27, 7, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('13-08-2022 20:00', 'DD-MM-YYYY HH24:MI'), 21, 7, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('18-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 27, 8, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('19-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 26, 8, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('15-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 19, 8, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('15-08-2022 20:00', 'DD-MM-YYYY HH24:MI'), 23, 8, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('20-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 18, 9, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('21-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 28, 9, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('16-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 29, 9, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('17-08-2022 20:00', 'DD-MM-YYYY HH24:MI'), 30, 9, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('23-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 17, 10, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('24-05-2022 18:30', 'DD-MM-YYYY HH24:MI'), 23, 10, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('18-08-2022 10:30', 'DD-MM-YYYY HH24:MI'), 25, 10, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('18-08-2022  20:00', 'DD-MM-YYYY HH24:MI'), 24, 10, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('25-05-2022 12:00', 'DD-MM-YYYY HH24:MI'), 28, 11, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('01-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 30, 11, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('01-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 27, 11, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('02-10-2022 20:00', 'DD-MM-YYYY HH24:MI'), 22, 11, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('02-04-2022 12:00', 'DD-MM-YYYY HH24:MI'), 29, 12, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('04-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 19, 12, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('04-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 18, 12, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('07-10-2022 20:00', 'DD-MM-YYYY HH24:MI'), 19, 12, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('05-04-2022 12:00', 'DD-MM-YYYY HH24:MI'), 25, 13, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('06-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 24, 13, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('08-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 21, 13, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('10-10-2022 20:00', 'DD-MM-YYYY HH24:MI'), 18, 13, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('07-04-2022 12:00', 'DD-MM-YYYY HH24:MI'), 19, 14, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('08-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 21, 14, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('11-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 30, 14, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('11-10-2022 20:00', 'DD-MM-YYYY HH24:MI'), 23, 14, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('09-04-2022 12:00', 'DD-MM-YYYY HH24:MI'), 16, 15, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('09-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 26, 15, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('14-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 27, 15, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('15-10-2022 20:00', 'DD-MM-YYYY HH24:MI'), 25, 15, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('11-04-2022 12:00', 'DD-MM-YYYY HH24:MI'), 27, 16, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('12-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 21, 16, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('15-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 19, 16, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('15-10-2022 20:00', 'DD-MM-YYYY HH24:MI'), 22, 16, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('15-04-2022 12:00', 'DD-MM-YYYY HH24:MI'), 26, 17, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('15-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 22, 17, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('21-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 23, 17, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('23-10-2022  20:00', 'DD-MM-YYYY HH24:MI'), 23, 17, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('16-04-2022 12:00', 'DD-MM-YYYY HH24:MI'), 17, 18, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('18-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 17, 18, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('24-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 25, 18, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('26-10-2022 20:00', 'DD-MM-YYYY HH24:MI'), 22, 18, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('18-04-2022 12:00', 'DD-MM-YYYY HH24:MI'), 21, 19, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('19-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 20, 19, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('26-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 16, 19, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('28-10-2022 20:00', 'DD-MM-YYYY HH24:MI'), 30, 19, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('20-04-2022 12:00', 'DD-MM-YYYY HH24:MI'), 19, 20, 2);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('21-04-2022 18:30', 'DD-MM-YYYY HH24:MI'), 26, 20, 3);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('29-10-2022 10:30', 'DD-MM-YYYY HH24:MI'), 28, 20, 1);

INSERT INTO seanse(poczatek, cena_pln, id_filmu, id_sali)
VALUES(TO_DATE('29-10-2022 20:00', 'DD-MM-YYYY HH24:MI'), 17, 20, 2);


-----------------------------------

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 13:13', 'DD-MM-YYYY HH24:MI'), 10, 1, 3, 16 );

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 20:15', 'DD-MM-YYYY HH24:MI'), 2, 1, 3, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-03-2022 21:11', 'DD-MM-YYYY HH24:MI'), 3, 1, 4, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 20:15', 'DD-MM-YYYY HH24:MI'), 1, 1, 3, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 20:15', 'DD-MM-YYYY HH24:MI'), 6, 1, 3, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 20:15', 'DD-MM-YYYY HH24:MI'), 9, 1, 3, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 19:35', 'DD-MM-YYYY HH24:MI'), 5, 5, 4, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-03-2022 18:14', 'DD-MM-YYYY HH24:MI'), 6, 5, 4, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-03-2022 12:16', 'DD-MM-YYYY HH24:MI'), 7, 5, 1, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 18:44', 'DD-MM-YYYY HH24:MI'), 9, 5, 4, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 13:28', 'DD-MM-YYYY HH24:MI'), 1, 9, 2, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-03-2022 12:39', 'DD-MM-YYYY HH24:MI'), 2, 9, 1, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 14:21', 'DD-MM-YYYY HH24:MI'), 7, 9, 4, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('23-03-2022 11:38', 'DD-MM-YYYY HH24:MI'), 6, 9, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 21:20', 'DD-MM-YYYY HH24:MI'), 9, 13, 3, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 13:27', 'DD-MM-YYYY HH24:MI'), 3, 13, 1, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-03-2022 19:47', 'DD-MM-YYYY HH24:MI'), 2, 13, 3, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 20:13', 'DD-MM-YYYY HH24:MI'), 6, 13, 3, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 13:52', 'DD-MM-YYYY HH24:MI'), 8, 17, 4, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-03-2022 18:46', 'DD-MM-YYYY HH24:MI'), 5, 17, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 17:43', 'DD-MM-YYYY HH24:MI'), 1, 17, 2, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 17:43', 'DD-MM-YYYY HH24:MI'), 10, 17, 4, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 17:43', 'DD-MM-YYYY HH24:MI'), 4, 17, 3, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 20:46', 'DD-MM-YYYY HH24:MI'), 2, 17, 3, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-03-2022 10:43', 'DD-MM-YYYY HH24:MI'), 1, 21, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 17:11', 'DD-MM-YYYY HH24:MI'), 2, 21, 3, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 20:33', 'DD-MM-YYYY HH24:MI'), 3, 21, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 15:21', 'DD-MM-YYYY HH24:MI'), 4, 21, 3, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 10:57', 'DD-MM-YYYY HH24:MI'), 5, 25, 2, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 16:34', 'DD-MM-YYYY HH24:MI'), 4, 25, 3, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 18:11', 'DD-MM-YYYY HH24:MI'), 1, 25, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 11:36', 'DD-MM-YYYY HH24:MI'), 10, 25, 2, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 14:50', 'DD-MM-YYYY HH24:MI'), 3, 29, 2, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 12:58', 'DD-MM-YYYY HH24:MI'), 1, 29, 2, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 20:36', 'DD-MM-YYYY HH24:MI'), 5, 29, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 21:18', 'DD-MM-YYYY HH24:MI'), 9, 29, 1, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 12:41', 'DD-MM-YYYY HH24:MI'), 8, 33, 1, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 12:16', 'DD-MM-YYYY HH24:MI'), 7, 33, 1, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 18:45', 'DD-MM-YYYY HH24:MI'), 9, 33, 1, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-03-2022 10:28', 'DD-MM-YYYY HH24:MI'), 6, 33, 1, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('23-03-2022 13:11', 'DD-MM-YYYY HH24:MI'), 6, 37, 3, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-03-2022 20:35', 'DD-MM-YYYY HH24:MI'), 7, 37, 3, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 17:14', 'DD-MM-YYYY HH24:MI'), 1, 37, 1, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 18:49', 'DD-MM-YYYY HH24:MI'), 2, 37, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-03-2022 10:37', 'DD-MM-YYYY HH24:MI'), 9, 41, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 15:32', 'DD-MM-YYYY HH24:MI'), 10, 41, 3, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('27-03-2022 10:51', 'DD-MM-YYYY HH24:MI'), 8, 41, 4, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 15:48', 'DD-MM-YYYY HH24:MI'), 6, 41, 4, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 15:45', 'DD-MM-YYYY HH24:MI'), 8, 45, 3, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 15:37', 'DD-MM-YYYY HH24:MI'), 7, 45, 1, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 15:55', 'DD-MM-YYYY HH24:MI'), 5, 45, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 14:56', 'DD-MM-YYYY HH24:MI'), 1, 45, 2, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 21:47', 'DD-MM-YYYY HH24:MI'), 6, 49, 3, 1 );

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-03-2022 14:24', 'DD-MM-YYYY HH24:MI'), 3, 49, 2, 9 );

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 15:28', 'DD-MM-YYYY HH24:MI'), 1, 49, 4, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 10:14', 'DD-MM-YYYY HH24:MI'), 7, 49, 1, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 21:41', 'DD-MM-YYYY HH24:MI'), 8, 53, 3,  1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 18:29', 'DD-MM-YYYY HH24:MI'), 2, 53, 1, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-03-2022 16:26', 'DD-MM-YYYY HH24:MI'), 6, 53, 4, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('27-03-2022 18:32', 'DD-MM-YYYY HH24:MI'), 7, 53, 1, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 16:27', 'DD-MM-YYYY HH24:MI'), 7, 57, 1, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 20:31', 'DD-MM-YYYY HH24:MI'), 9, 57, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 15:31', 'DD-MM-YYYY HH24:MI'), 8, 57, 4, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 21:36', 'DD-MM-YYYY HH24:MI'), 2, 57, 3,  9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 17:41', 'DD-MM-YYYY HH24:MI'), 7, 61, 4, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 15:42', 'DD-MM-YYYY HH24:MI'), 8, 61, 3, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 19:33', 'DD-MM-YYYY HH24:MI'), 1, 61, 1, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 20:20', 'DD-MM-YYYY HH24:MI'), 9, 61, 1, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 17:33', 'DD-MM-YYYY HH24:MI'), 1, 65, 1,  8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 14:14', 'DD-MM-YYYY HH24:MI'), 8, 65, 3, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 15:55', 'DD-MM-YYYY HH24:MI'), 6, 65, 1, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-03-2022 11:41', 'DD-MM-YYYY HH24:MI'), 4, 65, 1, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('23-03-2022 14:30', 'DD-MM-YYYY HH24:MI'), 8, 69, 2, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 10:57', 'DD-MM-YYYY HH24:MI'), 7, 69, 3, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 16:20', 'DD-MM-YYYY HH24:MI'), 9, 69, 2, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 18:41', 'DD-MM-YYYY HH24:MI'), 4, 69, 1, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 18:41', 'DD-MM-YYYY HH24:MI'), 3, 69, 1, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 15:26', 'DD-MM-YYYY HH24:MI'), 8, 73, 2, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 10:57', 'DD-MM-YYYY HH24:MI'), 5, 73, 2, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 11:35', 'DD-MM-YYYY HH24:MI'), 9, 73, 1, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 14:53', 'DD-MM-YYYY HH24:MI'), 2, 73, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 14:30', 'DD-MM-YYYY HH24:MI'), 5, 77, 2, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 12:44', 'DD-MM-YYYY HH24:MI'), 1, 77, 4, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 14:41', 'DD-MM-YYYY HH24:MI'), 10, 77, 4, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 11:15', 'DD-MM-YYYY HH24:MI'), 9, 77, 2, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 14:58', 'DD-MM-YYYY HH24:MI'), 7, 2, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 21:18', 'DD-MM-YYYY HH24:MI'), 8, 2, 3, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 18:25', 'DD-MM-YYYY HH24:MI'), 5, 2, 1, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('23-03-2022 16:19', 'DD-MM-YYYY HH24:MI'), 1, 2, 4, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 18:38', 'DD-MM-YYYY HH24:MI'), 8, 6, 4, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-03-2022 15:47', 'DD-MM-YYYY HH24:MI'), 1, 6, 4, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 16:55', 'DD-MM-YYYY HH24:MI'), 5, 6, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 18:31', 'DD-MM-YYYY HH24:MI'), 10, 6, 1, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 18:40', 'DD-MM-YYYY HH24:MI'), 10, 10, 1, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 17:49', 'DD-MM-YYYY HH24:MI'), 7, 10, 3, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 11:37', 'DD-MM-YYYY HH24:MI'), 8, 10, 4, 11 );

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 17:12', 'DD-MM-YYYY HH24:MI'), 1, 10, 3, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 13:10', 'DD-MM-YYYY HH24:MI'), 4, 14, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-03-2022 19:58', 'DD-MM-YYYY HH24:MI'), 6, 14, 2, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 14:18', 'DD-MM-YYYY HH24:MI'), 2, 14, 1, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-03-2022 16:58', 'DD-MM-YYYY HH24:MI'), 9, 14, 3, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 20:13', 'DD-MM-YYYY HH24:MI'), 2, 18, 1, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 20:43', 'DD-MM-YYYY HH24:MI'), 7, 18, 1, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 21:29', 'DD-MM-YYYY HH24:MI'), 1, 18, 1, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 11:44', 'DD-MM-YYYY HH24:MI'), 3, 18, 3, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 11:44', 'DD-MM-YYYY HH24:MI'), 4, 18, 3, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 18:27', 'DD-MM-YYYY HH24:MI'), 9, 22, 1, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 12:23', 'DD-MM-YYYY HH24:MI'), 8, 22, 2, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 21:34', 'DD-MM-YYYY HH24:MI'), 7, 22, 4, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 19:25', 'DD-MM-YYYY HH24:MI'), 5, 22, 4, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 16:27', 'DD-MM-YYYY HH24:MI'), 5, 26, 4, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 10:33', 'DD-MM-YYYY HH24:MI'), 10, 26, 2, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 12:24', 'DD-MM-YYYY HH24:MI'), 3, 26, 1, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-03-2022 21:30', 'DD-MM-YYYY HH24:MI'), 1, 26, 2, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 18:47', 'DD-MM-YYYY HH24:MI'), 2, 30, 2, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 14:11', 'DD-MM-YYYY HH24:MI'), 3, 30, 1, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-03-2022 18:52', 'DD-MM-YYYY HH24:MI'), 6, 30, 2, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 18:44', 'DD-MM-YYYY HH24:MI'), 9, 30, 3, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('27-03-2022 13:15', 'DD-MM-YYYY HH24:MI'), 10, 34, 1, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-03-2022 19:46', 'DD-MM-YYYY HH24:MI'), 6, 34, 2, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 17:16', 'DD-MM-YYYY HH24:MI'), 4, 34, 2, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 13:39', 'DD-MM-YYYY HH24:MI'), 9, 34, 1, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 15:37', 'DD-MM-YYYY HH24:MI'), 9, 38, 4, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 12:29', 'DD-MM-YYYY HH24:MI'), 7, 38, 2, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 19:26', 'DD-MM-YYYY HH24:MI'), 4, 38, 2, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 14:47', 'DD-MM-YYYY HH24:MI'), 5, 38, 4, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 12:33', 'DD-MM-YYYY HH24:MI'), 8, 42, 3, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 15:31', 'DD-MM-YYYY HH24:MI'), 10, 42, 2, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('23-03-2022 18:35', 'DD-MM-YYYY HH24:MI'), 3, 42, 1, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-03-2022 10:51', 'DD-MM-YYYY HH24:MI'), 4, 42, 3, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-03-2022 11:33', 'DD-MM-YYYY HH24:MI'), 10, 46, 4, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 13:20', 'DD-MM-YYYY HH24:MI'), 5, 46, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 16:24', 'DD-MM-YYYY HH24:MI'), 3, 46, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-03-2022 19:58', 'DD-MM-YYYY HH24:MI'), 4, 46, 4, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 17:27', 'DD-MM-YYYY HH24:MI'), 9, 50, 4, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 20:20', 'DD-MM-YYYY HH24:MI'), 7, 50, 1, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 11:27', 'DD-MM-YYYY HH24:MI'), 10, 50, 1, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 19:18', 'DD-MM-YYYY HH24:MI'), 1, 50, 2, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 17:13', 'DD-MM-YYYY HH24:MI'), 6, 54, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-03-2022 10:16', 'DD-MM-YYYY HH24:MI'), 9, 54, 2, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 11:28', 'DD-MM-YYYY HH24:MI'), 1, 54, 3, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 11:16', 'DD-MM-YYYY HH24:MI'), 7, 54, 1, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 20:52', 'DD-MM-YYYY HH24:MI'), 5, 58, 3, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 11:16', 'DD-MM-YYYY HH24:MI'), 4, 58, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-03-2022 19:37', 'DD-MM-YYYY HH24:MI'), 7, 58, 2, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-03-2022 10:23', 'DD-MM-YYYY HH24:MI'), 3, 58, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-03-2022 15:35', 'DD-MM-YYYY HH24:MI'), 10, 62, 2, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-03-2022 14:46', 'DD-MM-YYYY HH24:MI'), 9, 62, 4, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 16:45', 'DD-MM-YYYY HH24:MI'), 2, 62, 4, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-03-2022 11:23', 'DD-MM-YYYY HH24:MI'), 4, 62, 4, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 14:24', 'DD-MM-YYYY HH24:MI'), 8, 66, 3, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 19:48', 'DD-MM-YYYY HH24:MI'), 1, 66, 1, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-03-2022 13:44', 'DD-MM-YYYY HH24:MI'), 7, 66, 3, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-03-2022 21:18', 'DD-MM-YYYY HH24:MI'), 10, 66, 4, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 10:39', 'DD-MM-YYYY HH24:MI'), 1, 70, 1, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 16:49', 'DD-MM-YYYY HH24:MI'), 7, 70, 1, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-03-2022 19:13', 'DD-MM-YYYY HH24:MI'), 5, 70, 4, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 14:56', 'DD-MM-YYYY HH24:MI'), 6, 70, 1, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-03-2022 18:31', 'DD-MM-YYYY HH24:MI'), 1, 74, 2, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-03-2022 13:51', 'DD-MM-YYYY HH24:MI'), 7, 74, 3, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-03-2022 15:32', 'DD-MM-YYYY HH24:MI'), 8, 74, 4, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-03-2022 12:29', 'DD-MM-YYYY HH24:MI'), 4, 74, 2, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-03-2022 17:46', 'DD-MM-YYYY HH24:MI'), 9, 78, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-03-2022 21:11', 'DD-MM-YYYY HH24:MI'), 7, 78, 1, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-03-2022 17:53', 'DD-MM-YYYY HH24:MI'), 3, 78, 2, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-03-2022 13:14', 'DD-MM-YYYY HH24:MI'), 1, 78, 3, 9);


/**********************************************************/


INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 17:14', 'DD-MM-YYYY HH24:MI'), 6, 3, 2, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-05-2022 14:21', 'DD-MM-YYYY HH24:MI'), 8, 3, 2, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-05-2022 19:47', 'DD-MM-YYYY HH24:MI'), 1, 3, 4, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 11:48', 'DD-MM-YYYY HH24:MI'), 4, 3, 4, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-05-2022 14:31', 'DD-MM-YYYY HH24:MI'), 4, 7, 2, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-05-2022 19:12', 'DD-MM-YYYY HH24:MI'), 9, 7, 1, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 17:17', 'DD-MM-YYYY HH24:MI'), 5, 7, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 17:27', 'DD-MM-YYYY HH24:MI'), 1, 7, 4, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 11:21', 'DD-MM-YYYY HH24:MI'), 4, 11, 1, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('27-05-2022 10:17', 'DD-MM-YYYY HH24:MI'), 1, 11, 3, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 17:12', 'DD-MM-YYYY HH24:MI'), 6, 11, 1, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 11:37', 'DD-MM-YYYY HH24:MI'), 10, 11, 3, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 10:54', 'DD-MM-YYYY HH24:MI'), 5, 15, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 13:51', 'DD-MM-YYYY HH24:MI'), 6, 15, 2, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-05-2022 21:17', 'DD-MM-YYYY HH24:MI'), 4, 15, 1, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-05-2022 13:43', 'DD-MM-YYYY HH24:MI'), 7, 15, 1, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 19:21', 'DD-MM-YYYY HH24:MI'), 4, 19, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 12:21', 'DD-MM-YYYY HH24:MI'), 3, 19, 4, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 16:40', 'DD-MM-YYYY HH24:MI'), 5, 19, 3, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-05-2022 13:39', 'DD-MM-YYYY HH24:MI'), 10, 19, 1, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 11:44', 'DD-MM-YYYY HH24:MI'), 6, 23, 3, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 17:42', 'DD-MM-YYYY HH24:MI'), 7, 23, 2, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-05-2022 16:48', 'DD-MM-YYYY HH24:MI'), 1, 23, 3, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-05-2022 18:48', 'DD-MM-YYYY HH24:MI'), 2, 23, 3, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-05-2022 11:40', 'DD-MM-YYYY HH24:MI'), 4, 27, 4, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 11:54', 'DD-MM-YYYY HH24:MI'), 1, 27, 1, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 17:12', 'DD-MM-YYYY HH24:MI'), 2, 27, 4, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-05-2022 14:47', 'DD-MM-YYYY HH24:MI'), 7, 27, 1, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 18:45', 'DD-MM-YYYY HH24:MI'), 1, 31, 2, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 12:32', 'DD-MM-YYYY HH24:MI'), 6, 31, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('23-05-2022 20:57', 'DD-MM-YYYY HH24:MI'), 10, 31, 4, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('27-05-2022 21:22', 'DD-MM-YYYY HH24:MI'), 9, 31, 1, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-05-2022 15:33', 'DD-MM-YYYY HH24:MI'), 10, 35, 2, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-05-2022 17:39', 'DD-MM-YYYY HH24:MI'), 6, 35, 4, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-05-2022 10:45', 'DD-MM-YYYY HH24:MI'), 1, 35, 4, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 16:25', 'DD-MM-YYYY HH24:MI'), 7, 35, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-05-2022 12:15', 'DD-MM-YYYY HH24:MI'), 10, 39, 1, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 18:19', 'DD-MM-YYYY HH24:MI'), 5, 39, 2, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-05-2022 15:24', 'DD-MM-YYYY HH24:MI'), 1, 39, 4, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 21:12', 'DD-MM-YYYY HH24:MI'), 8, 39, 4, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-05-2022 11:45', 'DD-MM-YYYY HH24:MI'), 6, 43, 1, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-05-2022 18:34', 'DD-MM-YYYY HH24:MI'), 2, 43, 2, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 10:48', 'DD-MM-YYYY HH24:MI'), 7, 43, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 20:29', 'DD-MM-YYYY HH24:MI'), 1, 43, 2, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 14:50', 'DD-MM-YYYY HH24:MI'), 5, 47, 2, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 21:47', 'DD-MM-YYYY HH24:MI'), 2, 47, 1, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-05-2022 15:21', 'DD-MM-YYYY HH24:MI'), 8, 47, 4, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 10:49', 'DD-MM-YYYY HH24:MI'), 1, 47, 2, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 17:55', 'DD-MM-YYYY HH24:MI'), 2, 51, 1, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 12:15', 'DD-MM-YYYY HH24:MI'), 7, 51, 4, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 15:12', 'DD-MM-YYYY HH24:MI'), 10, 51, 4, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 13:39', 'DD-MM-YYYY HH24:MI'), 8, 51, 3, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-05-2022 13:35', 'DD-MM-YYYY HH24:MI'), 5, 55, 2, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-05-2022 12:20', 'DD-MM-YYYY HH24:MI'), 3, 55, 3, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 10:57', 'DD-MM-YYYY HH24:MI'), 7, 55, 4, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 12:41', 'DD-MM-YYYY HH24:MI'), 4, 55, 2, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 12:28', 'DD-MM-YYYY HH24:MI'), 6, 59, 2, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 21:40', 'DD-MM-YYYY HH24:MI'), 9, 59, 3, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 21:23', 'DD-MM-YYYY HH24:MI'), 2, 59, 2, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 11:56', 'DD-MM-YYYY HH24:MI'), 4, 59, 2, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-05-2022 15:10', 'DD-MM-YYYY HH24:MI'), 9, 63, 3, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-05-2022 13:42', 'DD-MM-YYYY HH24:MI'), 3, 63, 4, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 10:31', 'DD-MM-YYYY HH24:MI'), 10, 63, 4, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 17:11', 'DD-MM-YYYY HH24:MI'), 4, 63, 1, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-05-2022 15:43', 'DD-MM-YYYY HH24:MI'), 3, 67, 3, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 12:53', 'DD-MM-YYYY HH24:MI'), 9, 67, 4, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 14:28', 'DD-MM-YYYY HH24:MI'), 6, 67, 1, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 13:26', 'DD-MM-YYYY HH24:MI'), 10, 67, 2, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 16:55', 'DD-MM-YYYY HH24:MI'), 7, 71, 2, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 19:50', 'DD-MM-YYYY HH24:MI'), 4, 71, 4, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-05-2022 14:24', 'DD-MM-YYYY HH24:MI'), 1, 71, 3, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-05-2022 15:36', 'DD-MM-YYYY HH24:MI'), 2, 71, 2, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 10:40', 'DD-MM-YYYY HH24:MI'), 4, 75, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 21:14', 'DD-MM-YYYY HH24:MI'), 3, 75, 1, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 12:58', 'DD-MM-YYYY HH24:MI'), 9, 75, 3, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('23-05-2022 20:31', 'DD-MM-YYYY HH24:MI'), 7, 75, 3, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-05-2022 18:25', 'DD-MM-YYYY HH24:MI'), 4, 79, 2, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-05-2022 20:33', 'DD-MM-YYYY HH24:MI'), 8, 79, 1, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 11:32', 'DD-MM-YYYY HH24:MI'), 5, 79, 3, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-05-2022 15:45', 'DD-MM-YYYY HH24:MI'), 1, 79, 3, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-05-2022 20:44', 'DD-MM-YYYY HH24:MI'), 2, 4, 4, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 20:27', 'DD-MM-YYYY HH24:MI'), 3, 4, 2, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-05-2022 17:17', 'DD-MM-YYYY HH24:MI'), 9, 4, 3, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-05-2022 17:16', 'DD-MM-YYYY HH24:MI'), 4, 4, 2,13 );

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 13:55', 'DD-MM-YYYY HH24:MI'), 4, 8, 2, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 20:33', 'DD-MM-YYYY HH24:MI'), 9, 8, 3, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-05-2022 16:39', 'DD-MM-YYYY HH24:MI'), 10, 8, 2, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-05-2022 11:34', 'DD-MM-YYYY HH24:MI'), 2, 8, 2, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-05-2022 16:36', 'DD-MM-YYYY HH24:MI'), 10, 12, 2, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-05-2022 10:33', 'DD-MM-YYYY HH24:MI'), 5, 12, 1, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-05-2022 12:38', 'DD-MM-YYYY HH24:MI'), 6, 12, 3, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('27-05-2022 15:35', 'DD-MM-YYYY HH24:MI'), 3, 12, 2, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 20:55', 'DD-MM-YYYY HH24:MI'), 8, 16, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 13:29', 'DD-MM-YYYY HH24:MI'), 10, 16, 4, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-05-2022 15:30', 'DD-MM-YYYY HH24:MI'), 1, 16, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 13:10', 'DD-MM-YYYY HH24:MI'), 2, 16, 1, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('14-05-2022 13:10', 'DD-MM-YYYY HH24:MI'), 1, 20, 1,10 );

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-05-2022 16:42', 'DD-MM-YYYY HH24:MI'), 9, 20, 3, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 21:13', 'DD-MM-YYYY HH24:MI'), 3, 20, 3, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 19:42', 'DD-MM-YYYY HH24:MI'), 5, 20, 4, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 19:23', 'DD-MM-YYYY HH24:MI'), 7, 24, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-05-2022 21:49', 'DD-MM-YYYY HH24:MI'), 3, 24, 1, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-05-2022 18:53', 'DD-MM-YYYY HH24:MI'), 9, 24, 4, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 10:16', 'DD-MM-YYYY HH24:MI'), 4, 24, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 17:50', 'DD-MM-YYYY HH24:MI'), 4, 28, 4, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 10:29', 'DD-MM-YYYY HH24:MI'), 3, 28, 1, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('18-05-2022 13:14', 'DD-MM-YYYY HH24:MI'), 7, 28, 1, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-05-2022 10:57', 'DD-MM-YYYY HH24:MI'), 5, 28, 4, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 10:44', 'DD-MM-YYYY HH24:MI'), 1, 32, 1, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 19:21', 'DD-MM-YYYY HH24:MI'), 5, 32, 3, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('23-05-2022 11:58', 'DD-MM-YYYY HH24:MI'), 2, 32, 3, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 20:27', 'DD-MM-YYYY HH24:MI'), 3, 32, 4, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 13:45', 'DD-MM-YYYY HH24:MI'), 7, 36, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 21:22', 'DD-MM-YYYY HH24:MI'), 8, 36, 4, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-05-2022 12:35', 'DD-MM-YYYY HH24:MI'), 10, 36, 3, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-05-2022 19:13', 'DD-MM-YYYY HH24:MI'), 9, 36, 1, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-05-2022 12:50', 'DD-MM-YYYY HH24:MI'), 1, 40, 1, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-05-2022 14:43', 'DD-MM-YYYY HH24:MI'), 5, 40, 2, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-05-2022 16:44', 'DD-MM-YYYY HH24:MI'), 3, 40, 3, 10);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 16:52', 'DD-MM-YYYY HH24:MI'), 2, 40, 4, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 12:41', 'DD-MM-YYYY HH24:MI'), 5, 44, 2, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('26-05-2022 13:26', 'DD-MM-YYYY HH24:MI'), 7, 44, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 21:27', 'DD-MM-YYYY HH24:MI'), 8, 44, 4, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 10:55', 'DD-MM-YYYY HH24:MI'), 2, 44, 2, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-05-2022 18:43', 'DD-MM-YYYY HH24:MI'), 5, 48, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 20:28', 'DD-MM-YYYY HH24:MI'), 2, 48, 2, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 15:29', 'DD-MM-YYYY HH24:MI'), 7, 48, 2, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-05-2022 21:45', 'DD-MM-YYYY HH24:MI'), 9, 48, 1, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 16:52', 'DD-MM-YYYY HH24:MI'), 5, 52, 3, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 16:44', 'DD-MM-YYYY HH24:MI'), 10, 52, 1, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-05-2022 13:23', 'DD-MM-YYYY HH24:MI'), 6, 52, 3, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-05-2022 18:32', 'DD-MM-YYYY HH24:MI'), 3, 52, 3, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-05-2022 20:42', 'DD-MM-YYYY HH24:MI'), 4, 56, 1, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 20:46', 'DD-MM-YYYY HH24:MI'), 8, 56, 1, 8);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('17-05-2022 19:41', 'DD-MM-YYYY HH24:MI'), 6, 56, 3, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-05-2022 19:15', 'DD-MM-YYYY HH24:MI'), 3, 56, 1, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-05-2022 16:49', 'DD-MM-YYYY HH24:MI'), 9, 60, 4, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 21:49', 'DD-MM-YYYY HH24:MI'), 4, 60, 1, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 16:25', 'DD-MM-YYYY HH24:MI'), 7, 60, 2, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-05-2022 15:38', 'DD-MM-YYYY HH24:MI'), 3, 60, 4, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 19:18', 'DD-MM-YYYY HH24:MI'), 8, 64, 4, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 17:11', 'DD-MM-YYYY HH24:MI'), 10, 64, 3, 15);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('10-05-2022 10:46', 'DD-MM-YYYY HH24:MI'), 3, 64, 3, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('16-05-2022 17:52', 'DD-MM-YYYY HH24:MI'), 2, 64, 1, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-05-2022 20:46', 'DD-MM-YYYY HH24:MI'), 5, 68, 3, 16);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('15-05-2022 10:49', 'DD-MM-YYYY HH24:MI'), 1, 68, 4, 1);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-05-2022 14:30', 'DD-MM-YYYY HH24:MI'), 7, 68, 4, 3);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 17:28', 'DD-MM-YYYY HH24:MI'), 3, 68, 2, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 14:44', 'DD-MM-YYYY HH24:MI'), 6, 72, 1, 2);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('28-05-2022 17:43', 'DD-MM-YYYY HH24:MI'), 1, 72, 2, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('24-05-2022 13:47', 'DD-MM-YYYY HH24:MI'), 8, 72, 3, 5);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('27-05-2022 16:47', 'DD-MM-YYYY HH24:MI'), 1, 72, 1, 6);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('12-05-2022 19:32', 'DD-MM-YYYY HH24:MI'), 9, 76, 4, 11);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('21-05-2022 18:40', 'DD-MM-YYYY HH24:MI'), 7, 76, 4, 14);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('20-05-2022 16:18', 'DD-MM-YYYY HH24:MI'), 8, 76, 4, 7);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('13-05-2022 19:31', 'DD-MM-YYYY HH24:MI'), 3, 76, 4, 4);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('11-05-2022 16:14', 'DD-MM-YYYY HH24:MI'), 4, 80, 4, 12);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('19-05-2022 14:53', 'DD-MM-YYYY HH24:MI'), 1, 80, 1, 13);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('22-05-2022 19:17', 'DD-MM-YYYY HH24:MI'), 7, 80, 3, 9);

INSERT INTO rezerwacje(data_rezerwacji, id_klienta, id_seansu, id_typu, nr_siedzenia)
VALUES(TO_DATE('25-05-2022 17:33', 'DD-MM-YYYY HH24:MI'), 2, 80, 1, 5);



COMMIT;


CREATE OR REPLACE PROCEDURE dodaj_cene_koncowa
IS 
CURSOR r_cursor IS
    SELECT * FROM rezerwacje;
seans NUMBER;
typ NUMBER;
cena_seans NUMBER;
wyliczona_cena NUMBER;
licznik NUMBER(6) := 1;
BEGIN 
    FOR tmp IN r_cursor LOOP
        SELECT id_seansu INTO seans FROM rezerwacje WHERE id_rezerwacji = licznik;
        SELECT id_typu INTO typ FROM rezerwacje WHERE id_rezerwacji = licznik;
        SELECT cena_pln INTO cena_seans FROM seanse WHERE id_seansu = seans;

        
        IF(typ=1) THEN
            wyliczona_cena := cena_seans;
        ELSIF(typ=2) THEN
             wyliczona_cena := 0.75 * cena_seans;

        ELSIF(typ=3) THEN
             wyliczona_cena := 0.7 * cena_seans;

        ELSIF(typ=4) THEN
             wyliczona_cena := 0.6 * cena_seans;

        END IF;
        UPDATE rezerwacje SET cena_koncowa = wyliczona_cena WHERE id_rezerwacji = licznik;
        licznik:=licznik+1;
    END LOOP;
END;
/
EXEC dodaj_cene_koncowa;
/
DROP PROCEDURE dodaj_cene_koncowa;
/
COMMIT;
DROP TABLE rezerwacje;
DROP TABLE seanse; 
DROP TABLE sale; 
DROP TABLE filmy; 
DROP TABLE gatunki_filmow;
DROP TABLE typy; 
DROP TABLE klienci; 
DROP TABLE wpisy_pracy; 
DROP TABLE pracownicy; 
DROP TABLE konta; 
DROP TABLE godziny_pracy; 
DROP TABLE dni_tygodnia; 

CREATE TABLE dni_tygodnia (
    id_dnia INTEGER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    nazwa VARCHAR2(12) 
);
CREATE TABLE godziny_pracy (
    id_godzin INTEGER  GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    poczatek INTEGER,
    koniec INTEGER
);
CREATE TABLE konta (
    login VARCHAR2(20) PRIMARY KEY,
    haslo VARCHAR2(16),
    uprawnienia NUMBER(1) -- 1-klient, 2-pracownik, 3-wlasciciel
);
CREATE TABLE pracownicy (
    id_pracownika INTEGER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    imie VARCHAR2(20),
    nazwisko VARCHAR2(20),
    PESEL VARCHAR2(11),
    data_zatrudnienia DATE DEFAULT SYSDATE,
    pensja INTEGER,
    nr_telefonu NUMBER,
    login VARCHAR2(20) REFERENCES konta(login)
);
CREATE TABLE wpisy_pracy (
    id_wpisu INTEGER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    id_dnia INTEGER REFERENCES dni_tygodnia(id_dnia),
    id_godzin_pracy INTEGER REFERENCES godziny_pracy(id_godzin),
    id_pracownika INTEGER REFERENCES pracownicy(id_pracownika)
);
CREATE TABLE klienci (
    id_klienta INTEGER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    imie VARCHAR2(20),
    nazwisko VARCHAR2(20),
    nr_telefonu NUMBER,
    mail VARCHAR2(30),
    login VARCHAR2(20) REFERENCES konta(login)
);
CREATE TABLE typy (
    id_typu INTEGER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    nazwa VARCHAR2(10),
    mnoznik_ceny NUMBER
);
CREATE TABLE gatunki_filmow(
    id_gatunku INTEGER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    nazwa VARCHAR2(20)
);
CREATE TABLE filmy (
    id_filmu INTEGER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    tytul VARCHAR2(30),
    id_gatunku INTEGER REFERENCES gatunki_filmow(id_gatunku),
    rok_produkcji NUMBER(4),
    rezyser VARCHAR2(20)
);
CREATE TABLE sale (
    id_sali INTEGER PRIMARY KEY
);
CREATE TABLE seanse (
    id_seansu INTEGER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    poczatek DATE NOT NULL,
    cena_pln NUMBER DEFAULT 20,
    id_filmu INTEGER REFERENCES filmy(id_filmu),
    id_sali INTEGER REFERENCES sale(id_sali)
);

CREATE TABLE rezerwacje (
    id_rezerwacji INTEGER GENERATED ALWAYS as IDENTITY(START with 1 INCREMENT by 1) PRIMARY KEY,
    data_rezerwacji DATE DEFAULT SYSDATE,
    cena_koncowa NUMBER,
    id_pracownika INTEGER REFERENCES pracownicy(id_pracownika),
    id_klienta INTEGER REFERENCES klienci(id_klienta),
    id_seansu INTEGER REFERENCES seanse(id_seansu),
    id_typu INTEGER REFERENCES typy(id_typu),
    nr_siedzenia INTEGER 
);


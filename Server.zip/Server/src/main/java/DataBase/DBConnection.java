package DataBase;

import java.sql.Connection;
import java.sql.SQLException;

import oracle.jdbc.pool.*;

public class DBConnection{
    String host = "127.0.0.1";
    int port = 1521;
    String database = "xe";
    String user = "system";
    String password = "system";
    Connection connection;

    public DBConnection() throws SQLException {
        OracleDataSource dataSource = new OracleDataSource();

        String url = "jdbc:oracle:thin:" +
                user + "/" + password + "@" + host + ":" + port + ":" + database;

        dataSource.setURL(url);
        this.connection = dataSource.getConnection();
    }

    public Connection getConnection(){
        return this.connection;
    }

}

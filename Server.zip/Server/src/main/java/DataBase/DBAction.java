package DataBase;


import ForQueries.*;

import java.sql.*;
import java.util.LinkedList;

enum Type{
    USER_VERIFICATION, //0
    INSERT_MOVIE,
    GET_LIST_OF_MOVIES,
    INSERT_EMPLOYEE, //3
    GET_LIST_OF_EMPLOYEES,
    GET_LIST_OF_REPERTOIRE_ROWS,
    GET_LIST_OF_SEANCES_CHARACTERISTICS, //6
    GET_RESERVATION_SUMMARY,
    INSERT_RESERVATION,
    GET_CLIENT_ID, //9
    GET_LIST_OF_RESERVATIONS,
    REMOVE_RESERVATION,
    INSERT_SEANCE, //12
    GET_USER_PRIVILEGES,
    GET_EMPLOYEE_ID,
    GET_LIST_OF_SEANCES_TO_SET, //15
    UPDATE_SEANCE_PRICE,
    REMOVE_EMPLOYEE,
    UPDATE_EMPLOYEE_SALARY, //18
    UPDATE_RESERVATION,
    GET_LIST_OF_ENTRIES,
    UPDATE_ENTRY, //21
    CREATE_CLIENT_AND_ACCOUNT,
    GET_LIST_OF_CLIENT_RESERVATIONS,
    GET_LIST_OF_TOP3_TICKET_TYPES, //24
    GET_LIST_OF_TOP3_MOVIES,
    GET_LIST_OF_TOP3_GENRES,
    GET_INCOMES, //27
    GET_LIST_OF_OCCUPIED_SEATS,
    CHANGE_PASSWORD
}
public class DBAction {
    public static Message queryLastResult;
    Connection connection;
    public DBAction(Connection connection, int choice, Message messageFromClient) throws SQLException {
        this.connection = connection;
        setAction(choice, messageFromClient);
    }
    public void setAction(int choice, Message messageFromClient) throws SQLException {
        Type type = Type.values()[choice];
        switch(type){
            case USER_VERIFICATION:
                queryOfUserVerification(this.connection, messageFromClient.object);
                break;
            case INSERT_MOVIE:
                queryOfInsertMovie(this.connection, messageFromClient.object);
                break;
            case GET_LIST_OF_MOVIES:
                queryOfGetListOfMovies(this.connection);
                break;
            case INSERT_EMPLOYEE:
                queryOfInsertEmployee(this.connection, messageFromClient.object);
                break;
            case GET_LIST_OF_EMPLOYEES:
                queryOfGetListOfEmployees(this.connection);
                break;
            case GET_LIST_OF_REPERTOIRE_ROWS:
                queryOfGetListOfRepertoireRows(this.connection);
                break;
            case GET_LIST_OF_SEANCES_CHARACTERISTICS:
                queryOfGetListSeancesCharacteristics(this.connection, messageFromClient.object);
                break;
            case GET_RESERVATION_SUMMARY:
                queryOfReservationSummary(this.connection, messageFromClient.object);
                break;
            case INSERT_RESERVATION:
                queryOfInsertReservation(this.connection, messageFromClient.object);
                break;
            case GET_CLIENT_ID:
                queryOfGetClientId(this.connection, messageFromClient.object);
                break;
            case GET_LIST_OF_RESERVATIONS:
                queryOfGetListOfReservationsToShow(this.connection);
                break;
            case REMOVE_RESERVATION:
                queryOfRemoveReservation(this.connection, messageFromClient.object);
                break;
            case INSERT_SEANCE:
                queryOfInsertSeance(this.connection, messageFromClient.object);
                break;
            case GET_USER_PRIVILEGES:
                queryOfGetUserPrivileges(this.connection, messageFromClient.object);
                break;
            case GET_EMPLOYEE_ID:
                queryOfGetEmployeeId(this.connection, messageFromClient.object);
                break;
            case GET_LIST_OF_SEANCES_TO_SET:
                queryOfGetListOfSeancesToSet(this.connection);
                break;
            case UPDATE_SEANCE_PRICE:
                queryOfUpdateSeancePrice(this.connection, messageFromClient.object);
                break;
            case REMOVE_EMPLOYEE:
                queryOfRemoveEmployee(this.connection, messageFromClient.object);
                break;
            case UPDATE_EMPLOYEE_SALARY:
                queryOfUpdateEmployeeSalary(this.connection, messageFromClient.object);
                break;
            case UPDATE_RESERVATION:
                queryOfUpdateReservation(this.connection, messageFromClient.object);
                break;
            case GET_LIST_OF_ENTRIES:
                queryOfGetListOfEntries(this.connection);
                break;
            case UPDATE_ENTRY:
                queryOfUpdateEntry(this.connection, messageFromClient.object);
                break;
            case CREATE_CLIENT_AND_ACCOUNT:
                queryOfCreateClientAndAccount(this.connection, messageFromClient.object);
                break;
            case GET_LIST_OF_CLIENT_RESERVATIONS:
                queryOfGetListOfClientReservations(this.connection, messageFromClient.object);
                break;
            case GET_LIST_OF_TOP3_TICKET_TYPES:
                queryOfGetListOfTop3TicketTypes(this.connection);
                break;
            case GET_LIST_OF_TOP3_MOVIES:
                queryOfGetListOfTop3Movies(this.connection);
                break;
            case GET_LIST_OF_TOP3_GENRES:
                queryOfGetListOfTop3Genres(this.connection);
                break;
            case GET_INCOMES:
                queryOfGetIncomes(this.connection);
                break;
            case GET_LIST_OF_OCCUPIED_SEATS:
                queryOfGetListOfOccupiedSeats(this.connection, messageFromClient.object);
                break;
            case CHANGE_PASSWORD:
                queryOfChangePassword(this.connection, messageFromClient.object);
                break;
        }
    }

    private void queryOfUserVerification(Connection connection, Object object) throws SQLException {
        Account account = (Account) object;
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT uprawnienia FROM konta WHERE login = '"
                             + account.login + "'" + " AND haslo = '" +
                             account.password + "'")) {
            if (!resultSet.isBeforeFirst() ) {
                System.out.println("No data");
                queryLastResult = new Message(0, new Account("0,0,0"));
            }
            else {
                resultSet.next();
                queryLastResult = new Message(0, new Account("0,0," + resultSet.getString(1)));
            }
            System.out.println();
        }
    }
    private void queryOfInsertMovie (Connection connection, Object object) throws SQLException {
        Movie movie = (Movie) object;
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                     ("INSERT INTO filmy(tytul, id_gatunku, rok_produkcji, rezyser) VALUES(?,?,?,?)"))){

            prepareStatement.setString(1, movie.title);
            prepareStatement.setInt(2, movie.genreId);
            prepareStatement.setInt(3, movie.yearOfProduction);
            prepareStatement.setString(4, movie.movieDirector);
            prepareStatement.executeUpdate();
            queryLastResult = new Message(0, "0,0,0,0,0");
            System.out.println();
        }
    }
    private void queryOfGetListOfMovies(Connection connection) throws SQLException {
        LinkedList<Movie> listOfMovies = new LinkedList<Movie>();

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT * FROM filmy")) {


            while (resultSet.next()){
                listOfMovies.add(new Movie(resultSet.getString(1) + "," +
                        resultSet.getString(2) + "," +
                        resultSet.getString(3) + "," +
                        resultSet.getString(4) + "," +
                        resultSet.getString(5)));
            }

            System.out.println(listOfMovies);
            queryLastResult = new Message(2, listOfMovies);
        }
    }
    private void queryOfInsertEmployee(Connection connection, Object object) throws SQLException{
        Employee employee = (Employee) object;
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("INSERT INTO konta(login, haslo, uprawnienia) VALUES(?,?,?)"))){

            prepareStatement.setString(1, employee.employeeLogin);
            prepareStatement.setString(2, employee.employeeLogin + "123");
            prepareStatement.setInt(3, 2);

            prepareStatement.executeUpdate();
            //queryLastResult = resultSet.getString(1);
            System.out.println();
        }
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("INSERT INTO pracownicy(imie, nazwisko, pesel, pensja, nr_telefonu, login) VALUES(?,?,?,?,?,?)"))){

            prepareStatement.setString(1, employee.firstName);
            prepareStatement.setString(2, employee.lastName);
            prepareStatement.setString(3, employee.pesel);
            prepareStatement.setInt(4, employee.salary);
            prepareStatement.setInt(5, employee.phoneNumber);
            prepareStatement.setString(6, employee.employeeLogin);
            prepareStatement.executeUpdate();
            //queryLastResult = resultSet.getString(1);
            System.out.println();
        }
    }
    private void queryOfGetListOfEmployees(Connection connection) throws SQLException {
        LinkedList<Employee> listOfEmployees = new LinkedList<>();

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT * FROM pracownicy WHERE nazwisko <> 'BRAK'")) {

            while (resultSet.next()){
                listOfEmployees.add(new Employee(resultSet.getString(1) + "," +
                        resultSet.getString(2) + "," +
                        resultSet.getString(3) + "," + "0," +
                        resultSet.getString(5) + "," +
                        resultSet.getString(6) + ",0," +
                        resultSet.getString(8)));
            }
            queryLastResult = new Message(4, listOfEmployees);
        }
    }
    private void queryOfGetListOfRepertoireRows(Connection connection){
        LinkedList<RepertoireRow> listOfRepertoireRows = new LinkedList<>();

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT seanse.id_filmu, filmy.tytul, filmy.rok_produkcji, filmy.rezyser, gatunki_filmow.nazwa " +
                             "FROM seanse INNER JOIN filmy " +
                             "ON seanse.id_filmu = filmy.id_filmu " +
                             "INNER JOIN gatunki_filmow " +
                             "ON filmy.id_gatunku = gatunki_filmow.id_gatunku " +
                             "GROUP BY seanse.id_filmu, filmy.tytul, filmy.rok_produkcji, filmy.rezyser, gatunki_filmow.nazwa")) {

            while (resultSet.next()){
                listOfRepertoireRows.add(new RepertoireRow(resultSet.getString(1) + "," + resultSet.getString(2) + "," +
                        resultSet.getString(3) + "," + resultSet.getString(4) + "," + resultSet.getString(5)));
            }
            queryLastResult = new Message(5, listOfRepertoireRows);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void queryOfGetListSeancesCharacteristics(Connection connection, Object object){
        LinkedList<SeanceCharacteristics> listOfSeancesCharacteristics = new LinkedList<>();
        SeanceCharacteristics dateOfSeance = (SeanceCharacteristics) object;
        int movieId = dateOfSeance.seanceId;

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT id_seansu, TO_CHAR(poczatek, 'DD-MM-YYYY HH24:MI'), cena_pln " +
                             "FROM seanse " +
                             "WHERE id_filmu = " + movieId + " AND SYSDATE < poczatek")) {

            while (resultSet.next()){
                listOfSeancesCharacteristics.add(new SeanceCharacteristics(resultSet.getString(1) + "," + resultSet.getString(2) + "," + resultSet.getString(3)));
            }
            System.out.println(listOfSeancesCharacteristics);
            queryLastResult = new Message(6, listOfSeancesCharacteristics);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void queryOfReservationSummary(Connection connection, Object object){
        ReservationSummary reservationSummary = (ReservationSummary) object;

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT seanse.id_seansu, filmy.tytul, TO_CHAR(seanse.poczatek, 'DD-MM-YYYY'), TO_CHAR(seanse.poczatek, 'HH24:MI'), seanse.id_sali " +
                             "FROM filmy " +
                             "INNER JOIN seanse " +
                             "ON filmy.id_filmu = seanse.id_filmu " +
                             "WHERE seanse.id_seansu = " + reservationSummary.seanceId)) {

            while (resultSet.next()){
                reservationSummary = new ReservationSummary(resultSet.getString(1) + "," + resultSet.getString(2) + "," + resultSet.getString(3) + "," +
                        resultSet.getString(4) + "," + resultSet.getString(5) + ",11");
            }
            queryLastResult = new Message(7, reservationSummary);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    private void queryOfInsertReservation(Connection connection, Object object) throws SQLException {
        ReservationToInsert reservation = (ReservationToInsert) object;
        //if (reservation.clientId != 0) {

            try (PreparedStatement prepareStatement = connection.prepareStatement(
                    ("INSERT INTO rezerwacje(cena_koncowa, id_klienta, id_seansu, id_typu, nr_siedzenia) VALUES(?,?,?,?,?)"))) {

                prepareStatement.setDouble(1, reservation.finalPrice);
                prepareStatement.setInt(2, reservation.clientId);
                prepareStatement.setInt(3, reservation.seanceId);
                prepareStatement.setInt(4, reservation.typeId);
                prepareStatement.setInt(5, reservation.seatId);
                prepareStatement.executeUpdate();
                queryLastResult = new Message(8, "0,0,0,0,0");
                System.out.println();
            }
       /* }else{
            try (PreparedStatement prepareStatement = connection.prepareStatement(
                    ("INSERT INTO rezerwacje(cena_koncowa, id_pracownika, id_seansu, id_typu, id_siedzenia) VALUES(?,?,?,?,?)"))) {
                System.out.println(reservation.finalPrice + " " + reservation.employeeId + " " + reservation.seanceId + " " + reservation.typeId + " " + reservation.seatId);
                prepareStatement.setDouble(1, reservation.finalPrice);
                prepareStatement.setInt(2, reservation.employeeId);
                prepareStatement.setInt(3, reservation.seanceId);
                prepareStatement.setInt(4, reservation.typeId);
                prepareStatement.setInt(5, reservation.seatId);
                prepareStatement.executeUpdate();
                queryLastResult = new Message(8, "0,0,0,0,0");
                System.out.println();
            }
        }*/
    }
    private void queryOfGetClientId(Connection connection, Object object) throws SQLException {
        Client client = (Client) object;
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT klienci.id_klienta FROM klienci " +
                             "INNER JOIN konta " +
                             "ON konta.login = klienci.login " +
                             "WHERE konta.login = '" + client.login + "'")) {

            resultSet.next();
            queryLastResult = new Message(9, new Client(resultSet.getString(1)));

            System.out.println();
        }
    }
    private void queryOfGetListOfReservationsToShow(Connection connection) throws SQLException{
        LinkedList<ReservationToShow> listOfReservations = new LinkedList<ReservationToShow>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT rezerwacje.id_rezerwacji,  SUBSTR(klienci.imie,1,1) || '. ' || klienci.nazwisko, rezerwacje.data_rezerwacji, " +
                             "rezerwacje.id_seansu, filmy.tytul, seanse.id_sali, rezerwacje.nr_siedzenia " +
                             "FROM klienci " +
                             "INNER JOIN rezerwacje " +
                             "ON klienci.id_klienta = rezerwacje.id_klienta " +
                             "INNER JOIN seanse " +
                             "ON rezerwacje.id_seansu = seanse.id_seansu " +
                             "INNER JOIN filmy " +
                             "ON seanse.id_filmu = filmy.id_filmu")) {

            while (resultSet.next()){
                listOfReservations.add(new ReservationToShow(resultSet.getString(1) + "," +
                        resultSet.getString(2) + "," + resultSet.getString(3) + "," +
                        resultSet.getString(4) + "," + resultSet.getString(5) + "," +
                        resultSet.getString(6) + "," + resultSet.getString(7)));
            }
            queryLastResult = new Message(10, listOfReservations);
        }
    }
    private void queryOfRemoveReservation(Connection connection, Object object) throws SQLException{
        ReservationToShow reservation = (ReservationToShow) object;
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("DELETE FROM rezerwacje WHERE id_rezerwacji = " + reservation.reservationId))){
            prepareStatement.executeUpdate();
            queryLastResult = new Message(11, reservation.reservationId + ",0,0,0,0,0,0");
        }
    }
    private void queryOfInsertSeance(Connection connection, Object object) throws SQLException{
        SeanceToInsert seanceToInsert = (SeanceToInsert) object;
        System.out.println(Timestamp.valueOf(seanceToInsert.seanceDate));
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("INSERT INTO seanse(poczatek, id_filmu, id_sali)" +
                        " VALUES(?, ?, ?)"))){

            prepareStatement.setTimestamp(1, Timestamp.valueOf(seanceToInsert.seanceDate));
            prepareStatement.setInt(2, seanceToInsert.movieId);
            prepareStatement.setInt(3, seanceToInsert.hallId);
            prepareStatement.executeUpdate();
            queryLastResult = new Message(12, "0,0,0");
            System.out.println();
        }
    }
    private void queryOfGetUserPrivileges(Connection connection, Object object) throws SQLException {
        Account account = (Account) object;
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT uprawnienia FROM konta WHERE login = '"
                             + account.login + "'")) {
            resultSet.next();
            queryLastResult = new Message(0, new Account("0,0," + resultSet.getString(1)));

            System.out.println();
        }
    }
    private void queryOfGetEmployeeId(Connection connection, Object object) throws SQLException {
        Employee employee = (Employee) object;
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT pracownicy.id_pracownika FROM pracownicy " +
                             "INNER JOIN konta " +
                             "ON konta.login = pracownicy.login " +
                             "WHERE konta.login = '" + employee.employeeLogin + "'")) {

            resultSet.next();
            queryLastResult = new Message(14, new Employee(resultSet.getString(1) + ",0,0,0,0,0,0,0"));

            System.out.println();
        }
    }
    private void queryOfGetListOfSeancesToSet(Connection connection) throws SQLException {
        LinkedList<SeanceToSet> listOfSeances = new LinkedList<SeanceToSet>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT seanse.id_seansu, TO_CHAR(seanse.poczatek, 'DD-MM-YYYY HH24:MI'), filmy.tytul, seanse.cena_pln " +
                             "FROM seanse " +
                             "INNER JOIN filmy " +
                             "ON seanse.id_filmu = filmy.id_filmu")) {

            while (resultSet.next()){
                listOfSeances.add(new SeanceToSet(resultSet.getString(1) + "," +
                        resultSet.getString(2) + "," + resultSet.getString(3) + "," +
                        resultSet.getString(4)));
            }
            queryLastResult = new Message(15, listOfSeances);
        }
    }
    private void queryOfUpdateSeancePrice(Connection connection, Object object) throws SQLException {
        SeanceToSet seanceToSet = (SeanceToSet) object;
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("UPDATE seanse SET cena_pln = " + seanceToSet.seancePrice + " WHERE id_seansu = " + seanceToSet.seanceId))){
            prepareStatement.executeUpdate();
            queryLastResult = new Message(16, seanceToSet.seanceId + ",0,0,0");
        }
    }
    private void queryOfRemoveEmployee(Connection connection, Object object) throws SQLException{
        Employee employee = (Employee) object;
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("UPDATE wpisy_pracy SET id_pracownika = 1 WHERE id_pracownika = " + employee.employeeId))){
            prepareStatement.executeUpdate();
        }
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("DELETE FROM pracownicy WHERE id_pracownika = " + employee.employeeId ))){
            prepareStatement.executeUpdate();
        }
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("DELETE FROM konta WHERE login = '" + employee.employeeLogin + "'"))){
            prepareStatement.executeUpdate();
        }
        queryLastResult = new Message(17, employee.employeeId + ",0,0,0,0,0,0,0");
    }
    private void queryOfUpdateEmployeeSalary(Connection connection, Object object) throws SQLException{
        Employee employee = (Employee) object;
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("UPDATE pracownicy SET pensja = " + employee.salary + " WHERE id_pracownika = " + employee.employeeId))){
            prepareStatement.executeUpdate();
            queryLastResult = new Message(18, employee.employeeId + ",0,0,0,0,0,0,0");
        }
    }
    private void queryOfUpdateReservation(Connection connection, Object object) throws SQLException{
        ReservationToShow reservation = (ReservationToShow) object;
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("UPDATE rezerwacje SET nr_siedzenia = " + reservation.seatNumber + " WHERE id_rezerwacji = " + reservation.reservationId))){
            prepareStatement.executeUpdate();
            queryLastResult = new Message(19, reservation.reservationId + ",0,0,0,0,0,0");
        }
    }
    private void queryOfGetListOfEntries(Connection connection) throws SQLException {
        LinkedList<Entry> listOfEntries = new LinkedList<>();

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT wpisy_pracy.id_wpisu, dni_tygodnia.nazwa, godziny_pracy.poczatek || '.00 - ' || godziny_pracy.koniec || '.00'," +
                             " pracownicy.imie || ' ' || pracownicy.nazwisko" +
                             " FROM dni_tygodnia" +
                             " INNER JOIN wpisy_pracy" +
                             " ON dni_tygodnia.id_dnia = wpisy_pracy.id_dnia" +
                             " INNER JOIN godziny_pracy" +
                             " ON wpisy_pracy.id_godzin_pracy = godziny_pracy.id_godzin" +
                             " INNER JOIN pracownicy" +
                             " ON wpisy_pracy.id_pracownika = pracownicy.id_pracownika" +
                             " ORDER BY wpisy_pracy.id_wpisu")) {

            while (resultSet.next()){
                listOfEntries.add(new Entry(resultSet.getString(1) + "," +
                        resultSet.getString(2) + "," +
                        resultSet.getString(3) + ",0," +
                        resultSet.getString(4)));
            }
            queryLastResult = new Message(20, listOfEntries);
        }
    }
    private void queryOfUpdateEntry(Connection connection, Object object) throws SQLException {
        Entry entry = (Entry) object;
        try (PreparedStatement prepareStatement = connection.prepareStatement(
                ("UPDATE wpisy_pracy SET id_pracownika = " + entry.employeeId + " WHERE id_wpisu = " + entry.entryId))){
            prepareStatement.executeUpdate();
            queryLastResult = new Message(21, entry.entryId + ",0,0,0,0");
        }
    }
    private void queryOfCreateClientAndAccount(Connection connection, Object object) throws SQLException {
        ClientAndAccount clientAndAccount = (ClientAndAccount) object;

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT uprawnienia FROM konta WHERE login = '"
                             + clientAndAccount.login + "'")) {
            if (resultSet.next()) {
                System.out.println("No data");
                queryLastResult = new Message(22, new ClientAndAccount("0,0,0,0," + resultSet.getString(1) + ",0"));
            }
            else{
                try (PreparedStatement prepareStatement = connection.prepareStatement(
                        ("INSERT INTO konta(login, haslo, uprawnienia) VALUES(?, ?, ?)"))) {
                    prepareStatement.setString(1, clientAndAccount.login);
                    prepareStatement.setString(2, clientAndAccount.password);
                    prepareStatement.setInt(3, 1);
                    prepareStatement.executeUpdate();
                }

                try (PreparedStatement prepareStatement = connection.prepareStatement(
                        ("INSERT INTO klienci(imie, nazwisko, nr_telefonu, mail, login) VALUES(?, ?, ?, ?, ?)"))) {
                    prepareStatement.setString(1, clientAndAccount.firstName);
                    prepareStatement.setString(2, clientAndAccount.lastName);
                    prepareStatement.setInt(3, clientAndAccount.phoneNumber);
                    prepareStatement.setString(4, clientAndAccount.eMail);
                    prepareStatement.setString(5, clientAndAccount.login);
                    prepareStatement.executeUpdate();
                    queryLastResult = new Message(22, new ClientAndAccount("0,0,0,0,0,0"));
                }
            }
        }

    }
    private void queryOfGetListOfClientReservations(Connection connection, Object object) throws SQLException{
        ReservationToShow reservation = (ReservationToShow) object;
        LinkedList<ReservationToShow> listOfReservations = new LinkedList<ReservationToShow>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT rezerwacje.id_rezerwacji,  SUBSTR(klienci.imie,1,1) || '. ' || klienci.nazwisko, rezerwacje.data_rezerwacji, " +
                             "rezerwacje.id_seansu, filmy.tytul, seanse.id_sali, rezerwacje.nr_siedzenia " +
                             "FROM klienci " +
                             "INNER JOIN rezerwacje " +
                             "ON klienci.id_klienta = rezerwacje.id_klienta " +
                             "INNER JOIN seanse " +
                             "ON rezerwacje.id_seansu = seanse.id_seansu " +
                             "INNER JOIN filmy " +
                             "ON seanse.id_filmu = filmy.id_filmu WHERE klienci.id_klienta = " + reservation.clientName)) {

            while (resultSet.next()){
                listOfReservations.add(new ReservationToShow(resultSet.getString(1) + "," +
                        resultSet.getString(2) + "," + resultSet.getString(3) + "," +
                        resultSet.getString(4) + "," + resultSet.getString(5) + "," +
                        resultSet.getString(6) + "," + resultSet.getString(7)));
            }
            queryLastResult = new Message(23, listOfReservations);
        }
    }
    private void queryOfGetListOfTop3TicketTypes(Connection connection) throws SQLException {
        LinkedList<TicketType> listOfTop3TicketTypes = new LinkedList<TicketType>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT DENSE_RANK() OVER (ORDER BY COUNT(*) DESC) AS DENSE_RANK, typy.nazwa, COUNT(*) " +
                        "FROM typy " +
                        "INNER JOIN rezerwacje " +
                        "ON typy.id_typu = rezerwacje.id_typu " +
                        "GROUP BY typy.nazwa " +
                        "FETCH FIRST 3 ROWS ONLY")) {

            while (resultSet.next()){
                listOfTop3TicketTypes.add(new TicketType(resultSet.getString(1) + "," +
                        resultSet.getString(2) + "," + resultSet.getString(3)));
            }
            queryLastResult = new Message(24, listOfTop3TicketTypes);
        }
    }
    private void queryOfGetListOfTop3Movies(Connection connection) throws SQLException {
        LinkedList<Movie> listOfTop3Movies = new LinkedList<Movie>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT DENSE_RANK() OVER (ORDER BY COUNT(*) DESC) AS DENSE_RANK, filmy.tytul, filmy.rok_produkcji, filmy.rezyser, COUNT(*) " +
                        "FROM filmy " +
                        "INNER JOIN seanse " +
                        "ON filmy.id_filmu = seanse.id_filmu " +
                        "INNER JOIN rezerwacje " +
                        "ON rezerwacje.id_seansu = seanse.id_seansu " +
                        "GROUP BY filmy.tytul, filmy.rok_produkcji, filmy.rezyser " +
                        "FETCH FIRST 3 ROWS ONLY")) {

            while (resultSet.next()){
                listOfTop3Movies.add(new Movie(resultSet.getString(1) + "," + resultSet.getString(2) + ","
                        + resultSet.getString(5) + "," + resultSet.getString(3) + "," + resultSet.getString(4)));
            }
            queryLastResult = new Message(25, listOfTop3Movies);
        }
    }
    private void queryOfGetListOfTop3Genres(Connection connection) throws SQLException {
        LinkedList<Genre> listOfTop3Genres = new LinkedList<Genre>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT DENSE_RANK() OVER (ORDER BY COUNT(*) DESC) AS DENSE_RANK, gatunki_filmow.nazwa, COUNT(*) " +
                        "FROM gatunki_filmow " +
                        "INNER JOIN filmy " +
                        "ON gatunki_filmow.id_gatunku = filmy.id_gatunku " +
                        "INNER JOIN seanse " +
                        "ON filmy.id_filmu = seanse.id_filmu " +
                        "INNER JOIN rezerwacje " +
                        "ON seanse.id_seansu = rezerwacje.id_seansu " +
                        "GROUP BY gatunki_filmow.nazwa " +
                        "FETCH FIRST 3 ROWS ONLY")) {

            while (resultSet.next()){
                listOfTop3Genres.add(new Genre(resultSet.getString(1) + "," +
                        resultSet.getString(2) + "," + resultSet.getString(3)));
            }
            queryLastResult = new Message(26, listOfTop3Genres);
        }
    }
    private void queryOfGetIncomes(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT SUM(rezerwacje.cena_koncowa)" +
                             "FROM rezerwacje " +
                             "INNER JOIN seanse " +
                             "ON rezerwacje.id_seansu = seanse.id_seansu " +
                             "WHERE seanse.poczatek < SYSDATE")) {

            resultSet.next();
            queryLastResult = new Message(27, new Incomes(resultSet.getString(1)));
        }
    }
    private void queryOfGetListOfOccupiedSeats(Connection connection, Object object) throws SQLException {
        Seat seat = (Seat) object;
        int seanceId = seat.seatId;
        LinkedList<Seat> listOfOccupiedSeats = new LinkedList<Seat>();
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT nr_siedzenia" +
                             " FROM  rezerwacje" +
                             " WHERE id_seansu = " + seanceId)) {

            while (resultSet.next()){
                listOfOccupiedSeats.add(new Seat(resultSet.getString(1)));
            }
            queryLastResult = new Message(28, listOfOccupiedSeats);
        }
    }
    private void queryOfChangePassword(Connection connection, Object object) throws SQLException{
        ChangePassword changePassword = (ChangePassword) object;
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery
                     ("SELECT uprawnienia FROM konta WHERE login = '"
                             + changePassword.login + "'" + " AND haslo = '" +
                             changePassword.oldPassword + "'")) {
            if (!resultSet.isBeforeFirst() ) {
                System.out.println("No data");
                queryLastResult = new Message(29, new ChangePassword("0,0,0"));
            }
            else {
                resultSet.next();
                queryLastResult = new Message(29, new ChangePassword("0,0," + resultSet.getString(1)));
                try (PreparedStatement prepareStatement = connection.prepareStatement(
                        ("UPDATE konta SET haslo = '" + changePassword.newPassword + "' WHERE login = '" + changePassword.login + "'"))){
                    prepareStatement.executeUpdate();
                }
            }
            System.out.println();
        }
    }
}



package ForQueries;

import java.io.Serializable;

public class Employee implements Serializable {
    public int employeeId;
    public String firstName;
    public String lastName;
    public String pesel;
    public String dateOfEmployment;
    public int salary;
    public int phoneNumber;
    public String employeeLogin;

    final static String sep = ",";

    public Employee(String s) {
        String tmp[] = s.split(sep);
        employeeId = Integer.parseInt(tmp[0]);
        firstName = tmp[1];
        lastName = tmp[2];
        pesel = tmp[3];
        dateOfEmployment = tmp[4];
        salary = Integer.parseInt(tmp[5]);
        phoneNumber = Integer.parseInt(tmp[6]);
        employeeLogin = tmp[7];
    }
    public String toString(){
        return employeeId + ", " + firstName + " " + lastName;
    }
    /*public String toString(){
        return employeeId + sep + firstName + sep + lastName
                + sep + pesel + sep + dateOfEmployment + sep + salary + sep
                + phoneNumber + sep + employeeLogin;
    } */
}

package ForQueries;

import java.io.Serializable;

public class TicketType implements Serializable {
    public int rankPosition;
    public String name;
    public int number;

    final static String sep = ",";

    public TicketType(String s) {
        String tmp[] = s.split(sep);
        rankPosition = Integer.parseInt(tmp[0]);
        name = tmp[1];
        number = Integer.parseInt(tmp[2]);
    }

    public String toString() {
        return rankPosition + ". " + name + ", Liczba: " + number;
    }
}


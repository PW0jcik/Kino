package ForQueries;

import java.io.Serializable;

public class ClientAndAccount implements Serializable {
    public String firstName;
    public String lastName;
    public int phoneNumber;
    public String eMail;
    public String login;
    public String password;

    final static String sep = ",";

    public ClientAndAccount(String s){
        String tmp[] = s.split(sep);
        firstName = tmp[0];
        lastName = tmp[1];
        phoneNumber = Integer.parseInt(tmp[2]);
        eMail = tmp[3];
        login = tmp[4];
        password = tmp[5];
    }
    public String toString(){
        return firstName + sep + lastName + sep + phoneNumber + sep + eMail + sep + login + sep + password;
    }
}
package ForQueries;

import java.io.Serializable;

public class ChangePassword implements Serializable {
    public String login;
    public String oldPassword;
    public String newPassword;

    final static String sep = ",";

    public ChangePassword(String s){
        String tmp[] = s.split(sep);
        login = tmp[0];
        oldPassword = tmp[1];
        newPassword = tmp[2];
    }
    public String toString(){
        return login + sep + oldPassword + sep + newPassword;
    }
}
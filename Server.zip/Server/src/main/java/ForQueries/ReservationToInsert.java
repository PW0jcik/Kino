package ForQueries;

import java.io.Serializable;

public class ReservationToInsert implements Serializable {
    public double finalPrice;
    public int employeeId;
    public int clientId;
    public int seanceId;
    public int typeId;
    public int seatId;

    final static String sep = ",";

    public ReservationToInsert(String s){
        String tmp[] = s.split(sep);
        finalPrice = Double.parseDouble(tmp[0]);
        employeeId = Integer.parseInt(tmp[1]);
        clientId = Integer.parseInt(tmp[2]);
        seanceId = Integer.parseInt(tmp[3]);
        typeId = Integer.parseInt(tmp[4]);
        seatId = Integer.parseInt(tmp[5]);
    }
    public String toString(){
        return finalPrice + sep + employeeId + sep + clientId + sep + seanceId + sep + typeId + sep + seatId;
    }
}
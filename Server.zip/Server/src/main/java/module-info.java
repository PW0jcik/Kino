module Server {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.web;
    requires javafx.media;
    requires java.sql;
    requires junit;
    requires ojdbc8;
    requires java.naming;

    exports DataBase to javafx.graphics,javafx.base,
            javafx.controls,javafx.web,javafx.media, java.sql, java.ojdbc8, java.naming;
    exports Server to javafx.graphics,javafx.base,
            javafx.controls,javafx.web,javafx.media, java.sql, java.ojdbc8, java.naming;
    exports ForQueries to javafx.graphics,javafx.base,
            javafx.controls,javafx.web,javafx.media, java.sql, java.ojdbc8, java.naming;
}
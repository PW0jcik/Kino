package Server;

import ForQueries.Message;
import DataBase.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClientHandler implements Runnable{

    public static ArrayList<ClientHandler> clientHandlers = new ArrayList<>();
    private Socket socket;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;
    static Connection connection;
    DBConnection dbConnection;
    public ClientHandler(Socket socket){
        try {
            this.dbConnection = new DBConnection();
            connection = dbConnection.getConnection();
            this.socket = socket;
            this.outputStream = new ObjectOutputStream(socket.getOutputStream());
            this.inputStream = new ObjectInputStream(socket.getInputStream());
            clientHandlers.add(this);
        } catch (IOException | SQLException e) {
            closeEverything(socket, inputStream, outputStream);
        }
    }

    @Override
    public void run() {
        Message messageFromClient;
        while(socket.isConnected()){
            try {
                messageFromClient = (Message) inputStream.readObject();
                new DBAction(dbConnection.getConnection(), messageFromClient.type, messageFromClient);
                System.out.println("Serwer wysłał: " + DBAction.queryLastResult);
                outputStream.writeObject(DBAction.queryLastResult);
                DBAction.queryLastResult = null;

            } catch(IOException | ClassNotFoundException | SQLException  e){

            }
        }
    }

    public void removeClientHandler(){
        clientHandlers.remove(this);
    }
    public void closeEverything(Socket socket, ObjectInputStream inputStream, ObjectOutputStream outputStream){
        removeClientHandler();
        try {
            if(inputStream != null){
                inputStream.close();
            }
            if(outputStream != null){
                outputStream.close();
            }
            if(socket != null){
                socket.close();
            }
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}
